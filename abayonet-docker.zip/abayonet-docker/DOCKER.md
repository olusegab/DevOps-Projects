# AbayoNet — Docker setup

This packages AbayoNet + MySQL into two containers you can hand to
anyone with Docker installed — no manual MySQL install, no systemd
unit, no Python dependency wrangling.

## Requirements on the target machine
    Docker Engine + Docker Compose (Linux host strongly recommended —
    see the networking note below)

## 1. Files needed
Give the recipient this whole folder:
    Dockerfile
    docker-compose.yml
    .dockerignore
    abayonet.py
    static/index.html

(abayonet.cfg is intentionally NOT used in the Docker setup — all
config is passed as environment variables in docker-compose.yml.)

## 2. Set passwords
Either edit the defaults directly in docker-compose.yml, or create a
`.env` file next to it:
    DB_ROOT_PASSWORD=some_strong_password
    DB_PASSWORD=another_strong_password

## 3. Build and start
    docker compose up -d --build

First start takes a bit longer while MySQL initializes and AbayoNet
creates its tables. Watch it come up:
    docker compose logs -f app

You're looking for the same "database ready" and "Listening on all
interfaces" lines you'd see in `journalctl` on a bare-metal install.

## 4. Open the dashboard
With the recommended host networking (default in docker-compose.yml):
    http://<server-ip>:8780

Default login: admin / admin123 — change this immediately after first
login (Settings → Change My Password).

## 5. Networking — read this before deploying for real use
AbayoNet does raw ICMP ping and SNMP UDP polling against real devices
on your network (store routers, etc.), and other people on your LAN
need to reach the dashboard in their browser. **Host networking**
(already set in docker-compose.yml via `network_mode: host`) is the
closest match to how AbayoNet runs bare-metal today, and is what's
recommended.

This only works on Linux Docker hosts. If you're on Docker Desktop
(Mac/Windows) or want the container network-isolated, switch to the
bridge + port-mapping block commented out in docker-compose.yml — but
test ping/SNMP against your actual devices afterward, since bridge
networking can behave differently for raw sockets and UDP depending on
your Docker setup.

## 6. Stopping / restarting
    docker compose stop          # stop both containers
    docker compose start         # start them again, data intact
    docker compose down          # stop and remove containers (data volume is kept)
    docker compose down -v       # ⚠ also deletes the MySQL data volume — wipes everything

## 7. Updating the app
After you get a new abayonet.py / index.html from me:
    docker compose up -d --build app

This rebuilds only the app image and restarts it — the database
container and its data are untouched.

## 8. Backing up your data
The MySQL data lives in a named Docker volume (`abayonet_db_data`),
not inside the container, so `docker compose down` alone won't lose
it. To take an actual backup:
    docker compose exec db mysqldump -u root -p abayonetDB > backup.sql

To restore:
    cat backup.sql | docker compose exec -T db mysql -u root -p abayonetDB
