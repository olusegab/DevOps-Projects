# 🇳🇬 Nigeria Job Scout v1.0.0

**Automated Job & Scholarship Finder — delivered straight to your Telegram**

Runs silently on your Windows PC, searches every 2 hours for remote network jobs and every 24 hours for Masters scholarships, then sends results directly to your Telegram.

---

## What It Searches For

### 💼 Jobs (every 2 hours)
- Network Administrator (Nigeria + Remote + Abroad)
- Network Engineer (Nigeria + Remote + Abroad)
- NOC Engineer / Infrastructure Engineer
- IT Support Engineer / System Administrator
- **Sources:** RemoteOK, LinkedIn, Jobberman, MyJobMag, JobGurus

### 🎓 Scholarships (every 24 hours)
- Full Masters Scholarships in Cybersecurity
- Full Masters Scholarships in Information Technology
- Open to Nigerians / Africans
- **Sources:** ScholarshipsForAfricans, AfterSchoolAfrica, OpportunitiesForAfricans, ScholarshipPortal

---

## Installation Guide (Windows)

### Step 1 — Get the Files
You need two files in the same folder:
- `nigeria_job_scout.exe` (the main app)
- `install.bat` (the installer)

### Step 2 — Create Your Telegram Bot

1. Open **Telegram** on your phone or PC
2. Search for **@BotFather**
3. Send the message: `/newbot`
4. Follow the prompts — give your bot a name and username
5. BotFather will give you a **Bot Token** that looks like:
   ```
   7123456789:AAFxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
   **Copy this token — you need it in Step 4.**

6. Search for your new bot by the username you chose
7. Start a chat with it by pressing **START** or sending `/start`

### Step 3 — Run the Installer

Double-click `install.bat`

The installer will:
- Copy the app to `%APPDATA%\NigeriaJobScout\`
- Create a Desktop shortcut
- Run the setup wizard

### Step 4 — Setup Wizard

The setup wizard will ask for your **Bot Token**.
- Paste the token from Step 2 and press Enter
- The app will automatically detect your **Chat ID**
- If it can't auto-detect, see "How to find your Chat ID" below

### Step 5 — Add to Windows Startup (Recommended)

In the installer menu, choose option **[4] Add to Windows Startup**

This makes the scout run automatically every time you turn on your PC.

---

## How to Find Your Chat ID Manually

1. Open a terminal (Command Prompt) in the install folder
2. Run: `nigeria_job_scout.exe --get-chat-id`
3. Copy the number shown — that's your Chat ID

Or open this URL in a browser (replace YOUR_TOKEN):
```
https://api.telegram.org/botYOUR_TOKEN/getUpdates
```
Look for `"chat":{"id": XXXXXXX}` — the number is your Chat ID.

---

## Commands

| Command | What It Does |
|---------|-------------|
| `nigeria_job_scout.exe` | Start the scout (runs forever) |
| `nigeria_job_scout.exe --setup` | Re-run setup wizard |
| `nigeria_job_scout.exe --test` | Send a test Telegram message |
| `nigeria_job_scout.exe --get-chat-id` | Show your chat ID |
| `nigeria_job_scout.exe --help` | Show all commands |

---

## Config File

After setup, your config is saved at:
```
C:\Users\YourName\AppData\Roaming\NigeriaJobScout\config.json
```

You can open it with Notepad to change settings:

```json
{
  "telegram": {
    "bot_token": "YOUR_TOKEN",
    "chat_id": "YOUR_CHAT_ID"
  },
  "schedule": {
    "job_interval_hours": 2,
    "scholarship_interval_hours": 24
  }
}
```

Change `job_interval_hours` to `1` for hourly job searches.

---

## Log File

When running silently, logs are saved at:
```
C:\Users\YourName\AppData\Roaming\NigeriaJobScout\scout.log
```

Open it with Notepad to see what the scout has been doing.

---

## How to Build from Source (Advanced)

If you want to compile yourself:

### Requirements
- [Rust](https://rustup.rs/) (rustup install)
- Windows: Microsoft Visual C++ Build Tools OR MinGW

### Build Steps
```bash
# Clone or download the source
cd nigeria_job_scout

# Build release binary (small, fast)
cargo build --release

# Binary will be at:
# target/release/nigeria_job_scout.exe
```

### Cross-compile from Linux to Windows
```bash
# Install Windows target
rustup target add x86_64-pc-windows-gnu
apt-get install gcc-mingw-w64

# Build
cargo build --release --target x86_64-pc-windows-gnu
# Output: target/x86_64-pc-windows-gnu/release/nigeria_job_scout.exe
```

---

## Troubleshooting

**"Bot token invalid"**
- Make sure you copied the full token including the colon and numbers before it
- Try creating a new bot with @BotFather

**"No chat ID found"**
- Make sure you sent `/start` to your bot in Telegram first
- Wait 30 seconds and try `--get-chat-id` again

**"No jobs found in this scan"**
- This is normal — it only alerts you when NEW jobs appear
- Wait for the next scan cycle (2 hours for jobs)

**App closes immediately**
- Open Command Prompt, navigate to the install folder
- Run `nigeria_job_scout.exe` directly to see error messages

**"Access Denied" during install**
- Right-click `install.bat` and choose "Run as Administrator"

---

## Privacy

- This app does NOT collect any data
- All searches are done locally on your PC
- Your Telegram credentials stay on your device only
- No account registration required

---

## Built With

- **Rust** — fast, lightweight, no runtime needed
- **Tokio** — async runtime for concurrent searches
- **Reqwest** — HTTP client for web scraping
- **Scraper** — HTML parsing
- **Telegram Bot API** — free notifications

---

*Good luck with your job search and scholarship applications! 🇳🇬🚀*
