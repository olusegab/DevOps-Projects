use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::path::PathBuf;
use chrono::Local;

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct SeenCache {
    pub job_ids: HashSet<String>,
    pub scholarship_ids: HashSet<String>,
    pub last_job_scan: Option<String>,
    pub last_scholarship_scan: Option<String>,
}

impl SeenCache {
    fn cache_path() -> PathBuf {
        let config_dir = dirs::config_dir().unwrap_or_else(|| PathBuf::from("."));
        config_dir.join("NigeriaJobScout").join("seen_cache.json")
    }

    pub fn load() -> Self {
        let path = Self::cache_path();
        if path.exists() {
            if let Ok(content) = std::fs::read_to_string(&path) {
                if let Ok(cache) = serde_json::from_str(&content) {
                    return cache;
                }
            }
        }
        SeenCache::default()
    }

    pub fn save(&self) -> Result<()> {
        let path = Self::cache_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let content = serde_json::to_string_pretty(self)?;
        std::fs::write(&path, content)?;
        Ok(())
    }

    pub fn is_new_job(&self, id: &str) -> bool {
        !self.job_ids.contains(id)
    }

    pub fn is_new_scholarship(&self, id: &str) -> bool {
        !self.scholarship_ids.contains(id)
    }

    pub fn mark_job_seen(&mut self, id: &str) {
        self.job_ids.insert(id.to_string());
        // Keep cache from growing forever — max 2000 entries
        if self.job_ids.len() > 2000 {
            let to_remove: Vec<String> = self.job_ids.iter().take(500).cloned().collect();
            for id in to_remove {
                self.job_ids.remove(&id);
            }
        }
    }

    pub fn mark_scholarship_seen(&mut self, id: &str) {
        self.scholarship_ids.insert(id.to_string());
        if self.scholarship_ids.len() > 1000 {
            let to_remove: Vec<String> = self.scholarship_ids.iter().take(200).cloned().collect();
            for id in to_remove {
                self.scholarship_ids.remove(&id);
            }
        }
    }

    pub fn update_job_scan_time(&mut self) {
        self.last_job_scan = Some(Local::now().format("%Y-%m-%d %H:%M:%S").to_string());
    }

    pub fn update_scholarship_scan_time(&mut self) {
        self.last_scholarship_scan = Some(Local::now().format("%Y-%m-%d %H:%M:%S").to_string());
    }
}
