use anyhow::Result;
use chrono::Local;
use log::{info, warn};
use scraper::{Html, Selector};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct JobListing {
    pub title: String,
    pub company: String,
    pub location: String,
    pub salary: Option<String>,
    pub url: String,
    pub date_posted: String,
    pub source: String,
    pub id: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ScholarshipListing {
    pub title: String,
    pub country: String,
    pub field: String,
    pub level: String,
    pub eligibility: String,
    pub deadline: Option<String>,
    pub url: String,
    pub source: String,
    pub id: String,
}

pub struct Scraper {
    client: reqwest::Client,
}

impl Scraper {
    pub fn new() -> Self {
        let client = reqwest::Client::builder()
            .user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
            .timeout(std::time::Duration::from_secs(30))
            .build()
            .unwrap_or_default();

        Scraper { client }
    }

    // ==================== JOB SCRAPERS ====================

    pub async fn search_all_jobs(&self) -> Vec<JobListing> {
        let mut all_jobs = Vec::new();

        info!("🔍 Searching RemoteOK for remote jobs...");
        match self.search_remoteok().await {
            Ok(jobs) => all_jobs.extend(jobs),
            Err(e) => warn!("RemoteOK error: {}", e),
        }

        info!("🔍 Searching JobGurus Nigeria...");
        match self.search_jobgurus_nigeria().await {
            Ok(jobs) => all_jobs.extend(jobs),
            Err(e) => warn!("JobGurus error: {}", e),
        }

        info!("🔍 Searching MyJobMag Nigeria...");
        match self.search_myjobmag().await {
            Ok(jobs) => all_jobs.extend(jobs),
            Err(e) => warn!("MyJobMag error: {}", e),
        }

        info!("🔍 Searching LinkedIn (public)...");
        match self.search_linkedin_public().await {
            Ok(jobs) => all_jobs.extend(jobs),
            Err(e) => warn!("LinkedIn error: {}", e),
        }

        info!("🔍 Searching Jobberman Nigeria...");
        match self.search_jobberman().await {
            Ok(jobs) => all_jobs.extend(jobs),
            Err(e) => warn!("Jobberman error: {}", e),
        }

        info!("✅ Total jobs found: {}", all_jobs.len());
        all_jobs
    }

    async fn search_remoteok(&self) -> Result<Vec<JobListing>> {
        let url = "https://remoteok.com/api";
        let response = self.client
            .get(url)
            .header("Accept", "application/json")
            .send()
            .await?;

        let text = response.text().await?;
        let jobs_json: serde_json::Value = serde_json::from_str(&text)?;

        let mut jobs = Vec::new();
        let keywords = ["network", "sysadmin", "network engineer", "network admin", "noc", "infrastructure", "devops"];

        if let Some(arr) = jobs_json.as_array() {
            for item in arr.iter().skip(1) {
                let title = item["position"].as_str().unwrap_or("").to_lowercase();
                let matches = keywords.iter().any(|k| title.contains(k));

                if matches {
                    let listing = JobListing {
                        title: item["position"].as_str().unwrap_or("Unknown").to_string(),
                        company: item["company"].as_str().unwrap_or("Unknown").to_string(),
                        location: item["location"].as_str().unwrap_or("Remote").to_string(),
                        salary: item["salary"].as_str().map(|s| s.to_string()),
                        url: format!("https://remoteok.com{}", item["url"].as_str().unwrap_or("")),
                        date_posted: item["date"].as_str().unwrap_or(&Local::now().to_string()).to_string(),
                        source: "RemoteOK".to_string(),
                        id: format!("remoteok_{}", item["id"].as_str().unwrap_or("")),
                    };
                    jobs.push(listing);
                }
            }
        }

        Ok(jobs)
    }

    async fn search_linkedin_public(&self) -> Result<Vec<JobListing>> {
        let searches = vec![
            ("network+administrator", "Nigeria"),
            ("network+engineer", "Nigeria"),
            ("network+administrator", "remote"),
            ("network+engineer", "remote"),
        ];

        let mut jobs = Vec::new();

        for (keyword, location) in searches {
            let url = format!(
                "https://www.linkedin.com/jobs/search/?keywords={}&location={}&f_WT=2",
                keyword, location
            );

            let response = self.client.get(&url).send().await;
            if let Ok(resp) = response {
                let html = resp.text().await.unwrap_or_default();
                let parsed = Html::parse_document(&html);

                let job_card = Selector::parse(".job-search-card").unwrap_or_else(|_| Selector::parse("div").unwrap());
                let title_sel = Selector::parse(".base-search-card__title").ok();
                let company_sel = Selector::parse(".base-search-card__subtitle").ok();
                let location_sel = Selector::parse(".job-search-card__location").ok();
                let link_sel = Selector::parse("a.base-card__full-link").ok();

                for card in parsed.select(&job_card).take(5) {
                    let title = title_sel.as_ref()
                        .and_then(|s| card.select(s).next())
                        .map(|e| e.text().collect::<String>().trim().to_string())
                        .unwrap_or_default();

                    if title.is_empty() { continue; }

                    let company = company_sel.as_ref()
                        .and_then(|s| card.select(s).next())
                        .map(|e| e.text().collect::<String>().trim().to_string())
                        .unwrap_or_else(|| "Unknown".to_string());

                    let loc = location_sel.as_ref()
                        .and_then(|s| card.select(s).next())
                        .map(|e| e.text().collect::<String>().trim().to_string())
                        .unwrap_or_else(|| location.to_string());

                    let job_url = link_sel.as_ref()
                        .and_then(|s| card.select(s).next())
                        .and_then(|e| e.value().attr("href"))
                        .unwrap_or("")
                        .to_string();

                    let id = format!("linkedin_{}_{}", keyword, job_url.len());
                    jobs.push(JobListing {
                        title,
                        company,
                        location: loc,
                        salary: None,
                        url: job_url,
                        date_posted: Local::now().format("%Y-%m-%d").to_string(),
                        source: "LinkedIn".to_string(),
                        id,
                    });
                }
            }
        }

        Ok(jobs)
    }

    async fn search_jobgurus_nigeria(&self) -> Result<Vec<JobListing>> {
        let searches = vec![
            "https://www.jobgurus.com.ng/search?q=network+administrator",
            "https://www.jobgurus.com.ng/search?q=network+engineer",
            "https://www.jobgurus.com.ng/search?q=IT+administrator",
        ];

        let mut jobs = Vec::new();

        for url in searches {
            let response = self.client.get(url).send().await;
            if let Ok(resp) = response {
                let html = resp.text().await.unwrap_or_default();
                let parsed = Html::parse_document(&html);

                let card_sel = Selector::parse(".job-item, .job-listing, .job-card, article").ok();
                if let Some(sel) = card_sel {
                    for card in parsed.select(&sel).take(5) {
                        let text: String = card.text().collect::<Vec<_>>().join(" ");
                        if text.contains("network") || text.contains("administrator") || text.contains("engineer") {
                            let title_sel = Selector::parse("h2, h3, .title, .job-title").ok();
                            let title = title_sel.as_ref()
                                .and_then(|s| card.select(s).next())
                                .map(|e| e.text().collect::<String>().trim().to_string())
                                .unwrap_or_else(|| "Network Position".to_string());

                            let link_sel = Selector::parse("a").ok();
                            let job_url = link_sel.as_ref()
                                .and_then(|s| card.select(s).next())
                                .and_then(|e| e.value().attr("href"))
                                .map(|h| {
                                    if h.starts_with("http") {
                                        h.to_string()
                                    } else {
                                        format!("https://www.jobgurus.com.ng{}", h)
                                    }
                                })
                                .unwrap_or_else(|| url.to_string());

                            jobs.push(JobListing {
                                title,
                                company: "See listing".to_string(),
                                location: "Nigeria".to_string(),
                                salary: None,
                                url: job_url,
                                date_posted: Local::now().format("%Y-%m-%d").to_string(),
                                source: "JobGurus NG".to_string(),
                                id: format!("jobgurus_{}", jobs.len()),
                            });
                        }
                    }
                }
            }
        }

        Ok(jobs)
    }

    async fn search_myjobmag(&self) -> Result<Vec<JobListing>> {
        let urls = vec![
            "https://www.myjobmag.com/find-jobs/network-administrator-jobs-in-nigeria",
            "https://www.myjobmag.com/find-jobs/network-engineer-jobs-in-nigeria",
            "https://www.myjobmag.com/find-jobs/it-engineer-jobs-in-nigeria",
        ];

        let mut jobs = Vec::new();

        for url in urls {
            let response = self.client.get(url).send().await;
            if let Ok(resp) = response {
                let html = resp.text().await.unwrap_or_default();
                let parsed = Html::parse_document(&html);

                let card_sel = Selector::parse(".job-list-item, .job-item, .jobs-list article").ok();
                if let Some(sel) = card_sel {
                    for card in parsed.select(&sel).take(5) {
                        let title_sel = Selector::parse("h2 a, h3 a, .job-name a").ok();
                        let title = title_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .map(|e| e.text().collect::<String>().trim().to_string())
                            .unwrap_or_default();

                        if title.is_empty() { continue; }

                        let company_sel = Selector::parse(".company-name, .employer").ok();
                        let company = company_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .map(|e| e.text().collect::<String>().trim().to_string())
                            .unwrap_or_else(|| "See listing".to_string());

                        let link_sel = Selector::parse("h2 a, h3 a, .job-name a").ok();
                        let job_url = link_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .and_then(|e| e.value().attr("href"))
                            .map(|h| {
                                if h.starts_with("http") {
                                    h.to_string()
                                } else {
                                    format!("https://www.myjobmag.com{}", h)
                                }
                            })
                            .unwrap_or_else(|| url.to_string());

                        jobs.push(JobListing {
                            title,
                            company,
                            location: "Nigeria".to_string(),
                            salary: None,
                            url: job_url,
                            date_posted: Local::now().format("%Y-%m-%d").to_string(),
                            source: "MyJobMag NG".to_string(),
                            id: format!("myjobmag_{}", jobs.len()),
                        });
                    }
                }
            }
        }

        Ok(jobs)
    }

    async fn search_jobberman(&self) -> Result<Vec<JobListing>> {
        let urls = vec![
            "https://www.jobberman.com/jobs/network-engineering",
            "https://www.jobberman.com/jobs/it-and-telecoms",
        ];

        let mut jobs = Vec::new();

        for url in urls {
            let response = self.client.get(url).send().await;
            if let Ok(resp) = response {
                let html = resp.text().await.unwrap_or_default();
                let parsed = Html::parse_document(&html);

                let card_sel = Selector::parse("article.job-card, .job-listing-card").ok();
                if let Some(sel) = card_sel {
                    for card in parsed.select(&sel).take(5) {
                        let title_sel = Selector::parse("h3, h2, .job-title").ok();
                        let title = title_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .map(|e| e.text().collect::<String>().trim().to_string())
                            .unwrap_or_default();

                        if title.is_empty() { continue; }

                        let title_lower = title.to_lowercase();
                        let relevant = title_lower.contains("network")
                            || title_lower.contains("admin")
                            || title_lower.contains("engineer")
                            || title_lower.contains("noc")
                            || title_lower.contains("infrastructure");

                        if !relevant { continue; }

                        let company_sel = Selector::parse(".company, .employer-name").ok();
                        let company = company_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .map(|e| e.text().collect::<String>().trim().to_string())
                            .unwrap_or_else(|| "See listing".to_string());

                        let link_sel = Selector::parse("a").ok();
                        let job_url = link_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .and_then(|e| e.value().attr("href"))
                            .map(|h| {
                                if h.starts_with("http") {
                                    h.to_string()
                                } else {
                                    format!("https://www.jobberman.com{}", h)
                                }
                            })
                            .unwrap_or_else(|| url.to_string());

                        jobs.push(JobListing {
                            title,
                            company,
                            location: "Nigeria".to_string(),
                            salary: None,
                            url: job_url,
                            date_posted: Local::now().format("%Y-%m-%d").to_string(),
                            source: "Jobberman NG".to_string(),
                            id: format!("jobberman_{}", jobs.len()),
                        });
                    }
                }
            }
        }

        Ok(jobs)
    }

    // ==================== SCHOLARSHIP SCRAPERS ====================

    pub async fn search_all_scholarships(&self) -> Vec<ScholarshipListing> {
        let mut all_scholarships = Vec::new();

        info!("🎓 Searching ScholarshipPortal...");
        match self.search_scholarshipportal().await {
            Ok(s) => all_scholarships.extend(s),
            Err(e) => warn!("ScholarshipPortal error: {}", e),
        }

        info!("🎓 Searching ScholarshipsForAfricans...");
        match self.search_scholarships_for_africans().await {
            Ok(s) => all_scholarships.extend(s),
            Err(e) => warn!("ScholarshipsForAfricans error: {}", e),
        }

        info!("🎓 Searching Afterschoolafrica...");
        match self.search_afterschool_africa().await {
            Ok(s) => all_scholarships.extend(s),
            Err(e) => warn!("AfterSchoolAfrica error: {}", e),
        }

        info!("🎓 Searching Opportunitiesforafricans...");
        match self.search_opportunities_for_africans().await {
            Ok(s) => all_scholarships.extend(s),
            Err(e) => warn!("OpportunitiesForAfricans error: {}", e),
        }

        info!("✅ Total scholarships found: {}", all_scholarships.len());
        all_scholarships
    }

    async fn search_scholarshipportal(&self) -> Result<Vec<ScholarshipListing>> {
        let urls = vec![
            "https://www.scholarshipportal.com/scholarships/search?q=cybersecurity&degree=MASTER",
            "https://www.scholarshipportal.com/scholarships/search?q=information+technology&degree=MASTER",
        ];

        let mut scholarships = Vec::new();

        for url in urls {
            let response = self.client.get(url).send().await;
            if let Ok(resp) = response {
                let html = resp.text().await.unwrap_or_default();
                let parsed = Html::parse_document(&html);

                let card_sel = Selector::parse(".scholarship-card, .program-card, article").ok();
                if let Some(sel) = card_sel {
                    for card in parsed.select(&sel).take(5) {
                        let title_sel = Selector::parse("h2, h3, .title, .program-title").ok();
                        let title = title_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .map(|e| e.text().collect::<String>().trim().to_string())
                            .unwrap_or_default();

                        if title.is_empty() { continue; }

                        let link_sel = Selector::parse("a").ok();
                        let scholarship_url = link_sel.as_ref()
                            .and_then(|s| card.select(s).next())
                            .and_then(|e| e.value().attr("href"))
                            .map(|h| {
                                if h.starts_with("http") {
                                    h.to_string()
                                } else {
                                    format!("https://www.scholarshipportal.com{}", h)
                                }
                            })
                            .unwrap_or_else(|| url.to_string());

                        scholarships.push(ScholarshipListing {
                            title,
                            country: "Various".to_string(),
                            field: "Cybersecurity / IT".to_string(),
                            level: "Masters".to_string(),
                            eligibility: "Check website for Nigerian eligibility".to_string(),
                            deadline: None,
                            url: scholarship_url,
                            source: "ScholarshipPortal".to_string(),
                            id: format!("sp_{}", scholarships.len()),
                        });
                    }
                }
            }
        }

        Ok(scholarships)
    }

    async fn search_scholarships_for_africans(&self) -> Result<Vec<ScholarshipListing>> {
        let url = "https://www.scholarshipsforafricans.com/category/nigerian-scholarships/";

        let response = self.client.get(url).send().await?;
        let html = response.text().await?;
        let parsed = Html::parse_document(&html);

        let mut scholarships = Vec::new();

        let card_sel = Selector::parse("article, .post, .scholarship-entry").ok();
        if let Some(sel) = card_sel {
            for card in parsed.select(&sel).take(8) {
                let title_sel = Selector::parse("h2 a, h3 a, .entry-title a").ok();
                let title_el = title_sel.as_ref().and_then(|s| card.select(s).next());

                let title = title_el
                    .map(|e| e.text().collect::<String>().trim().to_string())
                    .unwrap_or_default();

                if title.is_empty() { continue; }

                let title_lower = title.to_lowercase();
                let relevant = title_lower.contains("cyber")
                    || title_lower.contains("technology")
                    || title_lower.contains("computer")
                    || title_lower.contains("engineer")
                    || title_lower.contains("master")
                    || title_lower.contains("it ")
                    || title_lower.contains("stem");

                let scholarship_url = title_el
                    .and_then(|e| e.value().attr("href"))
                    .unwrap_or(url)
                    .to_string();

                let text_content: String = card.text().collect::<Vec<_>>().join(" ").to_lowercase();
                let country = if text_content.contains("uk") || text_content.contains("united kingdom") {
                    "United Kingdom"
                } else if text_content.contains("usa") || text_content.contains("united states") {
                    "United States"
                } else if text_content.contains("canada") {
                    "Canada"
                } else if text_content.contains("germany") {
                    "Germany"
                } else if text_content.contains("australia") {
                    "Australia"
                } else {
                    "Abroad"
                };

                if relevant || !title.is_empty() {
                    scholarships.push(ScholarshipListing {
                        title,
                        country: country.to_string(),
                        field: "Cybersecurity / IT / STEM".to_string(),
                        level: "Masters / Postgraduate".to_string(),
                        eligibility: "Open to Nigerians".to_string(),
                        deadline: None,
                        url: scholarship_url,
                        source: "ScholarshipsForAfricans".to_string(),
                        id: format!("sfa_{}", scholarships.len()),
                    });
                }
            }
        }

        Ok(scholarships)
    }

    async fn search_afterschool_africa(&self) -> Result<Vec<ScholarshipListing>> {
        let url = "https://afterscholafrica.com/scholarships/";

        let response = self.client.get(url).send().await?;
        let html = response.text().await?;
        let parsed = Html::parse_document(&html);

        let mut scholarships = Vec::new();

        let card_sel = Selector::parse("article, .scholarship-post, .entry").ok();
        if let Some(sel) = card_sel {
            for card in parsed.select(&sel).take(6) {
                let title_sel = Selector::parse("h2 a, h3 a, .title a").ok();
                let title_el = title_sel.as_ref().and_then(|s| card.select(s).next());
                let title = title_el
                    .map(|e| e.text().collect::<String>().trim().to_string())
                    .unwrap_or_default();

                if title.is_empty() { continue; }

                let scholarship_url = title_el
                    .and_then(|e| e.value().attr("href"))
                    .unwrap_or(url)
                    .to_string();

                scholarships.push(ScholarshipListing {
                    title,
                    country: "Abroad".to_string(),
                    field: "Various (incl. Cybersecurity/IT)".to_string(),
                    level: "Masters".to_string(),
                    eligibility: "Check for Nigerian eligibility".to_string(),
                    deadline: None,
                    url: scholarship_url,
                    source: "AfterSchoolAfrica".to_string(),
                    id: format!("asa_{}", scholarships.len()),
                });
            }
        }

        Ok(scholarships)
    }

    async fn search_opportunities_for_africans(&self) -> Result<Vec<ScholarshipListing>> {
        let urls = vec![
            "https://opportunitiesforafricans.com/scholarships/",
            "https://opportunitiesforafricans.com/category/scholarships/",
        ];

        let mut scholarships = Vec::new();

        for url in urls {
            let response = self.client.get(url).send().await;
            if let Ok(resp) = response {
                let html = resp.text().await.unwrap_or_default();
                let parsed = Html::parse_document(&html);

                let card_sel = Selector::parse("article, .post, .entry").ok();
                if let Some(sel) = card_sel {
                    for card in parsed.select(&sel).take(5) {
                        let title_sel = Selector::parse("h2 a, h3 a, .entry-title a").ok();
                        let title_el = title_sel.as_ref().and_then(|s| card.select(s).next());
                        let title = title_el
                            .map(|e| e.text().collect::<String>().trim().to_string())
                            .unwrap_or_default();

                        if title.is_empty() { continue; }

                        let scholarship_url = title_el
                            .and_then(|e| e.value().attr("href"))
                            .unwrap_or(url)
                            .to_string();

                        scholarships.push(ScholarshipListing {
                            title,
                            country: "Abroad".to_string(),
                            field: "Various incl. IT/Cybersecurity".to_string(),
                            level: "Masters / Postgraduate".to_string(),
                            eligibility: "Africans / Nigerians eligible".to_string(),
                            deadline: None,
                            url: scholarship_url,
                            source: "OpportunitiesForAfricans".to_string(),
                            id: format!("ofa_{}", scholarships.len()),
                        });
                    }
                }
            }
        }

        Ok(scholarships)
    }
}
