use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use anyhow::Result;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Config {
    pub telegram: TelegramConfig,
    pub schedule: ScheduleConfig,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct TelegramConfig {
    pub bot_token: String,
    pub chat_id: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ScheduleConfig {
    pub job_interval_hours: u64,
    pub scholarship_interval_hours: u64,
}

impl Default for Config {
    fn default() -> Self {
        Config {
            telegram: TelegramConfig {
                bot_token: String::from("YOUR_BOT_TOKEN_HERE"),
                chat_id: String::from("YOUR_CHAT_ID_HERE"),
            },
            schedule: ScheduleConfig {
                job_interval_hours: 2,
                scholarship_interval_hours: 24,
            },
        }
    }
}

impl Config {
    pub fn config_path() -> PathBuf {
        let config_dir = dirs::config_dir().unwrap_or_else(|| PathBuf::from("."));
        config_dir.join("NigeriaJobScout").join("config.json")
    }

    pub fn load() -> Result<Self> {
        let path = Self::config_path();
        if path.exists() {
            let content = std::fs::read_to_string(&path)?;
            let config: Config = serde_json::from_str(&content)?;
            Ok(config)
        } else {
            let config = Config::default();
            config.save()?;
            Ok(config)
        }
    }

    pub fn save(&self) -> Result<()> {
        let path = Self::config_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let content = serde_json::to_string_pretty(self)?;
        std::fs::write(&path, content)?;
        Ok(())
    }

    pub fn is_configured(&self) -> bool {
        self.telegram.bot_token != "YOUR_BOT_TOKEN_HERE"
            && self.telegram.chat_id != "YOUR_CHAT_ID_HERE"
    }
}
