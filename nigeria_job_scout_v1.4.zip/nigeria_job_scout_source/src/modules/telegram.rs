use anyhow::Result;
use log::{info, error};
use crate::modules::config::TelegramConfig;

pub struct TelegramBot {
    config: TelegramConfig,
    client: reqwest::Client,
}

impl TelegramBot {
    pub fn new(config: TelegramConfig) -> Self {
        TelegramBot {
            config,
            client: reqwest::Client::new(),
        }
    }

    pub async fn send_message(&self, text: &str) -> Result<()> {
        let url = format!(
            "https://api.telegram.org/bot{}/sendMessage",
            self.config.bot_token
        );

        let payload = serde_json::json!({
            "chat_id": self.config.chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": false
        });

        let response = self.client
            .post(&url)
            .json(&payload)
            .send()
            .await?;

        if response.status().is_success() {
            info!("Telegram message sent successfully");
        } else {
            let err_text = response.text().await?;
            error!("Telegram error: {}", err_text);
        }

        Ok(())
    }

    pub async fn send_job_alert(&self, jobs: &[crate::modules::scraper::JobListing]) -> Result<()> {
        if jobs.is_empty() {
            return Ok(());
        }

        let header = format!(
            "🔔 <b>NIGERIA JOB SCOUT - {} New Job(s) Found!</b>\n{}\n\n",
            jobs.len(),
            "=".repeat(30)
        );

        let mut messages = vec![header];
        let mut current_msg = messages[0].clone();
        messages.clear();

        for (i, job) in jobs.iter().enumerate() {
            let job_text = format!(
                "💼 <b>{}</b>\n🏢 Company: {}\n📍 Location: {}\n💰 Salary: {}\n🔗 <a href=\"{}\">Apply Here</a>\n📅 Posted: {}\n\n",
                job.title,
                job.company,
                job.location,
                job.salary.as_deref().unwrap_or("Not specified"),
                job.url,
                job.date_posted
            );

            // Telegram max message size is 4096 chars
            if current_msg.len() + job_text.len() > 3800 {
                messages.push(current_msg.clone());
                current_msg = format!("📋 Jobs (continued {}/{}):\n\n", i + 1, jobs.len());
            }
            current_msg.push_str(&job_text);
        }

        if !current_msg.is_empty() {
            messages.push(current_msg);
        }

        for msg in &messages {
            self.send_message(msg).await?;
            tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
        }

        Ok(())
    }

    pub async fn send_scholarship_alert(
        &self,
        scholarships: &[crate::modules::scraper::ScholarshipListing],
    ) -> Result<()> {
        if scholarships.is_empty() {
            return Ok(());
        }

        let header = format!(
            "🎓 <b>NIGERIA JOB SCOUT - {} New Scholarship(s) Found!</b>\n{}\n\n",
            scholarships.len(),
            "=".repeat(30)
        );

        let mut current_msg = header;

        for (i, s) in scholarships.iter().enumerate() {
            let text = format!(
                "🏛 <b>{}</b>\n🌍 Country: {}\n📚 Field: {}\n🎯 Level: {}\n📋 Eligibility: {}\n⏰ Deadline: {}\n🔗 <a href=\"{}\">Apply Here</a>\n\n",
                s.title,
                s.country,
                s.field,
                s.level,
                s.eligibility,
                s.deadline.as_deref().unwrap_or("Check website"),
                s.url
            );

            if current_msg.len() + text.len() > 3800 {
                self.send_message(&current_msg).await?;
                tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
                current_msg = format!("🎓 Scholarships (continued {}/{}):\n\n", i + 1, scholarships.len());
            }
            current_msg.push_str(&text);
        }

        if !current_msg.is_empty() {
            self.send_message(&current_msg).await?;
        }

        Ok(())
    }

    pub async fn send_startup_message(&self) -> Result<()> {
        let msg = "🤖 <b>Nigeria Job Scout is now RUNNING!</b>\n\n\
            ✅ Job search: every 2 hours\n\
            ✅ Scholarship search: every 24 hours\n\
            🔍 Searching for: Network Admin, Network Engineer, IT jobs\n\
            🎓 Searching for: Masters scholarships in Cybersecurity/IT\n\
            🌍 Locations: Nigeria + Remote + Abroad\n\n\
            You'll receive alerts when new opportunities are found. Good luck! 🇳🇬";
        self.send_message(msg).await
    }

    pub async fn send_no_results_message(&self, search_type: &str) -> Result<()> {
        let msg = format!(
            "ℹ️ <b>Nigeria Job Scout</b>\n\nNo new {} found in this scan. Will check again soon! 🔄",
            search_type
        );
        self.send_message(&msg).await
    }

    /// Get your chat ID - call this during setup
    pub async fn get_updates(&self) -> Result<String> {
        let url = format!(
            "https://api.telegram.org/bot{}/getUpdates",
            self.config.bot_token
        );
        let response = self.client.get(&url).send().await?;
        let text = response.text().await?;
        Ok(text)
    }
}
