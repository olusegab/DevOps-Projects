use anyhow::Result;
use log::info;
use std::sync::Arc;
use tokio::sync::Mutex;
use tokio::time::{interval, Duration};

use crate::modules::cache::SeenCache;
use crate::modules::config::Config;
use crate::modules::scraper::Scraper;
use crate::modules::telegram::TelegramBot;

pub struct Scheduler {
    config: Config,
}

impl Scheduler {
    pub fn new(config: Config) -> Self {
        Scheduler { config }
    }

    pub async fn run(&self) -> Result<()> {
        let config = self.config.clone();
        let cache = Arc::new(Mutex::new(SeenCache::load()));
        let scraper = Arc::new(Scraper::new());
        let bot = Arc::new(TelegramBot::new(config.telegram.clone()));

        // Send startup notification
        if let Err(e) = bot.send_startup_message().await {
            log::warn!("Could not send startup message: {}", e);
        }

        let job_hours = config.schedule.job_interval_hours;
        let scholarship_hours = config.schedule.scholarship_interval_hours;

        info!(
            "⏰ Scheduler started: Jobs every {}h | Scholarships every {}h",
            job_hours, scholarship_hours
        );

        // Run both searches immediately on startup
        {
            let scraper = Arc::clone(&scraper);
            let bot = Arc::clone(&bot);
            let cache = Arc::clone(&cache);
            run_job_search(&scraper, &bot, &cache).await;
        }
        {
            let scraper = Arc::clone(&scraper);
            let bot = Arc::clone(&bot);
            let cache = Arc::clone(&cache);
            run_scholarship_search(&scraper, &bot, &cache).await;
        }

        // Spawn job search loop
        let scraper_j = Arc::clone(&scraper);
        let bot_j = Arc::clone(&bot);
        let cache_j = Arc::clone(&cache);
        let job_task = tokio::spawn(async move {
            let mut ticker = interval(Duration::from_secs(job_hours * 3600));
            ticker.tick().await; // Skip first tick (already ran above)
            loop {
                ticker.tick().await;
                info!("⏰ Job search timer fired");
                run_job_search(&scraper_j, &bot_j, &cache_j).await;
            }
        });

        // Spawn scholarship search loop
        let scraper_s = Arc::clone(&scraper);
        let bot_s = Arc::clone(&bot);
        let cache_s = Arc::clone(&cache);
        let scholarship_task = tokio::spawn(async move {
            let mut ticker = interval(Duration::from_secs(scholarship_hours * 3600));
            ticker.tick().await; // Skip first tick (already ran above)
            loop {
                ticker.tick().await;
                info!("⏰ Scholarship search timer fired");
                run_scholarship_search(&scraper_s, &bot_s, &cache_s).await;
            }
        });

        // Wait forever (both loops run indefinitely)
        let _ = tokio::join!(job_task, scholarship_task);

        Ok(())
    }
}

async fn run_job_search(
    scraper: &Arc<Scraper>,
    bot: &Arc<TelegramBot>,
    cache: &Arc<Mutex<SeenCache>>,
) {
    info!("🔍 Starting job search scan...");

    let all_jobs = scraper.search_all_jobs().await;

    let mut cache_guard = cache.lock().await;
    let new_jobs: Vec<_> = all_jobs
        .into_iter()
        .filter(|j| cache_guard.is_new_job(&j.id))
        .collect();

    for job in &new_jobs {
        cache_guard.mark_job_seen(&job.id);
    }
    cache_guard.update_job_scan_time();
    let _ = cache_guard.save();
    drop(cache_guard);

    info!("✅ {} new jobs found", new_jobs.len());

    if new_jobs.is_empty() {
        info!("No new jobs — skipping Telegram notification");
    } else {
        if let Err(e) = bot.send_job_alert(&new_jobs).await {
            log::error!("Failed to send job alert: {}", e);
        }
    }
}

async fn run_scholarship_search(
    scraper: &Arc<Scraper>,
    bot: &Arc<TelegramBot>,
    cache: &Arc<Mutex<SeenCache>>,
) {
    info!("🎓 Starting scholarship search scan...");

    let all_scholarships = scraper.search_all_scholarships().await;

    let mut cache_guard = cache.lock().await;
    let new_scholarships: Vec<_> = all_scholarships
        .into_iter()
        .filter(|s| cache_guard.is_new_scholarship(&s.id))
        .collect();

    for s in &new_scholarships {
        cache_guard.mark_scholarship_seen(&s.id);
    }
    cache_guard.update_scholarship_scan_time();
    let _ = cache_guard.save();
    drop(cache_guard);

    info!("✅ {} new scholarships found", new_scholarships.len());

    if new_scholarships.is_empty() {
        info!("No new scholarships — skipping Telegram notification");
    } else {
        if let Err(e) = bot.send_scholarship_alert(&new_scholarships).await {
            log::error!("Failed to send scholarship alert: {}", e);
        }
    }
}
