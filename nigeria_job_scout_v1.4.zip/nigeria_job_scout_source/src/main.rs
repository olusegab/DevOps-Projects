mod modules;

use anyhow::Result;
use log::info;
use std::io::{self, Write};

use modules::config::Config;
use modules::scheduler::Scheduler;
use modules::telegram::TelegramBot;

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::Builder::from_env(
        env_logger::Env::default().default_filter_or("info"),
    )
    .format_timestamp_secs()
    .init();

    print_banner();

    let mut config = Config::load()?;

    if !config.is_configured() {
        config = run_setup_wizard(config).await?;
    }

    let args: Vec<String> = std::env::args().collect();
    if args.len() > 1 {
        match args[1].as_str() {
            "--setup" => { config = run_setup_wizard(config).await?; }
            "--test" => { run_test(&config).await?; return Ok(()); }
            "--get-chat-id" => { get_chat_id(&config).await?; return Ok(()); }
            "--help" | "-h" => { print_help(); return Ok(()); }
            _ => { println!("Unknown argument. Use --help for options."); }
        }
    }

    info!("Nigeria Job Scout starting...");
    info!("Config: {}", Config::config_path().display());

    let scheduler = Scheduler::new(config);
    scheduler.run().await?;

    Ok(())
}

fn print_banner() {
    println!(r#"
+----------------------------------------------------------+
|          NIGERIA JOB SCOUT v1.0.0                        |
|  Automated Job & Scholarship Finder via Telegram         |
|  * Remote Network Admin / Engineer Jobs (every 2h)      |
|  * Masters Scholarships Cybersecurity/IT (every 24h)    |
+----------------------------------------------------------+
"#);
}

fn print_help() {
    println!("USAGE: nigeria_job_scout [OPTIONS]");
    println!();
    println!("  (no args)       Start the scout (runs continuously)");
    println!("  --setup         Re-run the setup wizard");
    println!("  --test          Send a test message to Telegram");
    println!("  --get-chat-id   Fetch your Telegram chat ID");
    println!("  --help          Show this help");
}

async fn run_setup_wizard(mut config: Config) -> Result<Config> {
    println!("=== SETUP WIZARD ===");
    println!();
    println!("Step 1: Open Telegram and search for @BotFather");
    println!("Step 2: Send /newbot and follow the instructions");
    println!("Step 3: Copy the bot token BotFather gives you");
    println!("Step 4: Send /start to your new bot");
    println!();

    print!("Enter your Telegram Bot Token: ");
    io::stdout().flush()?;
    let mut token = String::new();
    io::stdin().read_line(&mut token)?;
    let token = token.trim().to_string();

    if token.is_empty() {
        println!("No token entered. Re-run --setup when ready.");
        return Ok(config);
    }

    config.telegram.bot_token = token;

    let bot = TelegramBot::new(config.telegram.clone());
    println!("Fetching your Chat ID from Telegram...");

    match bot.get_updates().await {
        Ok(updates) => {
            if let Ok(json) = serde_json::from_str::<serde_json::Value>(&updates) {
                let chat_id = json["result"]
                    .as_array()
                    .and_then(|arr| arr.last())
                    .and_then(|msg| msg["message"]["chat"]["id"].as_i64());

                if let Some(id) = chat_id {
                    println!("Auto-detected Chat ID: {}", id);
                    config.telegram.chat_id = id.to_string();
                } else {
                    print!("Enter Chat ID manually: ");
                    io::stdout().flush()?;
                    let mut chat_id = String::new();
                    io::stdin().read_line(&mut chat_id)?;
                    config.telegram.chat_id = chat_id.trim().to_string();
                }
            }
        }
        Err(_) => {
            print!("Enter Chat ID manually: ");
            io::stdout().flush()?;
            let mut chat_id = String::new();
            io::stdin().read_line(&mut chat_id)?;
            config.telegram.chat_id = chat_id.trim().to_string();
        }
    }

    config.save()?;
    println!("Config saved to: {}", Config::config_path().display());

    let bot = TelegramBot::new(config.telegram.clone());
    match bot.send_message("Nigeria Job Scout setup complete! You will receive job and scholarship alerts here.").await {
        Ok(_) => println!("Test message sent! Check your Telegram."),
        Err(e) => println!("Could not send test message: {}. Check your settings.", e),
    }

    Ok(config)
}

async fn run_test(config: &Config) -> Result<()> {
    let bot = TelegramBot::new(config.telegram.clone());
    bot.send_message("Test message from Nigeria Job Scout. Your setup is working!").await?;
    println!("Test message sent! Check your Telegram.");
    Ok(())
}

async fn get_chat_id(config: &Config) -> Result<()> {
    let bot = TelegramBot::new(config.telegram.clone());
    let updates = bot.get_updates().await?;

    if let Ok(json) = serde_json::from_str::<serde_json::Value>(&updates) {
        let chat_id = json["result"]
            .as_array()
            .and_then(|arr| arr.last())
            .and_then(|msg| msg["message"]["chat"]["id"].as_i64());

        match chat_id {
            Some(id) => println!("Your Chat ID: {}", id),
            None => println!("No messages found. Send /start to your bot first."),
        }
    }
    Ok(())
}
