@echo off
REM Silent launcher - runs Nigeria Job Scout in background with no visible window
REM Place this in your Startup folder for auto-start on boot

start "" /B "%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe" > "%APPDATA%\NigeriaJobScout\scout.log" 2>&1
