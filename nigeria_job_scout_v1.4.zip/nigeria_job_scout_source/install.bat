@echo off
title Nigeria Job Scout - Installer
color 0A
cls

echo.
echo  +----------------------------------------------------------+
echo  ^|          NIGERIA JOB SCOUT v1.0.0                        ^|
echo  ^|  Automated Job ^& Scholarship Finder via Telegram         ^|
echo  +----------------------------------------------------------+
echo.

REM Check if already installed
if exist "%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe" (
    echo [INFO] Nigeria Job Scout is already installed.
    echo.
    echo  What would you like to do?
    echo  [1] Run Nigeria Job Scout now
    echo  [2] Re-configure (setup wizard)
    echo  [3] Send a test Telegram message
    echo  [4] Add to Windows Startup (auto-run on boot)
    echo  [5] Remove from Windows Startup
    echo  [6] Uninstall
    echo  [7] Exit
    echo.
    set /p choice="Enter your choice (1-7): "

    if "%choice%"=="1" goto RUN
    if "%choice%"=="2" goto SETUP
    if "%choice%"=="3" goto TEST
    if "%choice%"=="4" goto ADD_STARTUP
    if "%choice%"=="5" goto REMOVE_STARTUP
    if "%choice%"=="6" goto UNINSTALL
    if "%choice%"=="7" exit
    goto RUN
)

REM First time install
echo [INSTALL] Installing Nigeria Job Scout...
echo.

REM Create install directory
mkdir "%APPDATA%\NigeriaJobScout" 2>nul

REM Copy the executable
copy /Y "nigeria_job_scout.exe" "%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Could not copy executable. Make sure nigeria_job_scout.exe is in the same folder as this script.
    pause
    exit /b 1
)

REM Copy config if exists
if exist "config.json" (
    mkdir "%APPDATA%\NigeriaJobScout\NigeriaJobScout" 2>nul
    copy /Y "config.json" "%LOCALAPPDATA%\NigeriaJobScout\config.json" >nul 2>&1
)

echo [OK] Installed to: %APPDATA%\NigeriaJobScout\
echo.

REM Create desktop shortcut
echo [INFO] Creating Desktop shortcut...
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%USERPROFILE%\Desktop\Nigeria Job Scout.lnk'); $s.TargetPath = '%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe'; $s.WorkingDirectory = '%APPDATA%\NigeriaJobScout'; $s.IconLocation = '%SystemRoot%\System32\shell32.dll,23'; $s.Description = 'Nigeria Job Scout - Job & Scholarship Finder'; $s.Save()"
echo [OK] Desktop shortcut created.
echo.

:SETUP
echo [SETUP] Running setup wizard...
echo.
"%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe" --setup
if errorlevel 1 (
    echo [ERROR] Setup failed. Check your bot token and chat ID.
    pause
    exit /b 1
)
echo.
echo [OK] Setup complete!
echo.

:ADD_STARTUP
echo [INFO] Adding to Windows Startup...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NigeriaJobScout" /t REG_SZ /d "\"%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe\"" /f >nul
echo [OK] Nigeria Job Scout will now start automatically when Windows boots.
echo.
goto RUN

:RUN
echo [RUN] Starting Nigeria Job Scout...
echo.
echo  The scout is now running in the background.
echo  You will receive Telegram alerts for:
echo    * New Network Admin / Engineer jobs (every 2 hours)
echo    * New Masters Scholarships in Cybersecurity/IT (every 24 hours)
echo.
echo  Close this window to stop the scout.
echo  Check the log output below for status:
echo  -----------------------------------------------
echo.
"%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe"
pause
exit /b

:TEST
echo [TEST] Sending test message to your Telegram...
"%APPDATA%\NigeriaJobScout\nigeria_job_scout.exe" --test
pause
exit /b

:REMOVE_STARTUP
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NigeriaJobScout" /f >nul 2>&1
echo [OK] Removed from Windows Startup.
pause
exit /b

:UNINSTALL
echo [UNINSTALL] Removing Nigeria Job Scout...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NigeriaJobScout" /f >nul 2>&1
del "%USERPROFILE%\Desktop\Nigeria Job Scout.lnk" >nul 2>&1
rmdir /s /q "%APPDATA%\NigeriaJobScout" >nul 2>&1
echo [OK] Nigeria Job Scout has been uninstalled.
pause
exit /b
