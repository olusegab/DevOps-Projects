import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { useAuthStore } from "./store";
import Layout       from "./components/Layout";
import Player       from "./components/Player";
import Home         from "./pages/Home";
import Search       from "./pages/Search";
import Library      from "./pages/Library";
import PlaylistPage from "./pages/PlaylistPage";
import LikedSongs   from "./pages/LikedSongs";
import History      from "./pages/History";
import Upload       from "./pages/Upload";
import ArtistPage   from "./pages/ArtistPage";
import AlbumPage    from "./pages/AlbumPage";
import Admin        from "./pages/Admin";
import Login        from "./pages/Login";
import Register     from "./pages/Register";
import Profile      from "./pages/Profile";

const Private = ({ children }) => {
  const token = useAuthStore(s => s.token);
  return token ? children : <Navigate to="/login" replace />;
};
const AdminRoute = ({ children }) => {
  const { user, token } = useAuthStore();
  if (!token) return <Navigate to="/login" replace />;
  if (!["admin","superadmin"].includes(user?.role)) return <Navigate to="/" replace />;
  return children;
};

export default function App() {
  const { token, refreshUser } = useAuthStore();
  useEffect(() => { if (token) refreshUser(); }, []);

  return (
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{
        style: { background:"#1a1a26", color:"#f0f0ff", border:"1px solid #2a2a3e" },
        success: { iconTheme: { primary:"#22c55e", secondary:"#1a1a26" }},
        error:   { iconTheme: { primary:"#ef4444", secondary:"#1a1a26" }},
      }} />
      <Routes>
        <Route path="/login"    element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/" element={<Private><Layout /></Private>}>
          <Route index                  element={<Home />} />
          <Route path="search"          element={<Search />} />
          <Route path="library"         element={<Library />} />
          <Route path="playlist/:id"    element={<PlaylistPage />} />
          <Route path="liked"           element={<LikedSongs />} />
          <Route path="history"         element={<History />} />
          <Route path="upload"          element={<AdminRoute><Upload /></AdminRoute>} />
          <Route path="artist/:name"    element={<ArtistPage />} />
          <Route path="album/:name"     element={<AlbumPage />} />
          <Route path="profile"         element={<Profile />} />
          <Route path="submit-music"     element={<SubmitMusic />} />
          <Route path="mood"             element={<MoodPlayer />} />
          <Route path="admin"           element={<AdminRoute><Admin /></AdminRoute>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
