import React, { useState, useEffect } from "react";
import { Outlet, NavLink, Link, useNavigate } from "react-router-dom";
import {
  Home, Search, Library, Heart, Clock, Upload,
  Settings, LogOut, Music, Plus, Menu, X, Shield, ListMusic, Music2, Sparkles
} from "lucide-react";
import { useAuthStore, usePlayerStore } from "../store";
import { usePWAInstall, useOnlineStatus } from "../hooks/usePWA";
import toast from "react-hot-toast";
import Player from "./Player";
import api from "../utils/api";
import toast from "react-hot-toast";

export default function Layout() {
  const { user, logout, isAdmin } = useAuthStore();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen]   = useState(false);
  const [playlists, setPlaylists]       = useState([]);
  const [showNewPL, setShowNewPL]       = useState(false);
  const [newPLName, setNewPLName]       = useState("");
  const [showInstall, setShowInstall]   = useState(true);
  const { installPrompt, isInstalled, isIOS, install } = usePWAInstall();
  const isOnline = useOnlineStatus();

  useEffect(() => {
    api.getPlaylists().then(setPlaylists).catch(() => {});
  }, []);

  const handleLogout = () => { logout(); navigate("/login"); };

  const handleCreatePL = async (e) => {
    e.preventDefault();
    if (!newPLName.trim()) return;
    try {
      const f = new FormData();
      f.append("name", newPLName);
      const pl = await api.createPlaylist(f);
      setPlaylists((p) => [pl, ...p]);
      setNewPLName(""); setShowNewPL(false);
      navigate(`/playlist/${pl.id}`);
      toast.success("Playlist created!");
    } catch (err) { toast.error(err.message); }
  };

  return (
    <>
      {/* ── Offline bar ── */}
      {!isOnline && (
        <div style={{
          position:"fixed",top:0,left:0,right:0,zIndex:999,
          background:"#ef4444",color:"#fff",textAlign:"center",
          padding:"8px",fontSize:13,fontWeight:600
        }}>
          📡 You are offline — music may continue from cache
        </div>
      )}

      {/* ── PWA Install banner ── */}
      {showInstall && !isInstalled && (installPrompt || isIOS) && (
        <div style={{
          position:"fixed",bottom:"calc(var(--player-h) + 8px)",left:12,right:12,
          background:"var(--bg-surface)",border:"1px solid var(--accent)",
          borderRadius:14,padding:"14px 16px",zIndex:200,
          boxShadow:"0 8px 32px rgba(124,58,237,.3)",
          display:"flex",alignItems:"center",gap:12
        }}>
          <div style={{fontSize:32,flexShrink:0}}>🎵</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:13,fontWeight:700}}>Install YoMusic</div>
            <div style={{fontSize:11,color:"var(--tx-2)",marginTop:2}}>
              {isIOS
                ? 'Tap Share → "Add to Home Screen" to install'
                : "Add to your home screen for the best experience"}
            </div>
          </div>
          {!isIOS && (
            <button className="btn btn-primary btn-sm" onClick={async()=>{
              const ok = await install();
              if(ok) { setShowInstall(false); toast.success("YoMusic installed! 🎉"); }
            }}>Install</button>
          )}
          <button className="ctrl-btn" onClick={()=>setShowInstall(false)}
            style={{flexShrink:0,fontSize:16,color:"var(--tx-3)"}}>✕</button>
        </div>
      )}

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          style={{ position:"fixed",inset:0,background:"rgba(0,0,0,.5)",zIndex:199 }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="app-shell">
        {/* ── Sidebar ── */}
        <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
          <div className="sidebar-logo">
            <div className="logo-icon">🎵</div>
            <span>YoMusic</span>
          </div>

          <nav className="sidebar-nav">
            <NavLink to="/"       end onClick={() => setSidebarOpen(false)}>
              <Home size={18} /> Home
            </NavLink>
            <NavLink to="/search"    onClick={() => setSidebarOpen(false)}>
              <Search size={18} /> Search
            </NavLink>
            <NavLink to="/library"   onClick={() => setSidebarOpen(false)}>
              <Library size={18} /> Your Library
            </NavLink>
          </nav>

          <div className="sidebar-nav" style={{ paddingTop: 0 }}>
            <NavLink to="/liked"   onClick={() => setSidebarOpen(false)}>
              <Heart size={18} /> Liked Songs
            </NavLink>
            <NavLink to="/history" onClick={() => setSidebarOpen(false)}>
              <Clock size={18} /> Recently Played
            </NavLink>
            <NavLink to="/mood" onClick={() => setSidebarOpen(false)}>
              <Sparkles size={18} /> AI Mood Player
            </NavLink>
            {!isAdmin() && (
              <NavLink to="/submit-music" onClick={() => setSidebarOpen(false)}>
                <Music2 size={18} /> Submit Your Music
              </NavLink>
            )}
            {isAdmin() && (
              <NavLink to="/upload" onClick={() => setSidebarOpen(false)}>
                <Upload size={18} /> Upload Music
              </NavLink>
            )}
            {isAdmin() && (
              <NavLink to="/admin" onClick={() => setSidebarOpen(false)}>
                <Shield size={18} /> Admin
              </NavLink>
            )}
          </div>

          {/* Playlists */}
          <div className="sidebar-section">Playlists</div>
          <button
            className="sidebar-nav"
            style={{ padding: "0 12px 4px" }}
            onClick={() => setShowNewPL(true)}
          >
            <span style={{ display:"flex",alignItems:"center",gap:8,color:"var(--tx-2)",fontSize:13,padding:"8px 12px",borderRadius:8,cursor:"pointer",width:"100%" }}
              onMouseEnter={e=>e.currentTarget.style.background="var(--bg-hover)"}
              onMouseLeave={e=>e.currentTarget.style.background="transparent"}
            >
              <Plus size={14} /> New Playlist
            </span>
          </button>

          {showNewPL && (
            <form onSubmit={handleCreatePL} style={{ padding:"0 12px 8px", display:"flex", gap:6 }}>
              <input
                autoFocus
                value={newPLName}
                onChange={e => setNewPLName(e.target.value)}
                placeholder="Playlist name"
                style={{ fontSize:12, padding:"6px 10px", height:32 }}
                onKeyDown={e => e.key === "Escape" && setShowNewPL(false)}
              />
              <button type="submit" className="btn btn-primary btn-sm" style={{ whiteSpace:"nowrap" }}>Add</button>
            </form>
          )}

          <div className="sidebar-playlists">
            {playlists.map((pl) => (
              <NavLink
                key={pl.id}
                to={`/playlist/${pl.id}`}
                className="sidebar-pl-item"
                onClick={() => setSidebarOpen(false)}
              >
                <ListMusic size={13} style={{ marginRight:6, opacity:.5 }} />
                {pl.name}
              </NavLink>
            ))}
            {!playlists.length && (
              <p style={{ fontSize:12,color:"var(--tx-3)",padding:"4px 12px" }}>
                No playlists yet
              </p>
            )}
          </div>

          {/* User */}
          <NavLink to="/profile" className="sidebar-user" onClick={() => setSidebarOpen(false)}>
            <div className="sidebar-user-avatar">
              {user?.avatar_url
                ? <img src={user.avatar_url} alt="" />
                : user?.name?.[0]?.toUpperCase()
              }
            </div>
            <div className="sidebar-user-info">
              <div className="sidebar-user-name">{user?.name}</div>
              <div className="sidebar-user-role">{user?.role}</div>
            </div>
            <button
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleLogout(); }}
              className="ctrl-btn"
              title="Logout"
            >
              <LogOut size={15} />
            </button>
          </NavLink>
        </aside>

        {/* ── Main ── */}
        <main className="main-content">
          {/* Topbar */}
          <div className="topbar">
            <button
              className="mobile-menu-btn ctrl-btn"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="topbar-actions">
              <span style={{ fontSize:13,color:"var(--tx-2)" }}>
                Welcome, <strong style={{ color:"var(--tx-1)" }}>{user?.name}</strong>
              </span>
            </div>
          </div>

          <Outlet />
        </main>

        {/* ── Player ── */}
        <Player />
      </div>
    </>
  );
}
