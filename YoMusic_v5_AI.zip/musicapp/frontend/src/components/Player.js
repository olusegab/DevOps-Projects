import React, { useRef, useEffect, useState } from "react";
import {
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1,
  Volume2, VolumeX, Heart, ListMusic, Download, ChevronDown, Mic2
} from "lucide-react";
import { usePlayerStore, useAuthStore } from "../store";
import { useMediaSession } from "../hooks/usePWA";
import api from "../utils/api";
import toast from "react-hot-toast";

function fmt(s) {
  if (!s || isNaN(s)) return "0:00";
  return `${Math.floor(s/60)}:${Math.floor(s%60).toString().padStart(2,"0")}`;
}

export default function Player() {
  const {
    currentSong, isPlaying, volume, shuffle, repeat,
    duration, currentTime, queue, queueIndex,
    setPlaying, setVolume, setDuration, setCurrentTime,
    next, prev, toggleShuffle, cycleRepeat, playSong, showFullPlayer, setShowFull,
  } = usePlayerStore();
  const { isPremium } = useAuthStore();
  const audioRef = useRef(null);
  const [liked, setLiked]         = useState(false);
  const [queueOpen, setQueueOpen] = useState(false);
  const [dragging, setDragging]   = useState(false);

  // Lock screen / notification controls
  useMediaSession({
    song: currentSong, isPlaying,
    onPlay:  () => setPlaying(true),
    onPause: () => setPlaying(false),
    onNext:  next,
    onPrev:  prev,
  });

  // Play/pause sync
  useEffect(() => {
    if (!audioRef.current) return;
    if (isPlaying) audioRef.current.play().catch(() => {});
    else audioRef.current.pause();
  }, [isPlaying]);

  // New song load
  useEffect(() => {
    if (!audioRef.current || !currentSong) return;
    audioRef.current.src = currentSong.audio_url;
    audioRef.current.load();
    if (isPlaying) audioRef.current.play().catch(() => {});
    api.checkLike(currentSong.id).then(r => setLiked(r.liked)).catch(() => {});
  }, [currentSong?.id]);

  // Volume
  useEffect(() => { if (audioRef.current) audioRef.current.volume = volume; }, [volume]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e) => {
      const tag = e.target.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.code === "Space") { e.preventDefault(); setPlaying(!isPlaying); }
      if (e.code === "ArrowRight" && e.altKey) next();
      if (e.code === "ArrowLeft"  && e.altKey) prev();
      if (e.code === "KeyM") setVolume(volume > 0 ? 0 : 0.8);
      if (e.code === "KeyF") setShowFull(!showFullPlayer);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isPlaying, volume, showFullPlayer]);

  const handleEnded = () => {
    if (repeat === "one") { audioRef.current.currentTime = 0; audioRef.current.play(); }
    else next();
  };

  const seek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const t    = pct * duration;
    audioRef.current.currentTime = t;
    setCurrentTime(t);
  };

  const onVolClick = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setVolume(Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)));
  };

  const toggleLike = async () => {
    if (!currentSong) return;
    try { const r = await api.toggleLike(currentSong.id); setLiked(r.liked); }
    catch (err) { toast.error(err.message); }
  };

  const handleDownload = async () => {
    if (!currentSong) return;
    try {
      const r = await api.downloadSong(currentSong.id);
      const a = document.createElement("a");
      a.href = r.download_url; a.download = r.filename; a.click();
      toast.success("Download started!");
    } catch (err) { toast.error(err.message || "Premium required to download"); }
  };

  const progress = duration ? (currentTime / duration) * 100 : 0;

  // ── Full screen player ─────────────────────────────────────────────────────
  if (showFullPlayer && currentSong) {
    return (
      <>
        <audio ref={audioRef}
          onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime||0)}
          onDurationChange={() => setDuration(audioRef.current?.duration||0)}
          onEnded={handleEnded} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}
        />
        <div style={{
          position:"fixed",inset:0,zIndex:500,
          background:`linear-gradient(180deg,#1a0a3e 0%,#0a0a0f 100%)`,
          display:"flex",flexDirection:"column",alignItems:"center",
          justifyContent:"space-between",padding:"24px 32px",
        }}>
          {/* Top bar */}
          <div style={{width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
            <button className="ctrl-btn" onClick={() => setShowFull(false)}>
              <ChevronDown size={24}/>
            </button>
            <div style={{fontSize:13,fontWeight:600,color:"var(--tx-2)"}}>
              {queue.length > 1 ? `${queueIndex+1} of ${queue.length}` : "Now Playing"}
            </div>
            <button className="ctrl-btn" onClick={() => setQueueOpen(!queueOpen)}>
              <ListMusic size={20}/>
            </button>
          </div>

          {/* Cover art */}
          <div style={{
            width:280,height:280,borderRadius:16,
            background:"var(--bg-card)",overflow:"hidden",
            boxShadow:"0 32px 80px rgba(0,0,0,.7)",
            animation: isPlaying ? "rotateSlow 20s linear infinite paused" : "none",
          }}>
            {currentSong.cover_url
              ? <img src={currentSong.cover_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
              : <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:80}}>🎵</div>
            }
          </div>

          {/* Song info */}
          <div style={{textAlign:"center",width:"100%"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
              <div style={{textAlign:"left",flex:1,minWidth:0}}>
                <div style={{fontSize:22,fontWeight:800,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{currentSong.title}</div>
                <div style={{fontSize:15,color:"var(--tx-2)",marginTop:2}}>{currentSong.artist}</div>
              </div>
              <div style={{display:"flex",gap:8}}>
                <button className={`ctrl-btn ${liked?"active":""}`} onClick={toggleLike}>
                  <Heart size={22} fill={liked?"currentColor":"none"}/>
                </button>
                {isPremium() && (
                  <button className="ctrl-btn" onClick={handleDownload} title="Download (Premium)">
                    <Download size={20}/>
                  </button>
                )}
              </div>
            </div>

            {/* Progress */}
            <div className="player-progress" style={{margin:"16px 0"}}>
              <span className="time-label">{fmt(currentTime)}</span>
              <div className="progress-bar" onClick={seek}>
                <div className="progress-fill" style={{width:`${progress}%`}}/>
              </div>
              <span className="time-label right">{fmt(duration)}</span>
            </div>

            {/* Controls */}
            <div className="player-btns" style={{justifyContent:"center",gap:24}}>
              <button className={`ctrl-btn ${shuffle?"active":""}`} onClick={toggleShuffle}><Shuffle size={20}/></button>
              <button className="ctrl-btn" onClick={prev}><SkipBack size={28}/></button>
              <button className="play-btn" style={{width:56,height:56}} onClick={() => setPlaying(!isPlaying)}>
                {isPlaying ? <Pause size={24}/> : <Play size={24}/>}
              </button>
              <button className="ctrl-btn" onClick={next}><SkipForward size={28}/></button>
              <button className={`ctrl-btn ${repeat!=="none"?"active":""}`} onClick={cycleRepeat}>
                {repeat==="one"?<Repeat1 size={20}/>:<Repeat size={20}/>}
              </button>
            </div>

            {/* Volume */}
            <div className="volume-control" style={{justifyContent:"center",marginTop:24}}>
              <button className="ctrl-btn" onClick={() => setVolume(volume>0?0:.8)}>
                {volume===0?<VolumeX size={18}/>:<Volume2 size={18}/>}
              </button>
              <div className="volume-slider" style={{width:160}} onClick={onVolClick}>
                <div className="volume-fill" style={{width:`${volume*100}%`}}/>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  // ── Mini bar (no song) ─────────────────────────────────────────────────────
  if (!currentSong) {
    return (
      <div className="player-bar" style={{gridColumn:"1/-1"}}>
        <audio ref={audioRef}/>
        <div style={{color:"var(--tx-3)",fontSize:13,display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:18}}>🎵</span> YoMusic — Select a song to play
        </div>
        <div style={{fontSize:11,color:"var(--tx-3)",textAlign:"center"}}>
          Space = play/pause · Alt+← prev · Alt+→ next · M = mute · F = fullscreen
        </div>
        <div/>
      </div>
    );
  }

  // ── Mini player bar ────────────────────────────────────────────────────────
  return (
    <>
      {/* Queue drawer */}
      {queueOpen && (
        <div className="queue-drawer open">
          <div className="queue-header">
            <span>Queue ({queue.length})</span>
            <button className="ctrl-btn" onClick={() => setQueueOpen(false)}>✕</button>
          </div>
          <div className="queue-list">
            {queue.map((s, i) => (
              <div key={s.id+i} className={`queue-item ${i===queueIndex?"active":""}`}
                onClick={() => playSong(s, queue)}>
                <div className="queue-item-art">
                  {s.cover_url
                    ? <img src={s.cover_url} alt=""/>
                    : <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>🎵</div>
                  }
                </div>
                <div style={{minWidth:0}}>
                  <div className="queue-item-title">{s.title}</div>
                  <div className="queue-item-artist">{s.artist}</div>
                </div>
                {i===queueIndex && <span style={{marginLeft:"auto",color:"var(--accent-2)",fontSize:11,flexShrink:0}}>▶</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="player-bar" style={{gridColumn:"1/-1"}}>
        <audio ref={audioRef}
          onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime||0)}
          onDurationChange={() => setDuration(audioRef.current?.duration||0)}
          onEnded={handleEnded} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}
        />

        {/* Left: song info */}
        <div className="player-song-info">
          <div className="player-art" onClick={() => setShowFull(true)} style={{cursor:"pointer"}}>
            {currentSong.cover_url
              ? <img src={currentSong.cover_url} alt=""/>
              : <div className="player-art-ph">🎵</div>
            }
          </div>
          <div className="player-meta" style={{cursor:"pointer"}} onClick={() => setShowFull(true)}>
            <div className="player-title">{currentSong.title}</div>
            <div className="player-artist">{currentSong.artist}</div>
          </div>
          <button className={`player-like ctrl-btn ${liked?"liked":""}`} onClick={toggleLike}>
            <Heart size={16} fill={liked?"currentColor":"none"}/>
          </button>
          {isPremium() && (
            <button className="ctrl-btn" onClick={handleDownload} title="Download (Premium)">
              <Download size={15}/>
            </button>
          )}
        </div>

        {/* Center: controls + progress */}
        <div className="player-controls">
          <div className="player-btns">
            <button className={`ctrl-btn ${shuffle?"active":""}`} onClick={toggleShuffle}><Shuffle size={16}/></button>
            <button className="ctrl-btn" onClick={prev}><SkipBack size={20}/></button>
            <button className="play-btn" onClick={() => setPlaying(!isPlaying)}>
              {isPlaying ? <Pause size={18}/> : <Play size={18}/>}
            </button>
            <button className="ctrl-btn" onClick={next}><SkipForward size={20}/></button>
            <button className={`ctrl-btn ${repeat!=="none"?"active":""}`} onClick={cycleRepeat}>
              {repeat==="one"?<Repeat1 size={16}/>:<Repeat size={16}/>}
            </button>
          </div>
          <div className="player-progress">
            <span className="time-label">{fmt(currentTime)}</span>
            <div className="progress-bar" onClick={seek}>
              <div className="progress-fill" style={{width:`${progress}%`}}/>
            </div>
            <span className="time-label right">{fmt(duration)}</span>
          </div>
        </div>

        {/* Right: extras */}
        <div className="player-extras">
          <button className={`ctrl-btn ${showFullPlayer?"active":""}`} onClick={() => setShowFull(true)} title="Full Player (F)">
            <Mic2 size={16}/>
          </button>
          <button className={`ctrl-btn ${queueOpen?"active":""}`} onClick={() => setQueueOpen(!queueOpen)} title="Queue">
            <ListMusic size={16}/>
          </button>
          <div className="volume-control">
            <button className="ctrl-btn" onClick={() => setVolume(volume>0?0:.8)}>
              {volume===0?<VolumeX size={16}/>:<Volume2 size={16}/>}
            </button>
            <div className="volume-slider" onClick={onVolClick}>
              <div className="volume-fill" style={{width:`${volume*100}%`}}/>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
