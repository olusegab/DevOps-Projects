import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Play, Pause, MoreHorizontal, Heart, ListPlus, Trash2, Plus, Download, User, Disc } from "lucide-react";
import { usePlayerStore, useAuthStore } from "../store";
import api from "../utils/api";
import toast from "react-hot-toast";

function fmt(s) {
  if (!s || isNaN(s)) return "--:--";
  return `${Math.floor(s/60)}:${Math.floor(s%60).toString().padStart(2,"0")}`;
}

export default function SongRow({ song, index, queue, onDelete, onRemoveFromPlaylist, playlistId }) {
  const { currentSong, isPlaying, playSong, togglePlay } = usePlayerStore();
  const { user, isPremium } = useAuthStore();
  const navigate = useNavigate();
  const isActive = currentSong?.id === song.id;
  const [ctx, setCtx]         = useState(null);
  const [playlists, setPls]   = useState([]);
  const [showPL, setShowPL]   = useState(false);
  const menuRef = useRef(null);

  const handlePlay = (e) => {
    e.stopPropagation();
    if (isActive) togglePlay(); else playSong(song, queue||[song]);
  };

  useEffect(() => {
    if (!ctx) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setCtx(null); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [ctx]);

  const openCtx = (e) => {
    e.stopPropagation();
    setCtx({ x: Math.min(e.clientX, window.innerWidth-210), y: Math.min(e.clientY, window.innerHeight-320) });
    api.getPlaylists().then(setPls).catch(() => {});
  };

  const handleLike = async () => {
    try { const r = await api.toggleLike(song.id); toast.success(r.liked?"Added to Liked Songs":"Removed from Liked"); }
    catch (err) { toast.error(err.message); }
    setCtx(null);
  };

  const addToQueue = () => {
    usePlayerStore.getState().addToQueue(song);
    toast.success("Added to queue"); setCtx(null);
  };

  const addToPL = async (plId) => {
    try { await api.addToPlaylist(plId, song.id); toast.success("Added to playlist!"); }
    catch (err) { toast.error(err.message); }
    setCtx(null); setShowPL(false);
  };

  const handleDownload = async () => {
    if (!isPremium()) { toast.error("🔒 Premium required to download"); setCtx(null); return; }
    try {
      const r = await api.downloadSong(song.id);
      const a = document.createElement("a"); a.href=r.download_url; a.download=r.filename; a.click();
      toast.success("Download started!");
    } catch (err) { toast.error(err.message); }
    setCtx(null);
  };

  const handleDelete = async () => {
    try { await api.deleteSong(song.id); toast.success("Song deleted"); onDelete?.(song.id); }
    catch (err) { toast.error(err.message); }
    setCtx(null);
  };

  const canDelete = user?.role==="admin"||user?.role==="superadmin"||user?.id===song.uploaded_by;

  return (
    <>
      <div className={`song-row ${isActive?"playing":""}`} onDoubleClick={handlePlay}>
        <div className="sr-num" onClick={handlePlay} style={{cursor:"pointer"}}>
          {isActive && isPlaying ? <span style={{color:"var(--accent-2)"}}>▶</span> : <span>{index+1}</span>}
        </div>
        <div className="sr-art" onClick={handlePlay} style={{cursor:"pointer"}}>
          {song.cover_url ? <img src={song.cover_url} alt=""/> : <div className="sr-art-ph">🎵</div>}
        </div>
        <div className="sr-title" onClick={handlePlay}>{song.title}</div>
        <div className="sr-album" style={{cursor:"pointer"}} onClick={() => song.album && navigate(`/album/${encodeURIComponent(song.album)}`)}>
          {song.album||"—"}
        </div>
        <div className="sr-plays">{(song.play_count||0).toLocaleString()}</div>
        <div className="sr-duration">{fmt(song.duration)}</div>
        <button className="ctrl-btn" onClick={openCtx}><MoreHorizontal size={16}/></button>
      </div>

      {ctx && (
        <div ref={menuRef} className="ctx-menu" style={{top:ctx.y, left:ctx.x}}>
          <button className="ctx-item" onClick={handlePlay}>
            {isActive&&isPlaying ? <><Pause size={14}/> Pause</> : <><Play size={14}/> Play</>}
          </button>
          <button className="ctx-item" onClick={addToQueue}><Plus size={14}/> Add to queue</button>
          <div className="ctx-divider"/>
          <button className="ctx-item" onClick={handleLike}><Heart size={14}/> Like song</button>
          <button className="ctx-item" onClick={() => setShowPL(!showPL)}><ListPlus size={14}/> Add to playlist</button>
          {showPL && (playlists.length
            ? playlists.map(pl => (
                <button key={pl.id} className="ctx-item" style={{paddingLeft:28,fontSize:12}} onClick={()=>addToPL(pl.id)}>
                  {pl.name}
                </button>
              ))
            : <div style={{padding:"6px 28px",fontSize:12,color:"var(--tx-3)"}}>No playlists</div>
          )}
          <button className="ctx-item" onClick={handleDownload}>
            <Download size={14}/> Download {!isPremium()&&<span style={{fontSize:10,color:"var(--accent-2)",marginLeft:4}}>PREMIUM</span>}
          </button>
          <div className="ctx-divider"/>
          <button className="ctx-item" onClick={()=>{navigate(`/artist/${encodeURIComponent(song.artist)}`);setCtx(null);}}>
            <User size={14}/> Go to artist
          </button>
          {song.album && (
            <button className="ctx-item" onClick={()=>{navigate(`/album/${encodeURIComponent(song.album)}`);setCtx(null);}}>
              <Disc size={14}/> Go to album
            </button>
          )}
          {playlistId && onRemoveFromPlaylist && (
            <>
              <div className="ctx-divider"/>
              <button className="ctx-item" onClick={()=>{onRemoveFromPlaylist(song.id);setCtx(null);}}>
                <Plus size={14} style={{transform:"rotate(45deg)"}}/> Remove from playlist
              </button>
            </>
          )}
          {canDelete && (
            <>
              <div className="ctx-divider"/>
              <button className="ctx-item danger" onClick={handleDelete}><Trash2 size={14}/> Delete song</button>
            </>
          )}
        </div>
      )}
    </>
  );
}
