import { create } from "zustand";
import { persist } from "zustand/middleware";
import api from "../utils/api";

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null, token: null,
      login: async (email, pw) => {
        const d = await api.login(email, pw);
        localStorage.setItem("ym_token", d.token);
        set({ user: d.user, token: d.token }); return d;
      },
      register: async (name, email, pw) => {
        const d = await api.register(name, email, pw);
        localStorage.setItem("ym_token", d.token);
        set({ user: d.user, token: d.token }); return d;
      },
      logout: () => { localStorage.removeItem("ym_token"); set({ user: null, token: null }); },
      refreshUser: async () => {
        try { const u = await api.me(); set({ user: u }); }
        catch { get().logout(); }
      },
      isPremium: () => ["premium","admin","superadmin"].includes(get().user?.role),
      isAdmin:   () => ["admin","superadmin"].includes(get().user?.role),
    }),
    { name: "ym-auth", partialize: s => ({ user: s.user, token: s.token }) }
  )
);

export const usePlayerStore = create((set, get) => ({
  queue: [], queueIndex: 0, currentSong: null,
  isPlaying: false, volume: 0.8, shuffle: false,
  repeat: "none", duration: 0, currentTime: 0,
  showFullPlayer: false,

  playSong: (song, queue = null) => {
    const q   = queue || [song];
    const idx = q.findIndex(s => s.id === song.id);
    set({ currentSong: song, queue: q, queueIndex: idx >= 0 ? idx : 0, isPlaying: true });
    api.playSong(song.id).catch(() => {});
    api.addHistory(song.id).catch(() => {});
  },
  playQueue: (songs, startIdx = 0) => {
    if (!songs.length) return;
    const song = songs[startIdx];
    set({ queue: songs, queueIndex: startIdx, currentSong: song, isPlaying: true });
    api.playSong(song.id).catch(() => {});
    api.addHistory(song.id).catch(() => {});
  },
  togglePlay:    ()  => set(s => ({ isPlaying: !s.isPlaying })),
  setPlaying:    (v) => set({ isPlaying: v }),
  setVolume:     (v) => set({ volume: v }),
  setDuration:   (v) => set({ duration: v }),
  setCurrentTime:(v) => set({ currentTime: v }),
  setShowFull:   (v) => set({ showFullPlayer: v }),

  next: () => {
    const { queue, queueIndex, shuffle, repeat } = get();
    if (!queue.length) return;
    let idx = shuffle ? Math.floor(Math.random() * queue.length)
            : repeat === "all" ? (queueIndex + 1) % queue.length
            : Math.min(queueIndex + 1, queue.length - 1);
    const song = queue[idx];
    set({ queueIndex: idx, currentSong: song, isPlaying: true });
    api.playSong(song.id).catch(() => {}); api.addHistory(song.id).catch(() => {});
  },
  prev: () => {
    const { queue, queueIndex, currentTime } = get();
    if (!queue.length) return;
    if (currentTime > 3) { set({ currentTime: 0 }); return; }
    const idx  = Math.max(queueIndex - 1, 0);
    set({ queueIndex: idx, currentSong: queue[idx], isPlaying: true });
    api.playSong(queue[idx].id).catch(() => {});
  },
  toggleShuffle: () => set(s => ({ shuffle: !s.shuffle })),
  cycleRepeat:   () => set(s => ({ repeat: s.repeat === "none" ? "all" : s.repeat === "all" ? "one" : "none" })),
  addToQueue:    (song) => set(s => ({ queue: [...s.queue, song] })),
  clearQueue:    () => set({ queue: [], queueIndex: 0, currentSong: null, isPlaying: false }),
}));
