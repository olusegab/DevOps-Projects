import { useState, useEffect } from "react";

// ── PWA Install Prompt ────────────────────────────────────────────────────────
export function usePWAInstall() {
  const [installPrompt, setInstallPrompt] = useState(null);
  const [isInstalled,   setIsInstalled]   = useState(false);
  const [isIOS,         setIsIOS]         = useState(false);

  useEffect(() => {
    // Check if already installed
    const mq = window.matchMedia("(display-mode: standalone)");
    setIsInstalled(mq.matches || window.navigator.standalone === true);
    mq.addEventListener("change", (e) => setIsInstalled(e.matches));

    // iOS detection
    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
    setIsIOS(ios);

    // Android/Chrome install prompt
    const handler = (e) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const install = async () => {
    if (!installPrompt) return false;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === "accepted") { setInstallPrompt(null); setIsInstalled(true); }
    return outcome === "accepted";
  };

  return { installPrompt, isInstalled, isIOS, install };
}

// ── Media Session API (lock screen / notification controls) ──────────────────
export function useMediaSession({ song, isPlaying, onPlay, onPause, onNext, onPrev }) {
  useEffect(() => {
    if (!("mediaSession" in navigator) || !song) return;

    navigator.mediaSession.metadata = new MediaMetadata({
      title:  song.title  || "Unknown",
      artist: song.artist || "Unknown",
      album:  song.album  || "YoMusic",
      artwork: song.cover_url ? [
        { src: song.cover_url, sizes: "512x512", type: "image/jpeg" },
        { src: song.cover_url, sizes: "256x256", type: "image/jpeg" },
      ] : [
        { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
      ],
    });

    navigator.mediaSession.playbackState = isPlaying ? "playing" : "paused";

    navigator.mediaSession.setActionHandler("play",          () => onPlay?.());
    navigator.mediaSession.setActionHandler("pause",         () => onPause?.());
    navigator.mediaSession.setActionHandler("nexttrack",     () => onNext?.());
    navigator.mediaSession.setActionHandler("previoustrack", () => onPrev?.());
    navigator.mediaSession.setActionHandler("stop",          () => onPause?.());

  }, [song?.id, isPlaying]);
}

// ── Online/Offline detection ──────────────────────────────────────────────────
export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  useEffect(() => {
    const on  = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener("online",  on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online",on); window.removeEventListener("offline",off); };
  }, []);
  return isOnline;
}
