import React, { useState } from "react";
import { Music, Mail, CheckCircle, ExternalLink } from "lucide-react";

const GENRES = ["Pop","Rock","Jazz","Classical","Hip-Hop","Electronic",
  "RnB","Country","Afrobeats","Gospel","Reggae","Blues","Soul","Other"];

export default function SubmitMusic() {
  const [form, setForm]     = useState({ name:"", email:"", artist:"", genre:"", links:"", message:"" });
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending]     = useState(false);

  const handleChange = e => setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);
    // Simulate sending (in production, POST to your backend or a form service like Formspree)
    await new Promise(r => setTimeout(r, 1200));
    setSending(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="page">
        <div className="empty-state" style={{ paddingTop:80 }}>
          <div style={{ fontSize:64, marginBottom:16 }}>🎉</div>
          <h3 style={{ color:"var(--green)", fontSize:24 }}>Submission Received!</h3>
          <p style={{ maxWidth:440, textAlign:"center", color:"var(--tx-2)", lineHeight:1.6 }}>
            Thank you for your interest! Our team will review your submission and
            get back to you within <strong style={{ color:"var(--tx-1)" }}>3–5 business days</strong>.
          </p>
          <button className="btn btn-primary" style={{ marginTop:24 }} onClick={() => setSubmitted(false)}>
            Submit Another
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      {/* Hero */}
      <div style={{
        background: "linear-gradient(135deg, #1a0a3e 0%, #0a1a3e 100%)",
        borderRadius: 16, padding: "40px 32px", marginBottom: 36,
        border: "1px solid var(--border)", position: "relative", overflow: "hidden"
      }}>
        <div style={{ position:"absolute", top:-20, right:-20, fontSize:120, opacity:.06 }}>🎵</div>
        <div style={{ position:"relative" }}>
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:16 }}>
            <div style={{
              width:48, height:48, borderRadius:12,
              background:"linear-gradient(135deg,var(--accent),var(--accent-2))",
              display:"flex", alignItems:"center", justifyContent:"center"
            }}>
              <Music size={24} color="#fff"/>
            </div>
            <div>
              <h1 style={{ fontSize:26, fontWeight:800, margin:0 }}>Get Your Music on YoMusic</h1>
              <p style={{ color:"var(--tx-2)", margin:0, fontSize:14 }}>Submit your tracks to our curation team</p>
            </div>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:16, marginTop:24 }}>
            {[
              { icon:"🎧", title:"Curated Library",  desc:"Every track is reviewed by our team" },
              { icon:"🌍", title:"Global Reach",     desc:"Stream to listeners worldwide" },
              { icon:"📊", title:"Analytics",        desc:"Track your plays and audience" },
              { icon:"⚡", title:"Fast Review",      desc:"Response within 3–5 business days" },
            ].map(({ icon, title, desc }) => (
              <div key={title} style={{
                background:"rgba(255,255,255,.05)", borderRadius:10, padding:"14px 16px"
              }}>
                <div style={{ fontSize:24, marginBottom:6 }}>{icon}</div>
                <div style={{ fontSize:13, fontWeight:700 }}>{title}</div>
                <div style={{ fontSize:12, color:"var(--tx-3)", marginTop:2 }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 340px", gap:28, alignItems:"start" }}>
        {/* Form */}
        <div>
          <h2 style={{ fontSize:18, fontWeight:700, marginBottom:20 }}>Submission Form</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Your Full Name *</label>
                <input name="name" value={form.name} onChange={handleChange} placeholder="John Doe" required/>
              </div>
              <div className="form-group">
                <label className="form-label">Email Address *</label>
                <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="you@email.com" required/>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Artist / Band Name *</label>
                <input name="artist" value={form.artist} onChange={handleChange} placeholder="Your artist name" required/>
              </div>
              <div className="form-group">
                <label className="form-label">Primary Genre *</label>
                <select name="genre" value={form.genre} onChange={handleChange} required>
                  <option value="">Select genre</option>
                  {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Music Links *</label>
              <input
                name="links" value={form.links} onChange={handleChange} required
                placeholder="SoundCloud, YouTube, Google Drive, Dropbox links to your tracks..."
              />
              <span className="form-hint">Share links to at least 1 track (SoundCloud, YouTube, Drive, etc.)</span>
            </div>

            <div className="form-group">
              <label className="form-label">Tell Us About Your Music</label>
              <textarea
                name="message" value={form.message} onChange={handleChange}
                placeholder="Describe your music, influences, and what makes it unique..."
                rows={4}
                style={{ resize:"vertical", minHeight:100 }}
              />
            </div>

            <button
              type="submit" className="btn btn-primary" disabled={sending}
              style={{ width:"100%", justifyContent:"center", padding:14 }}
            >
              {sending ? (
                <><div className="spinner" style={{ width:16, height:16, borderWidth:2 }}/> Submitting...</>
              ) : (
                <><Mail size={16}/> Submit My Music</>
              )}
            </button>

            <p style={{ fontSize:12, color:"var(--tx-3)", textAlign:"center", marginTop:12 }}>
              By submitting, you confirm you own the rights to all submitted music.
            </p>
          </form>
        </div>

        {/* Sidebar info */}
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          {/* What happens next */}
          <div style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:14 }}>📋 What Happens Next</div>
            {[
              ["1", "Submit your form with music links"],
              ["2", "Our team reviews your tracks (3–5 days)"],
              ["3", "You receive an email with our decision"],
              ["4", "Approved? We upload & publish your music"],
              ["5", "Track your streams in real time!"],
            ].map(([num, step]) => (
              <div key={num} style={{ display:"flex", gap:10, marginBottom:10, alignItems:"flex-start" }}>
                <div style={{
                  width:22, height:22, borderRadius:"50%", flexShrink:0,
                  background:"var(--accent)", display:"flex", alignItems:"center",
                  justifyContent:"center", fontSize:11, fontWeight:800, color:"#fff"
                }}>{num}</div>
                <span style={{ fontSize:13, color:"var(--tx-2)", lineHeight:1.5 }}>{step}</span>
              </div>
            ))}
          </div>

          {/* Requirements */}
          <div style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:14 }}>✅ Requirements</div>
            {[
              "You own full rights to the music",
              "Original content only (no covers without license)",
              "Audio quality: 128kbps minimum",
              "Acceptable formats: MP3, WAV, FLAC",
              "Cover art recommended (500×500px min)",
            ].map(req => (
              <div key={req} style={{ display:"flex", gap:8, marginBottom:8, fontSize:12, color:"var(--tx-2)" }}>
                <span style={{ color:"var(--green)", flexShrink:0 }}>✓</span> {req}
              </div>
            ))}
          </div>

          {/* Direct contact */}
          <div style={{
            background:"var(--accent-glow)", border:"1px solid var(--accent)",
            borderRadius:12, padding:20
          }}>
            <div style={{ fontSize:13, fontWeight:700, marginBottom:8 }}>📩 Direct Contact</div>
            <p style={{ fontSize:12, color:"var(--tx-2)", margin:"0 0 12px" }}>
              Prefer to email us directly?
            </p>
            <a href="mailto:music@yomusic.com" style={{
              display:"flex", alignItems:"center", gap:6,
              fontSize:13, fontWeight:600, color:"var(--accent-2)"
            }}>
              <Mail size={14}/> music@yomusic.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
