import React, { useState } from "react";
import { Sparkles, Play, Plus, Loader, RefreshCw } from "lucide-react";
import SongRow from "../components/SongRow";
import { usePlayerStore } from "../store";
import api from "../utils/api";
import toast from "react-hot-toast";

const MOOD_PRESETS = [
  { emoji:"🌅", label:"Morning Energy",   prompt:"upbeat energetic music to start the day" },
  { emoji:"💪", label:"Workout",           prompt:"high energy fast beats for gym workout" },
  { emoji:"😌", label:"Relax & Unwind",   prompt:"calm peaceful relaxing music" },
  { emoji:"🎉", label:"Party Mode",        prompt:"party hype songs to get the crowd going" },
  { emoji:"💭", label:"Deep Focus",        prompt:"instrumental focus music for studying or working" },
  { emoji:"🌙", label:"Late Night",        prompt:"smooth late night chill vibes" },
  { emoji:"❤️", label:"Romance",           prompt:"romantic love songs for a special evening" },
  { emoji:"😢", label:"Feeling Blue",      prompt:"emotional melancholic music for sad moments" },
  { emoji:"🙏", label:"Spiritual",         prompt:"gospel worship inspirational music" },
  { emoji:"🌍", label:"Afro Vibes",        prompt:"afrobeats afropop feel good African music" },
  { emoji:"🎷", label:"Sunday Jazz",       prompt:"smooth jazz for a relaxed Sunday afternoon" },
  { emoji:"🚗", label:"Road Trip",         prompt:"fun upbeat songs perfect for driving" },
];

export default function MoodPlayer() {
  const [mood,        setMood]        = useState("");
  const [result,      setResult]      = useState(null);
  const [loading,     setLoading]     = useState(false);
  const [savedPL,     setSavedPL]     = useState(false);
  const { playQueue } = usePlayerStore();

  const generate = async (moodText) => {
    const m = moodText || mood;
    if (!m.trim()) { toast.error("Tell us your mood first!"); return; }
    setLoading(true); setResult(null); setSavedPL(false);
    try {
      const r = await api.aiMoodPlaylist(m);
      if (!r.songs?.length) { toast.error("No matching songs found. Try a different mood!"); }
      else { setResult(r); toast.success(`✨ ${r.playlist_name} is ready!`); }
    } catch (err) { toast.error(err.message); }
    setLoading(false);
  };

  const saveAsPlaylist = async () => {
    if (!result) return;
    try {
      const f = new FormData();
      f.append("name",        result.playlist_name);
      f.append("description", result.description || "");
      f.append("is_public",   false);
      const pl = await api.createPlaylist(f);
      // Add songs
      for (const song of result.songs) {
        await api.addToPlaylist(pl.id, song.id).catch(()=>{});
      }
      setSavedPL(true);
      toast.success("Playlist saved to your library! 🎉");
    } catch (err) { toast.error(err.message); }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title" style={{ display:"flex", alignItems:"center", gap:12 }}>
          <Sparkles size={28} color="var(--accent-2)"/> AI Mood Player
        </h1>
        <p className="page-subtitle">Tell us how you feel — AI builds your perfect playlist instantly</p>
      </div>

      {/* Custom mood input */}
      <div style={{
        background:"var(--bg-card)", border:"1px solid var(--border)",
        borderRadius:16, padding:24, marginBottom:28
      }}>
        <div style={{ fontSize:14, fontWeight:600, marginBottom:12, color:"var(--tx-2)" }}>
          Describe your mood or what you want to hear
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <input
            value={mood}
            onChange={e => setMood(e.target.value)}
            onKeyDown={e => e.key==="Enter" && generate()}
            placeholder="e.g. happy Afrobeats for a Friday evening..."
            style={{ flex:1 }}
          />
          <button
            className="btn btn-primary"
            onClick={() => generate()}
            disabled={loading}
            style={{ whiteSpace:"nowrap" }}
          >
            {loading
              ? <><Loader size={15} style={{animation:"spin .7s linear infinite"}}/> Generating...</>
              : <><Sparkles size={15}/> Generate</>
            }
          </button>
        </div>
      </div>

      {/* Mood presets */}
      <section className="section">
        <div className="section-head">
          <h2 className="section-title">Quick Moods</h2>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))", gap:10 }}>
          {MOOD_PRESETS.map(m => (
            <button
              key={m.label}
              onClick={() => { setMood(m.prompt); generate(m.prompt); }}
              disabled={loading}
              style={{
                background:"var(--bg-card)", border:"1px solid var(--border)",
                borderRadius:12, padding:"14px 12px", cursor:"pointer",
                transition:"all .15s", textAlign:"left",
                display:"flex", flexDirection:"column", gap:6,
                opacity: loading ? .6 : 1,
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor="var(--accent)"}
              onMouseLeave={e => e.currentTarget.style.borderColor="var(--border)"}
            >
              <span style={{ fontSize:28 }}>{m.emoji}</span>
              <span style={{ fontSize:13, fontWeight:600, color:"var(--tx-1)" }}>{m.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Loading state */}
      {loading && (
        <div style={{ textAlign:"center", padding:"48px 0" }}>
          <div style={{ fontSize:40, marginBottom:12 }}>🎵</div>
          <div style={{ fontSize:15, fontWeight:600, color:"var(--tx-1)", marginBottom:6 }}>
            AI is curating your playlist...
          </div>
          <div style={{ fontSize:13, color:"var(--tx-3)" }}>
            Analyzing mood and picking the perfect songs
          </div>
          <div className="spinner" style={{ margin:"20px auto 0" }}/>
        </div>
      )}

      {/* Result */}
      {result && !loading && (
        <div style={{ marginTop:8 }}>
          {/* Playlist header */}
          <div style={{
            background:"linear-gradient(135deg,#1a0a3e 0%,#0a1a2e 100%)",
            borderRadius:16, padding:28, marginBottom:24,
            border:"1px solid var(--border)", position:"relative", overflow:"hidden"
          }}>
            <div style={{ position:"absolute", top:-10, right:-10, fontSize:100, opacity:.06 }}>🎵</div>
            <div style={{ position:"relative" }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                <span className="badge badge-purple">
                  <Sparkles size={10}/> AI Generated
                </span>
              </div>
              <h2 style={{ fontSize:26, fontWeight:900, margin:"0 0 8px", letterSpacing:"-0.5px" }}>
                {result.playlist_name}
              </h2>
              <p style={{ fontSize:14, color:"var(--tx-2)", margin:"0 0 20px", lineHeight:1.5 }}>
                {result.description}
              </p>
              <div style={{ fontSize:13, color:"var(--tx-3)", marginBottom:20 }}>
                {result.songs.length} songs
              </div>
              <div style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
                <button className="btn btn-primary"
                  onClick={() => playQueue(result.songs)}>
                  <Play size={16}/> Play All
                </button>
                <button className="btn btn-outline"
                  onClick={() => { setMood(""); generate(mood || "surprise me with something great"); }}>
                  <RefreshCw size={14}/> Regenerate
                </button>
                {!savedPL ? (
                  <button className="btn btn-outline" onClick={saveAsPlaylist}>
                    <Plus size={14}/> Save to Library
                  </button>
                ) : (
                  <span className="badge badge-green" style={{ padding:"8px 14px", fontSize:12 }}>
                    ✓ Saved to Library
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Song list */}
          <div className="song-list-header">
            <span>#</span><span/><span>Title</span>
            <span>Album</span><span>Plays</span><span>Duration</span><span/>
          </div>
          <div className="song-list">
            {result.songs.map((s,i) => (
              <SongRow key={s.id} song={s} index={i} queue={result.songs}/>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
