import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Play, Shuffle } from "lucide-react";
import SongRow from "../components/SongRow";
import { usePlayerStore } from "../store";
import api from "../utils/api";

export default function ArtistPage() {
  const { name }  = useParams();
  const [songs, setSongs]   = useState([]);
  const [loading, setLoading] = useState(true);
  const { playQueue } = usePlayerStore();

  useEffect(() => {
    api.getSongsByArtist(decodeURIComponent(name))
      .then(setSongs).catch(() => {}).finally(() => setLoading(false));
  }, [name]);

  const cover = songs.find(s => s.cover_url)?.cover_url;

  if (loading) return <div className="loading-center"><div className="spinner"/></div>;

  return (
    <div>
      <div className="playlist-hero" style={{ background:"linear-gradient(180deg,#1e3a5f 0%,var(--bg-base) 100%)" }}>
        <div className="playlist-hero-art" style={{ borderRadius:"50%", background:"linear-gradient(135deg,#3b82f6,#06b6d4)" }}>
          {cover ? <img src={cover} alt="" style={{ borderRadius:"50%" }}/> : <div className="playlist-hero-art-ph">🎤</div>}
        </div>
        <div className="playlist-hero-info">
          <div className="playlist-hero-type">Artist</div>
          <div className="playlist-hero-name">{decodeURIComponent(name)}</div>
          <div className="playlist-hero-meta">{songs.length} songs</div>
          <div style={{ display:"flex", gap:12, marginTop:20 }}>
            <button className="btn btn-primary" onClick={() => playQueue(songs)} disabled={!songs.length}><Play size={16}/> Play All</button>
            <button className="btn btn-outline" onClick={() => { const i=Math.floor(Math.random()*songs.length); playQueue(songs,i); }} disabled={!songs.length}><Shuffle size={16}/> Shuffle</button>
          </div>
        </div>
      </div>
      <div className="page" style={{ paddingTop:0 }}>
        {!songs.length ? (
          <div className="empty-state"><div className="empty-state-icon">🎤</div><h3>No songs found</h3></div>
        ) : (
          <>
            <div className="song-list-header"><span>#</span><span/><span>Title</span><span>Album</span><span>Plays</span><span>Duration</span><span/></div>
            <div className="song-list">
              {songs.map((s,i) => <SongRow key={s.id} song={s} index={i} queue={songs} onDelete={id => setSongs(p=>p.filter(x=>x.id!==id))}/>)}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
