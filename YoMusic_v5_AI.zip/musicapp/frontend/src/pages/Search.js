import React, { useState, useEffect, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Search as SearchIcon, Sparkles, Loader } from "lucide-react";
import SongRow from "../components/SongRow";
import api from "../utils/api";

const GENRE_EMOJIS = {
  Pop:"🎤",Rock:"🎸",Jazz:"🎷",Classical:"🎻","Hip-Hop":"🎤",
  Electronic:"🎹",RnB:"🎶",Country:"🤠",Afrobeats:"🌍",
  Gospel:"🙏",Reggae:"🌴",Blues:"🎸",Soul:"💛",
};

const AI_SUGGESTIONS = [
  "slow Afrobeats for a Sunday morning",
  "upbeat gospel to start my day",
  "something chill for late night studying",
  "energetic hip-hop for the gym",
  "romantic RnB for a dinner date",
  "fast electronic music",
];

export default function Search() {
  const [params]             = useSearchParams();
  const [query,  setQuery]   = useState(params.get("q") || "");
  const [genre,  setGenre]   = useState(params.get("genre") || "");
  const [songs,  setSongs]   = useState([]);
  const [genres, setGenres]  = useState([]);
  const [pls,    setPls]     = useState([]);
  const [artists,setArtists] = useState([]);
  const [loading,setLoading] = useState(false);
  const [isAI,   setIsAI]    = useState(false);
  const [interpreted, setInterpreted] = useState("");
  const [mode,   setMode]    = useState("normal");
  const navigate    = useNavigate();
  const debounceRef = useRef(null);

  useEffect(() => { api.getGenres().then(setGenres).catch(()=>{}); }, []);

  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => doSearch(), mode==="ai" ? 800 : 300);
    return () => clearTimeout(debounceRef.current);
  }, [query, genre, mode]);

  const doSearch = async () => {
    if (!query && !genre) {
      const r = await api.getRecent().catch(()=>[]);
      setSongs(Array.isArray(r)?r:[]); setPls([]); setArtists([]);
      setIsAI(false); setInterpreted(""); return;
    }
    setLoading(true);
    try {
      if (mode==="ai" && query.length >= 3) {
        const r = await api.aiSearch(query);
        setSongs(r.songs||[]); setPls([]); setArtists([]);
        setIsAI(r.ai_powered); setInterpreted(r.interpreted_as||query);
      } else {
        if (query.length >= 2) {
          const r = await api.search(query);
          setSongs(r.songs||[]); setPls(r.playlists||[]); setArtists(r.artists||[]);
        } else if (genre) {
          const r = await api.getSongs({ genre, limit:50 });
          setSongs(r.songs||[]); setPls([]); setArtists([]);
        }
        setIsAI(false); setInterpreted("");
      }
    } catch { setSongs([]); }
    setLoading(false);
  };

  return (
    <div className="page">
      <div className="page-header"><h1 className="page-title">Search</h1></div>

      {/* Mode toggle */}
      <div style={{ display:"flex", gap:8, marginBottom:16 }}>
        {[{key:"normal",label:"🔍 Standard"},{key:"ai",label:"✨ AI Search"}].map(m => (
          <button key={m.key} onClick={()=>{setMode(m.key);setSongs([]);setInterpreted("");}}
            className={`btn ${mode===m.key?"btn-primary":"btn-outline"} btn-sm`}>{m.label}</button>
        ))}
      </div>

      {/* Search bar */}
      <div className="search-bar" style={{ marginBottom: mode==="ai"?8:28, position:"relative" }}>
        <SearchIcon size={18} className="search-bar-icon"/>
        <input value={query} autoFocus
          onChange={e=>{setQuery(e.target.value);setGenre("");}}
          placeholder={mode==="ai"
            ?"Describe what you want to hear... (e.g. chill Afrobeats for Sunday)"
            :"Search songs, artists, albums..."}/>
        {loading && (
          <div style={{position:"absolute",right:16,top:"50%",transform:"translateY(-50%)"}}>
            <Loader size={16} color="var(--accent-2)" style={{animation:"spin .7s linear infinite"}}/>
          </div>
        )}
      </div>

      {/* AI suggestions */}
      {mode==="ai" && !query && (
        <div style={{marginBottom:24}}>
          <div style={{fontSize:12,color:"var(--tx-3)",marginBottom:8,fontWeight:600,textTransform:"uppercase",letterSpacing:".8px"}}>
            Try asking for...
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
            {AI_SUGGESTIONS.map(s=>(
              <button key={s} onClick={()=>setQuery(s)}
                className="btn btn-outline btn-sm" style={{borderRadius:99,fontSize:12}}>{s}</button>
            ))}
          </div>
        </div>
      )}

      {/* AI result banner */}
      {isAI && interpreted && (
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20,padding:"10px 16px",
          background:"var(--accent-glow)",borderRadius:10,border:"1px solid var(--accent)",fontSize:13}}>
          <Sparkles size={16} color="var(--accent-2)"/>
          <span style={{color:"var(--tx-2)"}}>AI understood: <strong style={{color:"var(--tx-1)"}}>"{interpreted}"</strong></span>
          <span className="badge badge-purple" style={{marginLeft:"auto"}}>AI</span>
        </div>
      )}

      {/* Genre pills (normal mode) */}
      {mode==="normal" && !query && (
        <section className="section">
          <div className="section-head"><h2 className="section-title">Browse Genres</h2></div>
          <div className="genre-grid">
            {genres.map(g=>(
              <div key={g} className="genre-pill"
                style={genre===g?{borderColor:"var(--accent)",background:"var(--accent-glow)"}:{}}
                onClick={()=>setGenre(g===genre?"":g)}>
                <span className="genre-emoji">{GENRE_EMOJIS[g]||"🎵"}</span>{g}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Results */}
      {loading ? (
        <div style={{textAlign:"center",padding:"48px 0",color:"var(--tx-3)"}}>
          <div className="spinner" style={{margin:"0 auto 12px"}}/>
          {mode==="ai"?"AI is finding the perfect songs for you...":"Searching..."}
        </div>
      ) : (
        <>
          {genre && mode==="normal" && (
            <div style={{marginBottom:16,display:"flex",alignItems:"center",gap:8}}>
              <span className="badge badge-purple">{GENRE_EMOJIS[genre]||"🎵"} {genre}</span>
              <button className="btn btn-ghost btn-sm" onClick={()=>setGenre("")}>Clear</button>
            </div>
          )}

          {artists.length > 0 && (
            <section className="section">
              <h2 className="section-title" style={{marginBottom:16}}>Artists</h2>
              <div className="cards-grid">
                {artists.map(a=>(
                  <div key={a.artist} className="song-card"
                    onClick={()=>navigate(`/artist/${encodeURIComponent(a.artist)}`)}>
                    <div className="song-card-art" style={{borderRadius:"50%"}}>
                      {a.cover_url?<img src={a.cover_url} alt="" style={{borderRadius:"50%"}}/>
                        :<div className="song-card-art-placeholder" style={{borderRadius:"50%"}}>🎤</div>}
                    </div>
                    <div className="song-card-title" style={{textAlign:"center"}}>{a.artist}</div>
                    <div className="song-card-artist" style={{textAlign:"center"}}>Artist</div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {songs.length > 0 && (
            <section className="section">
              <h2 className="section-title" style={{marginBottom:16}}>
                {mode==="ai"?"✨ AI-Selected Songs"
                  :query?`Songs for "${query}"`
                  :genre?`${genre} Songs`:"All Songs"}
                <span style={{fontSize:13,color:"var(--tx-3)",fontWeight:400,marginLeft:8}}>
                  {songs.length} results
                </span>
              </h2>
              <div className="song-list-header">
                <span>#</span><span/><span>Title</span>
                <span>Album</span><span>Plays</span><span>Duration</span><span/>
              </div>
              <div className="song-list">
                {songs.map((s,i)=><SongRow key={s.id} song={s} index={i} queue={songs}/>)}
              </div>
            </section>
          )}

          {pls.length > 0 && (
            <section className="section">
              <h2 className="section-title" style={{marginBottom:16}}>Playlists</h2>
              <div className="cards-grid">
                {pls.map(pl=>(
                  <div key={pl.id} className="song-card" onClick={()=>navigate(`/playlist/${pl.id}`)}>
                    <div className="song-card-art">
                      {pl.cover_url?<img src={pl.cover_url} alt=""/>
                        :<div className="song-card-art-placeholder">📋</div>}
                    </div>
                    <div className="song-card-title">{pl.name}</div>
                    <div className="song-card-artist">by {pl.users?.name||"Unknown"}</div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {!loading&&!songs.length&&!pls.length&&!artists.length&&(query||genre)&&(
            <div className="empty-state">
              <div className="empty-state-icon">{mode==="ai"?"🤖":"🔍"}</div>
              <h3>No results found</h3>
              <p>{mode==="ai"?"Try describing a different mood or genre":"Try different keywords"}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
