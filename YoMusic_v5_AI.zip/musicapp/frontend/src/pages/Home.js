import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Play, ChevronRight, Sparkles } from "lucide-react";
import { usePlayerStore, useAuthStore } from "../store";
import SongRow from "../components/SongRow";
import api from "../utils/api";

const GENRE_EMOJIS = { Pop:"🎤",Rock:"🎸",Jazz:"🎷",Classical:"🎻","Hip-Hop":"🎤",
  Electronic:"🎹",RnB:"🎶",Country:"🤠",Afrobeats:"🌍",Gospel:"🙏",Reggae:"🌴",Blues:"🎸",Soul:"💛" };

function SongCard({ song, queue, onPlay }) {
  return (
    <div className="song-card">
      <div className="song-card-art">
        {song.cover_url ? <img src={song.cover_url} alt={song.title}/> : <div className="song-card-art-placeholder">🎵</div>}
        <button className="song-card-play" onClick={() => onPlay(song, queue)}><Play size={18}/></button>
      </div>
      <div className="song-card-title">{song.title}</div>
      <div className="song-card-artist">{song.artist}</div>
    </div>
  );
}

function ArtistCard({ artist, navigate }) {
  return (
    <div className="song-card" onClick={() => navigate(`/artist/${encodeURIComponent(artist.artist)}`)}>
      <div className="song-card-art" style={{borderRadius:"50%"}}>
        {artist.cover_url ? <img src={artist.cover_url} alt="" style={{borderRadius:"50%"}}/> : <div className="song-card-art-placeholder" style={{borderRadius:"50%"}}>🎤</div>}
      </div>
      <div className="song-card-title" style={{textAlign:"center"}}>{artist.artist}</div>
      <div className="song-card-artist" style={{textAlign:"center"}}>Artist</div>
    </div>
  );
}

export default function Home() {
  const [featured,    setFeatured]    = useState([]);
  const [recent,      setRecent]      = useState([]);
  const [recommended, setRecommended] = useState([]);
  const [genres,      setGenres]      = useState([]);
  const [artists,     setArtists]     = useState([]);
  const [albums,      setAlbums]      = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [aiRecs,      setAiRecs]      = useState({ songs:[], reason:"" });
  const { playSong, playQueue } = usePlayerStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.getFeatured(), api.getRecent(), api.getRecommended(),
      api.getGenres(), api.getArtists(), api.getAlbums()
    ]).then(([f,r,rec,g,a,al]) => {
      setFeatured(f); setRecent(r); setRecommended(rec);
      setGenres(g); setArtists(a); setAlbums(al);
    }).catch(()=>{}).finally(()=>setLoading(false));
    // Load AI recs separately (non-blocking)
    api.aiRecommendations().then(r => setAiRecs(r)).catch(()=>{});
  }, []);

  const hour = new Date().getHours();
  const greeting = hour<12?"Good morning":hour<17?"Good afternoon":"Good evening";

  if (loading) return <div className="loading-center"><div className="spinner"/></div>;

  const Section = ({ title, children, link, linkLabel="See all" }) => (
    <section className="section">
      <div className="section-head">
        <h2 className="section-title">{title}</h2>
        {link && <span className="section-link" onClick={() => navigate(link)}>{linkLabel} <ChevronRight size={13}/></span>}
      </div>
      {children}
    </section>
  );

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">{greeting}, {user?.name?.split(" ")[0]} 👋</h1>
        <p className="page-subtitle">What would you like to listen to today?</p>
      </div>

      {/* AI Recommendations */}
      {aiRecs.songs?.length > 0 && (
        <Section title={<span style={{display:"flex",alignItems:"center",gap:8}}><Sparkles size={18} color="var(--accent-2)"/> Just For You</span>}>
          <div style={{fontSize:12,color:"var(--tx-3)",marginBottom:12,display:"flex",alignItems:"center",gap:6}}>
            <Sparkles size={11} color="var(--accent-2)"/>
            {aiRecs.reason}
          </div>
          <div className="cards-grid">
            {aiRecs.songs.slice(0,8).map(s=><SongCard key={s.id} song={s} queue={aiRecs.songs} onPlay={playSong}/>)}
          </div>
        </Section>
      )}

      {/* Quick picks - recent plays as cards */}
      {featured.length > 0 && (
        <Section title="🔥 Most Played" link="/search">
          <div className="cards-grid">
            {featured.slice(0,8).map(s => <SongCard key={s.id} song={s} queue={featured} onPlay={playSong}/>)}
          </div>
        </Section>
      )}

      {/* Recommended */}
      {recommended.length > 0 && (
        <Section title="✨ Recommended for You">
          <div className="song-list-header">
            <span>#</span><span/><span>Title</span><span>Album</span><span>Plays</span><span>Duration</span><span/>
          </div>
          <div className="song-list">
            {recommended.slice(0,6).map((s,i) => (
              <SongRow key={s.id} song={s} index={i} queue={recommended}/>
            ))}
          </div>
        </Section>
      )}

      {/* Recently added */}
      {recent.length > 0 && (
        <Section title="🆕 New Releases">
          <div className="cards-grid">
            {recent.slice(0,8).map(s => <SongCard key={s.id} song={s} queue={recent} onPlay={playSong}/>)}
          </div>
        </Section>
      )}

      {/* Artists */}
      {artists.length > 0 && (
        <Section title="🎤 Artists">
          <div className="cards-grid">
            {artists.slice(0,8).map(a => <ArtistCard key={a.artist} artist={a} navigate={navigate}/>)}
          </div>
        </Section>
      )}

      {/* Albums */}
      {albums.length > 0 && (
        <Section title="💿 Albums">
          <div className="cards-grid">
            {albums.slice(0,8).map(a => (
              <div key={a.album} className="song-card" onClick={() => navigate(`/album/${encodeURIComponent(a.album)}`)}>
                <div className="song-card-art">
                  {a.cover_url ? <img src={a.cover_url} alt=""/> : <div className="song-card-art-placeholder">💿</div>}
                </div>
                <div className="song-card-title">{a.album}</div>
                <div className="song-card-artist">{a.artist}{a.year ? ` · ${a.year}` : ""}</div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Genres */}
      {genres.length > 0 && (
        <Section title="🎭 Browse Genres">
          <div className="genre-grid">
            {genres.map(g => (
              <div key={g} className="genre-pill" onClick={() => navigate(`/search?genre=${encodeURIComponent(g)}`)}>
                <span className="genre-emoji">{GENRE_EMOJIS[g]||"🎵"}</span>{g}
              </div>
            ))}
          </div>
        </Section>
      )}

      {!featured.length && !recent.length && (
        <div className="empty-state">
          <div className="empty-state-icon">🎵</div>
          <h3>No music yet</h3>
          <p>Upload your first song to get started</p>
          <button className="btn btn-primary" style={{marginTop:16}} onClick={() => navigate("/upload")}>
            Upload Music
          </button>
        </div>
      )}
    </div>
  );
}
