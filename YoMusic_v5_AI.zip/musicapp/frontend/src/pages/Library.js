// Library.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, ListMusic } from "lucide-react";
import api from "../utils/api";
import toast from "react-hot-toast";

export function Library() {
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [creating, setCreating]   = useState(false);
  const [name, setName]           = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    api.getPlaylists().then(setPlaylists).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      const f = new FormData(); f.append("name", name);
      const pl = await api.createPlaylist(f);
      setPlaylists(p => [pl, ...p]);
      setName(""); setCreating(false);
      navigate(`/playlist/${pl.id}`);
      toast.success("Playlist created!");
    } catch (err) { toast.error(err.message); }
  };

  const handleDelete = async (id, e) => {
    e.stopPropagation();
    if (!window.confirm("Delete this playlist?")) return;
    try {
      await api.deletePlaylist(id);
      setPlaylists(p => p.filter(x => x.id !== id));
      toast.success("Playlist deleted");
    } catch (err) { toast.error(err.message); }
  };

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;

  return (
    <div className="page">
      <div className="page-header" style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div>
          <h1 className="page-title">Your Library</h1>
          <p className="page-subtitle">{playlists.length} playlists</p>
        </div>
        <button className="btn btn-primary" onClick={() => setCreating(true)}>
          <Plus size={16} /> New Playlist
        </button>
      </div>

      {creating && (
        <form onSubmit={handleCreate} style={{ display:"flex", gap:10, marginBottom:24 }}>
          <input autoFocus value={name} onChange={e => setName(e.target.value)} placeholder="Playlist name" />
          <button type="submit" className="btn btn-primary">Create</button>
          <button type="button" className="btn btn-outline" onClick={() => setCreating(false)}>Cancel</button>
        </form>
      )}

      {playlists.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">📋</div>
          <h3>No playlists yet</h3>
          <p>Create a playlist to organize your music</p>
        </div>
      ) : (
        <div className="cards-grid">
          {playlists.map(pl => (
            <div key={pl.id} className="song-card" onClick={() => navigate(`/playlist/${pl.id}`)}>
              <div className="song-card-art">
                {pl.cover_url
                  ? <img src={pl.cover_url} alt="" />
                  : <div className="song-card-art-placeholder"><ListMusic size={40} /></div>
                }
              </div>
              <div className="song-card-title">{pl.name}</div>
              <div className="song-card-artist" style={{ display:"flex", justifyContent:"space-between" }}>
                <span>{pl.is_public ? "Public" : "Private"}</span>
                <button
                  className="btn-ghost"
                  style={{ fontSize:11, color:"var(--red)", padding:"2px 6px" }}
                  onClick={e => handleDelete(pl.id, e)}
                >Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Library;
