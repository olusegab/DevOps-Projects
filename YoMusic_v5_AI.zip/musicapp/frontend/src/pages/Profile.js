import React, { useState, useRef } from "react";
import { Camera, Crown, Lock } from "lucide-react";
import { useAuthStore } from "../store";
import api from "../utils/api";
import toast from "react-hot-toast";

const ROLE_BADGES = {
  user:       { label:"Free",       color:"#606080",  bg:"#606080" },
  premium:    { label:"Premium",    color:"#f59e0b",  bg:"#f59e0b" },
  admin:      { label:"Admin",      color:"#a855f7",  bg:"#7c3aed" },
  superadmin: { label:"Super Admin",color:"#ef4444",  bg:"#ef4444" },
};

export default function Profile() {
  const { user, refreshUser, isPremium } = useAuthStore();
  const [name, setName]       = useState(user?.name||"");
  const [saving, setSaving]   = useState(false);
  const [preview, setPreview] = useState(null);
  const [avatarFile, setFile] = useState(null);
  const fileRef = useRef(null);

  const badge = ROLE_BADGES[user?.role] || ROLE_BADGES.user;

  const onAvatar = (e) => {
    const f = e.target.files[0]; if (!f) return;
    setFile(f); setPreview(URL.createObjectURL(f));
  };

  const handleSave = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const fd = new FormData(); fd.append("name", name);
      if (avatarFile) fd.append("avatar", avatarFile);
      await api.updateProfile(fd); await refreshUser();
      toast.success("Profile updated!");
    } catch (err) { toast.error(err.message); }
    setSaving(false);
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Your Profile</h1>
        <p className="page-subtitle">Manage your YoMusic account</p>
      </div>

      <div style={{maxWidth:520}}>
        {/* Avatar + role */}
        <div style={{display:"flex",alignItems:"center",gap:24,marginBottom:36,
          padding:24,background:"var(--bg-card)",borderRadius:16,border:"1px solid var(--border)"}}>
          <div style={{position:"relative",flexShrink:0}}>
            <div style={{width:96,height:96,borderRadius:"50%",
              background:"linear-gradient(135deg,var(--accent),var(--accent-2))",
              display:"flex",alignItems:"center",justifyContent:"center",
              overflow:"hidden",fontSize:36,fontWeight:700}}>
              {(preview||user?.avatar_url)
                ? <img src={preview||user.avatar_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                : user?.name?.[0]?.toUpperCase()
              }
            </div>
            <button type="button" onClick={()=>fileRef.current?.click()} style={{
              position:"absolute",bottom:0,right:0,width:30,height:30,borderRadius:"50%",
              background:"var(--accent)",color:"#fff",display:"flex",alignItems:"center",
              justifyContent:"center",cursor:"pointer",border:"2px solid var(--bg-base)"}}>
              <Camera size={14}/>
            </button>
            <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={onAvatar}/>
          </div>
          <div>
            <div style={{fontSize:22,fontWeight:800}}>{user?.name}</div>
            <div style={{fontSize:13,color:"var(--tx-2)",margin:"2px 0 10px"}}>{user?.email}</div>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span style={{
                display:"inline-flex",alignItems:"center",gap:6,
                padding:"4px 12px",borderRadius:99,fontSize:12,fontWeight:700,
                background:`${badge.bg}22`,color:badge.color,border:`1px solid ${badge.bg}55`
              }}>
                {user?.role==="premium"&&<Crown size={12}/>}
                {badge.label}
              </span>
              {!isPremium() && (
                <span style={{fontSize:12,color:"var(--tx-3)"}}>
                  → Ask admin to upgrade to Premium for downloads
                </span>
              )}
            </div>
          </div>
        </div>

        <form onSubmit={handleSave}>
          <div className="form-group">
            <label className="form-label">Display Name</label>
            <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" required/>
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input value={user?.email||""} disabled style={{opacity:.6}}/>
            <span className="form-hint">Email cannot be changed</span>
          </div>
          <button type="submit" className="btn btn-primary" disabled={saving}
            style={{width:"100%",justifyContent:"center",padding:14}}>
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </form>

        {/* Premium features info */}
        <div style={{marginTop:32,padding:20,background:"var(--bg-card)",borderRadius:12,border:"1px solid var(--border)"}}>
          <div style={{fontSize:14,fontWeight:700,marginBottom:14,display:"flex",alignItems:"center",gap:8}}>
            <Crown size={16} color="#f59e0b"/> Premium Features
          </div>
          {[
            ["⬇️ Download songs",   isPremium()],
            ["🎵 Stream all music", true],
            ["📋 Unlimited playlists", true],
            ["🔍 Search & browse",  true],
          ].map(([feat, unlocked]) => (
            <div key={feat} style={{display:"flex",alignItems:"center",gap:10,marginBottom:8,fontSize:13}}>
              {unlocked
                ? <span style={{color:"var(--green)",fontSize:16}}>✓</span>
                : <Lock size={14} color="var(--tx-3)"/>
              }
              <span style={{color:unlocked?"var(--tx-1)":"var(--tx-3)"}}>{feat}</span>
            </div>
          ))}
          {!isPremium() && (
            <div style={{marginTop:12,padding:"10px 14px",background:"var(--accent-glow)",
              borderRadius:8,border:"1px solid var(--accent)",fontSize:12,color:"var(--tx-2)"}}>
              Contact your admin to upgrade your account to Premium and unlock downloads.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
