import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload as UploadIcon, Music, Image, CheckCircle, X } from "lucide-react";
import api from "../utils/api";
import toast from "react-hot-toast";

const GENRES = [
  "Pop","Rock","Jazz","Classical","Hip-Hop","Electronic",
  "RnB","Country","Afrobeats","Gospel","Reggae","Blues","Soul","Other"
];

export default function Upload() {
  const [audioFile, setAudioFile] = useState(null);
  const [coverFile, setCoverFile] = useState(null);
  const [coverPreview, setCoverPreview] = useState(null);
  const [form, setForm] = useState({
    title:"", artist:"", album:"", genre:"", year:"", is_public: true
  });
  const [uploading, setUploading] = useState(false);
  const [progress,  setProgress]  = useState(0);
  const [done,      setDone]      = useState(false);

  // Audio dropzone
  const onDropAudio = useCallback((accepted) => {
    if (!accepted.length) return;
    const f = accepted[0];
    setAudioFile(f);
    // Auto-fill title from filename
    const name = f.name.replace(/\.[^.]+$/, "").replace(/[-_]/g, " ");
    setForm(p => ({ ...p, title: p.title || name }));
  }, []);

  const { getRootProps: getAudioProps, getInputProps: getAudioInput, isDragActive: isDragAudio } =
    useDropzone({ onDrop: onDropAudio, accept: { "audio/*": [".mp3",".wav",".flac",".aac",".ogg",".m4a"] }, maxFiles: 1 });

  // Cover dropzone
  const onDropCover = useCallback((accepted) => {
    if (!accepted.length) return;
    const f = accepted[0];
    setCoverFile(f);
    setCoverPreview(URL.createObjectURL(f));
  }, []);

  const { getRootProps: getCoverProps, getInputProps: getCoverInput, isDragActive: isDragCover } =
    useDropzone({ onDrop: onDropCover, accept: { "image/*": [".jpg",".jpeg",".png",".webp"] }, maxFiles: 1 });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(p => ({ ...p, [name]: type === "checkbox" ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!audioFile) { toast.error("Please select an audio file"); return; }
    if (!form.title.trim()) { toast.error("Title is required"); return; }
    if (!form.artist.trim()) { toast.error("Artist is required"); return; }

    setUploading(true); setProgress(10);

    try {
      const fd = new FormData();
      fd.append("audio_file", audioFile);
      if (coverFile) fd.append("cover_art", coverFile);
      fd.append("title",    form.title);
      fd.append("artist",   form.artist);
      fd.append("album",    form.album);
      fd.append("genre",    form.genre);
      fd.append("year",     form.year || "");
      fd.append("is_public", form.is_public);

      setProgress(40);
      await api.uploadSong(fd);
      setProgress(100);
      setDone(true);
      toast.success("🎵 Song uploaded successfully!");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setUploading(false);
    }
  };

  const reset = () => {
    setAudioFile(null); setCoverFile(null); setCoverPreview(null);
    setForm({ title:"", artist:"", album:"", genre:"", year:"", is_public:true });
    setDone(false); setProgress(0);
  };

  if (done) {
    return (
      <div className="page">
        <div className="empty-state" style={{ paddingTop:80 }}>
          <div style={{ fontSize:64, marginBottom:16 }}>🎉</div>
          <h3 style={{ color:"var(--green)", fontSize:24 }}>Upload Complete!</h3>
          <p>Your song is now live on YoMusic</p>
          <div style={{ display:"flex", gap:12, marginTop:24 }}>
            <button className="btn btn-primary" onClick={reset}>Upload Another</button>
            <a href="/" className="btn btn-outline">Go to Home</a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Upload Music</h1>
        <p className="page-subtitle">Share your music with the world 🌍</p>
      </div>

      <form onSubmit={handleSubmit} style={{ maxWidth:640 }}>
        {/* Audio file */}
        <div className="form-group">
          <label className="form-label">Audio File *</label>
          {audioFile ? (
            <div style={{
              background:"var(--bg-card)", border:"1px solid var(--border)",
              borderRadius:10, padding:"14px 16px",
              display:"flex", alignItems:"center", gap:12
            }}>
              <Music size={20} color="var(--accent-2)" />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:14, fontWeight:600, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {audioFile.name}
                </div>
                <div style={{ fontSize:12, color:"var(--tx-3)" }}>
                  {(audioFile.size / 1024 / 1024).toFixed(1)} MB
                </div>
              </div>
              <button type="button" className="ctrl-btn" onClick={() => setAudioFile(null)}>
                <X size={16} />
              </button>
            </div>
          ) : (
            <div {...getAudioProps()} className={`dropzone ${isDragAudio ? "active" : ""}`}>
              <input {...getAudioInput()} />
              <div className="dropzone-icon">🎵</div>
              <p>Drag & drop your audio file here, or click to browse</p>
              <small>MP3, WAV, FLAC, AAC, OGG, M4A supported</small>
            </div>
          )}
        </div>

        {/* Song details */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Title *</label>
            <input name="title" value={form.title} onChange={handleChange} placeholder="Song title" required />
          </div>
          <div className="form-group">
            <label className="form-label">Artist *</label>
            <input name="artist" value={form.artist} onChange={handleChange} placeholder="Artist name" required />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Album</label>
            <input name="album" value={form.album} onChange={handleChange} placeholder="Album name (optional)" />
          </div>
          <div className="form-group">
            <label className="form-label">Year</label>
            <input name="year" type="number" value={form.year} onChange={handleChange}
              placeholder="e.g. 2024" min="1900" max={new Date().getFullYear()} />
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Genre</label>
          <select name="genre" value={form.genre} onChange={handleChange}>
            <option value="">Select a genre</option>
            {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>

        {/* Cover art */}
        <div className="form-group">
          <label className="form-label">Cover Art</label>
          <div style={{ display:"flex", gap:16, alignItems:"flex-start" }}>
            {coverPreview && (
              <div style={{ position:"relative", flexShrink:0 }}>
                <img src={coverPreview} alt="" style={{ width:100, height:100, borderRadius:8, objectFit:"cover" }} />
                <button
                  type="button"
                  onClick={() => { setCoverFile(null); setCoverPreview(null); }}
                  style={{
                    position:"absolute", top:-6, right:-6,
                    width:20, height:20, borderRadius:"50%",
                    background:"var(--red)", color:"#fff",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:12, cursor:"pointer", border:"none"
                  }}
                >✕</button>
              </div>
            )}
            <div {...getCoverProps()} className={`dropzone ${isDragCover ? "active" : ""}`} style={{ flex:1, padding:20 }}>
              <input {...getCoverInput()} />
              <Image size={24} style={{ margin:"0 auto 8px", display:"block", color:"var(--tx-3)" }} />
              <p style={{ fontSize:13 }}>Drop cover art or click to browse</p>
              <small>JPG, PNG, WEBP (recommended: 500×500px)</small>
            </div>
          </div>
        </div>

        {/* Visibility */}
        <div className="form-group">
          <label style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}>
            <input
              type="checkbox"
              name="is_public"
              checked={form.is_public}
              onChange={handleChange}
              style={{ width:16, height:16 }}
            />
            <span className="form-label" style={{ marginBottom:0 }}>Make this song public</span>
          </label>
          <span className="form-hint">Public songs are visible to all users</span>
        </div>

        {/* Progress */}
        {uploading && (
          <div className="upload-progress">
            <div className="upload-progress-fill" style={{ width:`${progress}%` }} />
          </div>
        )}

        <button
          type="submit"
          className="btn btn-primary"
          disabled={uploading || !audioFile}
          style={{ width:"100%", justifyContent:"center", padding:"14px", marginTop:8 }}
        >
          {uploading ? (
            <><div className="spinner" style={{ width:18, height:18, borderWidth:2 }} /> Uploading...</>
          ) : (
            <><UploadIcon size={16} /> Upload Song</>
          )}
        </button>
      </form>
    </div>
  );
}
