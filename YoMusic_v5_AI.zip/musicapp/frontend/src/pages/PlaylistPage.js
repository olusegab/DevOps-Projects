import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Play, Shuffle, Edit2, Trash2, Sparkles } from "lucide-react";
import SongRow from "../components/SongRow";
import { usePlayerStore, useAuthStore } from "../store";
import api from "../utils/api";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

export default function PlaylistPage() {
  const { id } = useParams();
  const [playlist, setPlaylist] = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [editing,  setEditing]  = useState(false);
  const [naming,   setNaming]   = useState(false);
  const [editName, setEditName] = useState("");
  const { playQueue, toggleShuffle } = usePlayerStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const load = async () => {
    try {
      const pl = await api.getPlaylist(id);
      setPlaylist(pl); setEditName(pl.name);
    } catch (err) { toast.error(err.message); navigate("/library"); }
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  const handleAIName = async () => {
    setNaming(true);
    try {
      const r = await api.aiPlaylistDescribe(id);
      if (r.name) {
        setEditName(r.name);
        const f = new FormData();
        f.append("name", r.name);
        if (r.description) f.append("description", r.description);
        await api.updatePlaylist(id, f);
        setPlaylist(p => ({ ...p, name: r.name, description: r.description }));
        toast.success(`✨ AI named it: "${r.name}"`);
      }
    } catch (err) { toast.error(err.message); }
    setNaming(false);
  };

  const handlePlay = (startIndex = 0) => {
    if (!playlist?.songs?.length) return;
    playQueue(playlist.songs, startIndex);
  };

  const handleShuffle = () => {
    if (!playlist?.songs?.length) return;
    const idx = Math.floor(Math.random() * playlist.songs.length);
    playQueue(playlist.songs, idx);
    toggleShuffle();
  };

  const handleSaveEdit = async () => {
    try {
      const f = new FormData(); f.append("name", editName);
      await api.updatePlaylist(id, f);
      setPlaylist(p => ({ ...p, name: editName }));
      setEditing(false);
      toast.success("Playlist updated!");
    } catch (err) { toast.error(err.message); }
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this playlist?")) return;
    try {
      await api.deletePlaylist(id);
      toast.success("Playlist deleted"); navigate("/library");
    } catch (err) { toast.error(err.message); }
  };

  const handleRemoveSong = async (songId) => {
    try {
      await api.removeFromPlaylist(id, songId);
      setPlaylist(p => ({ ...p, songs: p.songs.filter(s => s.id !== songId) }));
      toast.success("Removed from playlist");
    } catch (err) { toast.error(err.message); }
  };

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;
  if (!playlist) return null;

  const isOwner = user?.id === playlist.user_id || user?.role === "admin";
  const songs   = playlist.songs || [];

  return (
    <div>
      <div className="playlist-hero">
        <div className="playlist-hero-art">
          {playlist.cover_url
            ? <img src={playlist.cover_url} alt="" />
            : <div className="playlist-hero-art-ph">🎵</div>
          }
        </div>
        <div className="playlist-hero-info">
          <div className="playlist-hero-type">Playlist</div>
          {editing ? (
            <div style={{ display:"flex", gap:8, alignItems:"center", margin:"8px 0" }}>
              <input
                value={editName}
                onChange={e => setEditName(e.target.value)}
                style={{ fontSize:24, fontWeight:800, background:"var(--bg-card)" }}
                autoFocus
              />
              <button className="btn btn-primary btn-sm" onClick={handleSaveEdit}>Save</button>
              <button className="btn btn-outline btn-sm" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          ) : (
            <div className="playlist-hero-name">{playlist.name}</div>
          )}
          <div className="playlist-hero-meta">
            by {playlist.users?.name} · {songs.length} songs
            · {playlist.is_public ? "Public" : "Private"}
          </div>

          <div style={{ display:"flex", gap:12, marginTop:20, flexWrap:"wrap" }}>
            <button className="btn btn-primary" onClick={() => handlePlay(0)} disabled={!songs.length}>
              <Play size={16} /> Play
            </button>
            <button className="btn btn-outline" onClick={handleShuffle} disabled={!songs.length}>
              <Shuffle size={16} /> Shuffle
            </button>
            {isOwner && (
              <>
                <button className="btn btn-outline" onClick={() => setEditing(true)}>
                  <Edit2 size={14} /> Edit
                </button>
                <button className="btn btn-outline" onClick={handleAIName} disabled={naming||!songs.length}>
                  {naming ? <><div className="spinner" style={{width:12,height:12,borderWidth:2}}/> Naming...</>
                    : <><Sparkles size={14}/> AI Name</>}
                </button>
                <button className="btn btn-danger btn-sm" onClick={handleDelete}>
                  <Trash2 size={14} /> Delete
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="page" style={{ paddingTop:0 }}>
        {songs.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">🎵</div>
            <h3>No songs yet</h3>
            <p>Search for songs and add them to this playlist</p>
          </div>
        ) : (
          <>
            <div className="song-list-header">
              <span>#</span><span></span><span>Title</span>
              <span>Album</span><span>Plays</span><span>Duration</span><span></span>
            </div>
            <div className="song-list">
              {songs.map((s, i) => (
                <SongRow
                  key={s.id} song={s} index={i} queue={songs}
                  playlistId={id}
                  onRemoveFromPlaylist={isOwner ? handleRemoveSong : undefined}
                  onDelete={(sid) => setPlaylist(p => ({ ...p, songs: p.songs.filter(x => x.id !== sid) }))}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
