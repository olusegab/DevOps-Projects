import React, { useEffect, useState } from "react";
import { Heart, Clock } from "lucide-react";
import SongRow from "../components/SongRow";
import { usePlayerStore } from "../store";
import api from "../utils/api";

export function LikedSongs() {
  const [songs, setSongs]   = useState([]);
  const [loading, setLoading] = useState(true);
  const { playQueue } = usePlayerStore();

  useEffect(() => {
    api.getLikedSongs().then(setSongs).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;

  return (
    <div>
      <div className="playlist-hero" style={{ background:"linear-gradient(180deg,#4c1d95 0%,var(--bg-base) 100%)" }}>
        <div className="playlist-hero-art" style={{ background:"linear-gradient(135deg,#7c3aed,#a855f7)" }}>
          <div className="playlist-hero-art-ph"><Heart size={72} fill="white" color="white" /></div>
        </div>
        <div className="playlist-hero-info">
          <div className="playlist-hero-type">Playlist</div>
          <div className="playlist-hero-name">Liked Songs</div>
          <div className="playlist-hero-meta">{songs.length} songs</div>
          {songs.length > 0 && (
            <button className="btn btn-primary" style={{ marginTop:20 }} onClick={() => playQueue(songs)}>
              <Heart size={16} /> Play All
            </button>
          )}
        </div>
      </div>

      <div className="page" style={{ paddingTop:0 }}>
        {songs.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">💜</div>
            <h3>No liked songs yet</h3>
            <p>Like songs to find them here easily</p>
          </div>
        ) : (
          <>
            <div className="song-list-header">
              <span>#</span><span></span><span>Title</span>
              <span>Album</span><span>Plays</span><span>Duration</span><span></span>
            </div>
            <div className="song-list">
              {songs.map((s, i) => (
                <SongRow
                  key={s.id} song={s} index={i} queue={songs}
                  onDelete={sid => setSongs(p => p.filter(x => x.id !== sid))}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export function History() {
  const [songs, setSongs]     = useState([]);
  const [loading, setLoading] = useState(true);
  const { playQueue } = usePlayerStore();

  useEffect(() => {
    api.getHistory(50).then(setSongs).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Recently Played</h1>
        <p className="page-subtitle">{songs.length} songs in your history</p>
      </div>

      {songs.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">🕐</div>
          <h3>No history yet</h3>
          <p>Songs you play will appear here</p>
        </div>
      ) : (
        <>
          <div style={{ marginBottom:16 }}>
            <button className="btn btn-primary" onClick={() => playQueue(songs)}>
              <Clock size={16} /> Play All
            </button>
          </div>
          <div className="song-list-header">
            <span>#</span><span></span><span>Title</span>
            <span>Album</span><span>Plays</span><span>Duration</span><span></span>
          </div>
          <div className="song-list">
            {songs.map((s, i) => (
              <SongRow key={s.id + i} song={s} index={i} queue={songs} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default LikedSongs;
