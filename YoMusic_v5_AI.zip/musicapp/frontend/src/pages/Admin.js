import React, { useEffect, useState, useCallback } from "react";
import { Shield, Users, Music, Play, Download, TrendingUp,
         Globe, Monitor, Smartphone, RefreshCw, Map, Sparkles } from "lucide-react";
import api from "../utils/api";
import toast from "react-hot-toast";

const TABS = ["overview","traffic","ai insights","map","users","songs","downloads"];
const DAYS_OPTIONS = [1,7,14,30];

// ── Mini bar chart ────────────────────────────────────────────────────────────
function BarChart({ data, xKey, yKey, color="#7c3aed", height=120 }) {
  if (!data?.length) return <div style={{height,display:"flex",alignItems:"center",justifyContent:"center",color:"var(--tx-3)",fontSize:13}}>No data</div>;
  const max = Math.max(...data.map(d=>d[yKey]||0)) || 1;
  return (
    <div style={{display:"flex",alignItems:"flex-end",gap:3,height,width:"100%"}}>
      {data.map((d,i)=>(
        <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
          <div style={{width:"100%",background:color,borderRadius:"3px 3px 0 0",
            height:`${Math.max(((d[yKey]||0)/max)*100,2)}%`,
            opacity:0.85,transition:"height .3s"}}/>
          <span style={{fontSize:9,color:"var(--tx-3)",transform:"rotate(-45deg)",
            transformOrigin:"top left",whiteSpace:"nowrap",marginTop:2}}>
            {String(d[xKey]).slice(5)}
          </span>
        </div>
      ))}
    </div>
  );
}

// ── Donut chart ───────────────────────────────────────────────────────────────
function DonutChart({ data, nameKey, valueKey }) {
  if (!data?.length) return <div style={{color:"var(--tx-3)",fontSize:13,textAlign:"center",padding:20}}>No data</div>;
  const total  = data.reduce((a,d)=>a+(d[valueKey]||0),0)||1;
  const COLORS = ["#7c3aed","#22c55e","#f59e0b","#3b82f6","#ef4444","#06b6d4","#ec4899"];
  let angle = -90;
  const segments = data.slice(0,7).map((d,i)=>{
    const pct  = (d[valueKey]||0)/total;
    const deg  = pct*360;
    const seg  = { ...d, pct, deg, startAngle: angle, color: COLORS[i%COLORS.length] };
    angle += deg;
    return seg;
  });
  const polarToCart=(cx,cy,r,a)=>({x:cx+r*Math.cos((a*Math.PI)/180),y:cy+r*Math.sin((a*Math.PI)/180)});
  const describeArc=(cx,cy,r,sa,ea)=>{
    const s=polarToCart(cx,cy,r,sa); const e=polarToCart(cx,cy,r,ea);
    const large=ea-sa<=180?"0":"1";
    return `M${cx},${cy} L${s.x},${s.y} A${r},${r},0,${large},1,${e.x},${e.y} Z`;
  };
  return (
    <div style={{display:"flex",gap:20,alignItems:"center",flexWrap:"wrap"}}>
      <svg width={120} height={120} viewBox="0 0 120 120">
        {segments.map((s,i)=>(
          <path key={i} d={describeArc(60,60,50,s.startAngle,s.startAngle+s.deg-0.5)}
            fill={s.color} opacity={0.9}/>
        ))}
        <circle cx={60} cy={60} r={28} fill="var(--bg-surface)"/>
        <text x={60} y={64} textAnchor="middle" fill="var(--tx-1)" fontSize={11} fontWeight={700}>{total}</text>
      </svg>
      <div style={{display:"flex",flexDirection:"column",gap:6}}>
        {segments.map((s,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",gap:8,fontSize:12}}>
            <div style={{width:10,height:10,borderRadius:2,background:s.color,flexShrink:0}}/>
            <span style={{color:"var(--tx-2)"}}>{s[nameKey]}</span>
            <span style={{marginLeft:"auto",fontWeight:600,color:"var(--tx-1)"}}>{s[valueKey]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── World Map (SVG) ───────────────────────────────────────────────────────────
function WorldMap({ points }) {
  const latLonToXY = (lat, lon) => ({
    x: ((lon + 180) / 360) * 800,
    y: ((90 - lat) / 180) * 400,
  });
  return (
    <div style={{ background:"var(--bg-card)", borderRadius:12, overflow:"hidden", position:"relative" }}>
      <svg viewBox="0 0 800 400" style={{ width:"100%", background:"#0d1117", display:"block" }}>
        {/* Simple world outline paths */}
        <rect width={800} height={400} fill="#0d1117"/>
        {/* Grid lines */}
        {[-60,-30,0,30,60].map(lat=>(
          <line key={lat} x1={0} y1={latLonToXY(lat,0).y} x2={800} y2={latLonToXY(lat,0).y}
            stroke="#1e2a1e" strokeWidth={0.5}/>
        ))}
        {[-120,-60,0,60,120].map(lon=>(
          <line key={lon} x1={latLonToXY(0,lon).x} y1={0} x2={latLonToXY(0,lon).x} y2={400}
            stroke="#1e2a1e" strokeWidth={0.5}/>
        ))}
        {/* Data points */}
        {points.map((p,i)=>{
          const {x,y} = latLonToXY(p.lat, p.lon);
          return (
            <g key={i}>
              <circle cx={x} cy={y} r={5} fill={p.event==="play"?"#7c3aed":"#22c55e"} opacity={0.7}>
                <animate attributeName="r" values="4;8;4" dur="2s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.7;0.3;0.7" dur="2s" repeatCount="indefinite"/>
              </circle>
              <circle cx={x} cy={y} r={2} fill={p.event==="play"?"#a855f7":"#4ade80"}/>
            </g>
          );
        })}
      </svg>
      <div style={{ position:"absolute", bottom:12, left:12, display:"flex", gap:16, fontSize:11 }}>
        <span style={{ display:"flex", alignItems:"center", gap:4 }}>
          <span style={{ width:8,height:8,borderRadius:"50%",background:"#7c3aed",display:"inline-block"}}/>
          Play event
        </span>
        <span style={{ display:"flex", alignItems:"center", gap:4 }}>
          <span style={{ width:8,height:8,borderRadius:"50%",background:"#22c55e",display:"inline-block"}}/>
          Other event
        </span>
      </div>
    </div>
  );
}

// ── Main Admin Component ───────────────────────────────────────────────────────
export default function Admin() {
  const [tab,       setTab]       = useState("overview");
  const [stats,     setStats]     = useState(null);
  const [traffic,   setTraffic]   = useState(null);
  const [live,      setLive]      = useState(null);
  const [topSongs,  setTopSongs]  = useState([]);
  const [users,     setUsers]     = useState([]);
  const [songs,     setSongs]     = useState([]);
  const [downloads, setDownloads] = useState([]);
  const [days,      setDays]      = useState(7);
  const [loading,   setLoading]   = useState(true);
  const [aiInsights, setAiInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [refreshing,setRefreshing]= useState(false);

  const loadAll = useCallback(async () => {
    setRefreshing(true);
    try {
      const [s, t, l, ts, u, so] = await Promise.all([
        api.adminStats(),
        api.adminTrafficOverview(days),
        api.adminTrafficLive(),
        api.adminTopSongs(days),
        api.adminUsers(),
        api.getSongs({ limit:100 }),
      ]);
      setStats(s); setTraffic(t); setLive(l);
      setTopSongs(ts); setUsers(u); setSongs(so.songs||[]);
    } catch(err) { toast.error(err.message); }
    setLoading(false); setRefreshing(false);
  }, [days]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const loadInsights = async () => {
    setLoadingInsights(true);
    try { const r = await api.aiTrafficInsights(days); setAiInsights(r); }
    catch (err) { console.error(err); }
    setLoadingInsights(false);
  };

  // Refresh live every 30s
  useEffect(() => {
    const t = setInterval(() => api.adminTrafficLive().then(setLive).catch(()=>{}), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (tab === "downloads") api.adminDownloads().then(setDownloads).catch(()=>{});
  }, [tab]);

  const setRole = async (uid, role) => {
    try { await api.setUserRole(uid, role); setUsers(u=>u.map(x=>x.id===uid?{...x,role}:x)); toast.success("Role updated!"); }
    catch(err) { toast.error(err.message); }
  };
  const deleteSong = async (id) => {
    if (!window.confirm("Delete this song?")) return;
    try { await api.deleteSong(id); setSongs(s=>s.filter(x=>x.id!==id)); toast.success("Deleted"); }
    catch(err) { toast.error(err.message); }
  };

  if (loading) return <div className="loading-center"><div className="spinner"/></div>;

  return (
    <div className="page">
      {/* Header */}
      <div className="page-header" style={{display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:12}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <Shield size={28} color="var(--accent-2)"/>
          <div>
            <h1 className="page-title">Admin Dashboard</h1>
            <p className="page-subtitle">YoMusic platform management</p>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          {/* Live indicator */}
          <div style={{display:"flex",alignItems:"center",gap:6,padding:"6px 12px",
            background:"var(--bg-card)",borderRadius:99,border:"1px solid var(--border)",fontSize:12}}>
            <span style={{width:8,height:8,borderRadius:"50%",background:"var(--green)",
              boxShadow:"0 0 6px var(--green)",animation:"pulse 2s infinite"}}/>
            <strong style={{color:"var(--green)"}}>{live?.active_now||0}</strong>
            <span style={{color:"var(--tx-3)"}}>active now</span>
          </div>
          <select value={days} onChange={e=>setDays(Number(e.target.value))}
            style={{padding:"6px 10px",fontSize:12,width:"auto",borderRadius:8}}>
            {DAYS_OPTIONS.map(d=><option key={d} value={d}>Last {d}d</option>)}
          </select>
          <button className="btn btn-outline btn-sm" onClick={loadAll} disabled={refreshing}>
            <RefreshCw size={14} style={{animation:refreshing?"spin .7s linear infinite":"none"}}/> Refresh
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:2,marginBottom:28,borderBottom:"1px solid var(--border)"}}>
        {TABS.map(t=>(
          <button key={t} onClick={()=>setTab(t)} style={{
            padding:"10px 16px",fontSize:13,fontWeight:600,background:"none",border:"none",
            color:tab===t?"var(--tx-1)":"var(--tx-3)",cursor:"pointer",
            borderBottom:tab===t?"2px solid var(--accent-2)":"2px solid transparent",
            textTransform:"capitalize",transition:"all .15s"
          }}>{t}</button>
        ))}
      </div>

      {/* ── OVERVIEW ── */}
      {tab==="overview" && (
        <>
          {/* Stat cards */}
          <div className="stats-grid" style={{gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))"}}>
            {[
              {icon:<Music size={22}/>,    label:"Songs",       val:stats?.total_songs,     c:"#a855f7"},
              {icon:<Users size={22}/>,    label:"Users",       val:stats?.total_users,     c:"#22c55e"},
              {icon:<Play size={22}/>,     label:"Total Plays", val:stats?.total_plays,     c:"#3b82f6"},
              {icon:<Download size={22}/>, label:"Downloads",   val:stats?.total_downloads, c:"#f59e0b"},
              {icon:<TrendingUp size={22}/>,label:"Traffic 24h",val:stats?.traffic_24h,    c:"#06b6d4"},
              {icon:<Users size={22}/>,    label:"Premium",     val:stats?.premium_users,   c:"#ec4899"},
            ].map(({icon,label,val,c})=>(
              <div key={label} className="stat-card">
                <div style={{color:c,marginBottom:8}}>{icon}</div>
                <div className="stat-card-value" style={{color:c,fontSize:26}}>{(val||0).toLocaleString()}</div>
                <div className="stat-card-label">{label}</div>
              </div>
            ))}
          </div>

          {/* Daily plays chart */}
          <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:12,padding:20,marginBottom:20}}>
            <div style={{fontSize:15,fontWeight:700,marginBottom:16}}>📈 Daily Activity (Last {days} days)</div>
            <BarChart data={traffic?.daily||[]} xKey="date" yKey="plays" color="#7c3aed" height={140}/>
          </div>

          {/* Top streamed songs */}
          <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:12,padding:20}}>
            <div style={{fontSize:15,fontWeight:700,marginBottom:16}}>🔥 Top Streamed Songs</div>
            {topSongs.length ? topSongs.map((s,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderBottom:"1px solid var(--border)"}}>
                <span style={{width:24,textAlign:"center",color:"var(--tx-3)",fontSize:13,fontWeight:700}}>#{i+1}</span>
                <div style={{flex:1,fontSize:14,fontWeight:500}}>{s.song}</div>
                <span style={{fontSize:13,color:"var(--accent-2)",fontWeight:700}}>{s.plays} plays</span>
              </div>
            )) : <div style={{color:"var(--tx-3)",fontSize:13}}>No play data yet</div>}
          </div>
        </>
      )}

      {/* ── TRAFFIC ── */}
      {tab==="traffic" && (
        <>
          {/* Summary */}
          <div className="stats-grid" style={{gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",marginBottom:24}}>
            {[
              {label:"Total Events",   val:traffic?.summary?.total_events,    c:"var(--accent-2)"},
              {label:"Unique Visitors",val:traffic?.summary?.unique_visitors,  c:"#22c55e"},
              {label:"Streams",        val:traffic?.summary?.total_plays,      c:"#3b82f6"},
              {label:"Searches",       val:traffic?.summary?.total_searches,   c:"#f59e0b"},
              {label:"Logins",         val:traffic?.summary?.total_logins,     c:"#06b6d4"},
            ].map(({label,val,c})=>(
              <div key={label} className="stat-card">
                <div className="stat-card-value" style={{color:c,fontSize:24}}>{(val||0).toLocaleString()}</div>
                <div className="stat-card-label">{label}</div>
              </div>
            ))}
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:20}}>
            {/* By country */}
            <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:12,padding:20}}>
              <div style={{fontSize:15,fontWeight:700,marginBottom:14}}>🌍 Top Countries</div>
              {(traffic?.by_country||[]).slice(0,10).map((c,i)=>(
                <div key={i} style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                  <span style={{fontSize:13,color:"var(--tx-3)",width:18}}>{i+1}</span>
                  <span style={{flex:1,fontSize:13,fontWeight:500}}>{c.country}</span>
                  <div style={{width:80,height:6,background:"var(--bg-hover)",borderRadius:99,overflow:"hidden"}}>
                    <div style={{height:"100%",background:"var(--accent)",borderRadius:99,
                      width:`${((c.count/(traffic?.by_country?.[0]?.count||1))*100)}%`}}/>
                  </div>
                  <span style={{fontSize:12,color:"var(--tx-2)",width:28,textAlign:"right"}}>{c.count}</span>
                </div>
              ))}
            </div>

            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              {/* By device */}
              <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:12,padding:20,flex:1}}>
                <div style={{fontSize:15,fontWeight:700,marginBottom:14}}>📱 By Device</div>
                <DonutChart data={traffic?.by_device||[]} nameKey="device" valueKey="count"/>
              </div>
              {/* By browser */}
              <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:12,padding:20,flex:1}}>
                <div style={{fontSize:15,fontWeight:700,marginBottom:14}}>🌐 By Browser</div>
                <DonutChart data={traffic?.by_browser||[]} nameKey="browser" valueKey="count"/>
              </div>
            </div>
          </div>

          {/* Live feed */}
          <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:12,padding:20}}>
            <div style={{fontSize:15,fontWeight:700,marginBottom:14,display:"flex",alignItems:"center",gap:8}}>
              <span style={{width:8,height:8,borderRadius:"50%",background:"var(--green)",display:"inline-block",animation:"pulse 2s infinite"}}/>
              Live Activity (Last 30 min)
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:4,maxHeight:280,overflowY:"auto"}}>
              {(live?.recent_events||[]).slice(0,20).map((e,i)=>(
                <div key={i} style={{display:"grid",gridTemplateColumns:"90px 70px 80px 80px 1fr",
                  gap:8,fontSize:11,padding:"6px 8px",borderRadius:6,
                  background:i%2===0?"transparent":"rgba(255,255,255,.02)",alignItems:"center"}}>
                  <span style={{color:"var(--tx-3)"}}>{e.timestamp?.slice(11,19)||""}</span>
                  <span style={{
                    padding:"2px 8px",borderRadius:99,fontSize:10,fontWeight:700,textAlign:"center",
                    background:e.event_type==="play"?"#7c3aed22":e.event_type==="login"?"#22c55e22":"#3b82f622",
                    color:e.event_type==="play"?"#a855f7":e.event_type==="login"?"#22c55e":"#3b82f6"
                  }}>{e.event_type}</span>
                  <span style={{color:"var(--tx-2)"}}>{e.country||"—"}</span>
                  <span style={{color:"var(--tx-3)"}}>{e.device||"—"}</span>
                  <span style={{color:"var(--tx-3)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{e.city||""} {e.isp?`· ${e.isp}`:""}</span>
                </div>
              ))}
              {!live?.recent_events?.length && <div style={{color:"var(--tx-3)",fontSize:13}}>No recent activity</div>}
            </div>
          </div>
        </>
      )}


      {/* ── AI INSIGHTS ── */}
      {tab==="ai insights" && (
        <div>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:24}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <Sparkles size={22} color="var(--accent-2)"/>
              <div>
                <div style={{fontSize:16,fontWeight:700}}>AI Traffic Insights</div>
                <div style={{fontSize:13,color:"var(--tx-2)"}}>Plain English analysis of your platform data</div>
              </div>
            </div>
            <button className="btn btn-primary" onClick={loadInsights} disabled={loadingInsights}>
              {loadingInsights
                ?<><div className="spinner" style={{width:14,height:14,borderWidth:2}}/> Analyzing...</>
                :<><Sparkles size={14}/> Generate Insights</>
              }
            </button>
          </div>

          {!aiInsights && !loadingInsights && (
            <div style={{textAlign:"center",padding:"60px 24px",background:"var(--bg-card)",
              borderRadius:16,border:"1px solid var(--border)"}}>
              <div style={{fontSize:48,marginBottom:16}}>🤖</div>
              <div style={{fontSize:16,fontWeight:700,marginBottom:8}}>AI Traffic Analysis</div>
              <div style={{fontSize:14,color:"var(--tx-2)",maxWidth:360,margin:"0 auto 24px",lineHeight:1.6}}>
                Click "Generate Insights" and AI will read your traffic data and write
                a plain English business summary with actionable recommendations.
              </div>
              <button className="btn btn-primary" onClick={loadInsights}>
                <Sparkles size={15}/> Generate Insights for Last {days} Days
              </button>
            </div>
          )}

          {loadingInsights && (
            <div style={{textAlign:"center",padding:"60px 24px"}}>
              <div className="spinner" style={{margin:"0 auto 16px"}}/>
              <div style={{fontSize:14,color:"var(--tx-2)"}}>AI is analyzing your traffic data...</div>
            </div>
          )}

          {aiInsights && !loadingInsights && (
            <div style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:16,padding:28}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <Sparkles size={16} color="var(--accent-2)"/>
                  <span style={{fontSize:13,fontWeight:600,color:"var(--tx-2)"}}>
                    Analysis for last {aiInsights.period_days} days
                  </span>
                  {aiInsights.ai_powered && <span className="badge badge-purple">AI</span>}
                </div>
                <button className="btn btn-ghost btn-sm" onClick={loadInsights}>
                  <RefreshCw size={13}/> Refresh
                </button>
              </div>
              <div style={{
                fontSize:14,lineHeight:1.8,color:"var(--tx-1)",
                whiteSpace:"pre-wrap",fontFamily:"inherit"
              }}>
                {aiInsights.insights}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── MAP ── */
      {tab==="map" && (
        <div>
          <div style={{marginBottom:16,display:"flex",alignItems:"center",gap:10}}>
            <Globe size={20} color="var(--accent-2)"/>
            <span style={{fontSize:16,fontWeight:700}}>Streaming Locations</span>
            <span style={{fontSize:12,color:"var(--tx-3)"}}>{(traffic?.geo_points||[]).length} events plotted</span>
          </div>
          <WorldMap points={traffic?.geo_points||[]}/>
          <div style={{marginTop:20,display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:12}}>
            {(traffic?.by_country||[]).slice(0,12).map((c,i)=>(
              <div key={i} style={{background:"var(--bg-card)",border:"1px solid var(--border)",borderRadius:10,
                padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:13,fontWeight:500}}>{c.country}</span>
                <span style={{fontSize:18,fontWeight:800,color:"var(--accent-2)"}}>{c.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── USERS ── */}
      {tab==="users" && (
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead>
              <tr style={{borderBottom:"1px solid var(--border)"}}>
                {["User","Email","Role","Joined","Change Role"].map(h=>(
                  <th key={h} style={{padding:"10px 12px",textAlign:"left",fontSize:11,fontWeight:700,
                    textTransform:"uppercase",letterSpacing:".8px",color:"var(--tx-3)"}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map(u=>(
                <tr key={u.id} style={{borderBottom:"1px solid var(--border)"}}>
                  <td style={{padding:12}}>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <div style={{width:32,height:32,borderRadius:"50%",
                        background:"linear-gradient(135deg,var(--accent),var(--accent-2))",
                        display:"flex",alignItems:"center",justifyContent:"center",
                        fontSize:13,fontWeight:700,overflow:"hidden",flexShrink:0}}>
                        {u.avatar_url?<img src={u.avatar_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>:u.name?.[0]?.toUpperCase()}
                      </div>
                      <span style={{fontSize:14,fontWeight:500}}>{u.name}</span>
                    </div>
                  </td>
                  <td style={{padding:12,fontSize:13,color:"var(--tx-2)"}}>{u.email}</td>
                  <td style={{padding:12}}>
                    <span className={`badge ${
                      u.role==="superadmin"?"badge-purple":
                      u.role==="admin"?"badge-purple":
                      u.role==="premium"?"badge-green":"badge-gray"}`}>{u.role}</span>
                  </td>
                  <td style={{padding:12,fontSize:12,color:"var(--tx-3)"}}>{new Date(u.created_at).toLocaleDateString()}</td>
                  <td style={{padding:12}}>
                    <select value={u.role} onChange={e=>setRole(u.id,e.target.value)}
                      style={{padding:"5px 8px",fontSize:12,width:"auto",borderRadius:8}}>
                      <option value="user">User</option>
                      <option value="premium">Premium</option>
                      <option value="admin">Admin</option>
                      <option value="superadmin">Super Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── SONGS ── */}
      {tab==="songs" && (
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead>
              <tr style={{borderBottom:"1px solid var(--border)"}}>
                {["Song","Artist","Genre","Plays","Visibility","Action"].map(h=>(
                  <th key={h} style={{padding:"10px 12px",textAlign:"left",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:".8px",color:"var(--tx-3)"}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {songs.map(s=>(
                <tr key={s.id} style={{borderBottom:"1px solid var(--border)"}}>
                  <td style={{padding:12}}>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <div style={{width:36,height:36,borderRadius:6,background:"var(--bg-hover)",overflow:"hidden",flexShrink:0}}>
                        {s.cover_url?<img src={s.cover_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<div style={{display:"flex",alignItems:"center",justifyContent:"center",width:"100%",height:"100%",fontSize:16}}>🎵</div>}
                      </div>
                      <span style={{fontSize:13,fontWeight:500}}>{s.title}</span>
                    </div>
                  </td>
                  <td style={{padding:12,fontSize:13,color:"var(--tx-2)"}}>{s.artist}</td>
                  <td style={{padding:12}}>{s.genre?<span className="badge badge-gray">{s.genre}</span>:<span style={{color:"var(--tx-3)"}}>—</span>}</td>
                  <td style={{padding:12,fontSize:13,fontWeight:600,color:"var(--accent-2)"}}>{(s.play_count||0).toLocaleString()}</td>
                  <td style={{padding:12}}>
                    <span className={`badge ${s.is_public?"badge-green":"badge-gray"}`}>{s.is_public?"Public":"Private"}</span>
                  </td>
                  <td style={{padding:12}}>
                    <button className="btn btn-danger btn-sm" onClick={()=>deleteSong(s.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── DOWNLOADS ── */}
      {tab==="downloads" && (
        <div>
          <div style={{marginBottom:16,fontSize:15,fontWeight:700,display:"flex",alignItems:"center",gap:8}}>
            <Download size={18} color="var(--accent-2)"/> Premium Downloads Log
          </div>
          <div style={{overflowX:"auto"}}>
            <table style={{width:"100%",borderCollapse:"collapse"}}>
              <thead>
                <tr style={{borderBottom:"1px solid var(--border)"}}>
                  {["User","Song","Artist","Downloaded At"].map(h=>(
                    <th key={h} style={{padding:"10px 12px",textAlign:"left",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:".8px",color:"var(--tx-3)"}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {downloads.map((d,i)=>(
                  <tr key={i} style={{borderBottom:"1px solid var(--border)"}}>
                    <td style={{padding:12,fontSize:13}}>{d.users?.name||"—"} <span style={{fontSize:11,color:"var(--tx-3)"}}>({d.users?.email||""})</span></td>
                    <td style={{padding:12,fontSize:13,fontWeight:500}}>{d.songs?.title||"—"}</td>
                    <td style={{padding:12,fontSize:13,color:"var(--tx-2)"}}>{d.songs?.artist||"—"}</td>
                    <td style={{padding:12,fontSize:12,color:"var(--tx-3)"}}>{new Date(d.downloaded_at).toLocaleString()}</td>
                  </tr>
                ))}
                {!downloads.length&&<tr><td colSpan={4} style={{padding:32,textAlign:"center",color:"var(--tx-3)",fontSize:13}}>No downloads yet</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
