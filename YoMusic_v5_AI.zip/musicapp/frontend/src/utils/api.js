const BASE = process.env.REACT_APP_API_URL || "http://localhost:8000";
const tok  = () => localStorage.getItem("ym_token");

async function req(method, path, body, isForm = false) {
  const headers = {};
  const t = tok();
  if (t) headers["Authorization"] = `Bearer ${t}`;
  let fetchBody;
  if (body) {
    if (isForm) { fetchBody = body; }
    else { headers["Content-Type"] = "application/json"; fetchBody = JSON.stringify(body); }
  }
  const res  = await fetch(`${BASE}${path}`, { method, headers, body: fetchBody });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

const api = {
  // Auth
  register:      (name,email,pw)  => { const f=new FormData();f.append("name",name);f.append("email",email);f.append("password",pw);return req("POST","/api/auth/register",f,true); },
  login:         (email,pw)       => { const f=new FormData();f.append("email",email);f.append("password",pw);return req("POST","/api/auth/login",f,true); },
  me:            ()               => req("GET","/api/auth/me"),
  updateProfile: (fd)             => req("PUT","/api/auth/me",fd,true),

  // Songs
  getSongs:       (p={})   => { const q=new URLSearchParams(p).toString(); return req("GET",`/api/songs${q?"?"+q:""}`); },
  getFeatured:    ()        => req("GET","/api/songs/featured"),
  getRecent:      ()        => req("GET","/api/songs/recent"),
  getGenres:      ()        => req("GET","/api/songs/genres"),
  getArtists:     ()        => req("GET","/api/songs/artists"),
  getAlbums:      ()        => req("GET","/api/songs/albums"),
  getNewReleases: ()        => req("GET","/api/songs/new-releases"),
  getRecommended: ()        => req("GET","/api/songs/recommended"),
  getSong:        (id)      => req("GET",`/api/songs/${id}`),
  getSongsByArtist:(a)      => req("GET",`/api/songs/artist/${encodeURIComponent(a)}`),
  getSongsByAlbum: (a)      => req("GET",`/api/songs/album/${encodeURIComponent(a)}`),
  playSong:       (id)      => req("POST",`/api/songs/${id}/play`),
  downloadSong:   (id)      => req("GET",`/api/songs/${id}/download`),
  uploadSong:     (fd)      => req("POST","/api/songs/upload",fd,true),
  updateSong:     (id,fd)   => req("PUT",`/api/songs/${id}`,fd,true),
  deleteSong:     (id)      => req("DELETE",`/api/songs/${id}`),

  // Playlists
  getPlaylists:       ()        => req("GET","/api/playlists"),
  getPublicPlaylists: ()        => req("GET","/api/playlists/public"),
  createPlaylist:     (fd)      => req("POST","/api/playlists",fd,true),
  getPlaylist:        (id)      => req("GET",`/api/playlists/${id}`),
  updatePlaylist:     (id,fd)   => req("PUT",`/api/playlists/${id}`,fd,true),
  deletePlaylist:     (id)      => req("DELETE",`/api/playlists/${id}`),
  addToPlaylist:      (pl,song) => { const f=new FormData();f.append("song_id",song);return req("POST",`/api/playlists/${pl}/songs`,f,true); },
  removeFromPlaylist: (pl,song) => req("DELETE",`/api/playlists/${pl}/songs/${song}`),

  // Likes & History
  getLiked:     ()    => req("GET","/api/likes"),
  toggleLike:   (id)  => req("POST",`/api/likes/${id}`),
  checkLike:    (id)  => req("GET",`/api/likes/${id}`),
  getHistory:   (n=30)=> req("GET",`/api/history?limit=${n}`),
  addHistory:   (id)  => req("POST",`/api/history/${id}`),

  // Search
  search: (q) => req("GET",`/api/search?q=${encodeURIComponent(q)}`),

  // AI
  aiRecommendations:  ()           => req("GET","/api/ai/recommendations"),
  aiMoodPlaylist:     (mood)       => { const f=new FormData();f.append("mood",mood);return req("POST","/api/ai/mood-playlist",f,true); },
  aiSearch:           (q)          => req("GET",`/api/ai/search?q=${encodeURIComponent(q)}`),
  aiTrafficInsights:  (days=7)     => req("GET",`/api/ai/traffic-insights?days=${days}`),
  aiScreenSubmission: (fd)         => req("POST","/api/ai/screen-submission",fd,true),
  aiPlaylistDescribe: (playlist_id)=> { const f=new FormData();f.append("playlist_id",playlist_id);return req("POST","/api/ai/playlist-describe",f,true); },

  // Admin
  adminStats:          ()        => req("GET","/api/admin/stats"),
  adminUsers:          ()        => req("GET","/api/admin/users"),
  setUserRole:         (uid,role)=> { const f=new FormData();f.append("role",role);return req("PUT",`/api/admin/users/${uid}/role`,f,true); },
  adminTrafficOverview:(days=7)  => req("GET",`/api/admin/traffic/overview?days=${days}`),
  adminTrafficLive:    ()        => req("GET","/api/admin/traffic/live"),
  adminTopSongs:       (days=7)  => req("GET",`/api/admin/traffic/top-songs?days=${days}`),
  adminDownloads:      ()        => req("GET","/api/admin/downloads"),
};
export default api;
