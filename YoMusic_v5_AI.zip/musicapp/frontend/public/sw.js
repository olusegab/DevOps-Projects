/* YoMusic Service Worker v1 */
const CACHE_NAME    = "yomusic-v1";
const RUNTIME_CACHE = "yomusic-runtime-v1";

// Files to cache immediately on install (app shell)
const PRECACHE_URLS = [
  "/",
  "/index.html",
  "/manifest.json",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
];

// ── Install: cache app shell ────────────────────────────────────────────────
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

// ── Activate: clean old caches ──────────────────────────────────────────────
self.addEventListener("activate", (event) => {
  const current = [CACHE_NAME, RUNTIME_CACHE];
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => !current.includes(k)).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// ── Fetch: serve from cache or network ─────────────────────────────────────
self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET and API calls (always fresh from network)
  if (request.method !== "GET") return;
  if (url.pathname.startsWith("/api/")) return;

  // Audio files: network-first (stream), fallback to cache
  if (url.pathname.match(/\.(mp3|wav|flac|aac|ogg|m4a)$/i)) {
    event.respondWith(
      fetch(request)
        .then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, clone));
          }
          return res;
        })
        .catch(() => caches.match(request))
    );
    return;
  }

  // Images/covers: cache-first (fast load)
  if (url.pathname.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i)) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, clone));
          }
          return res;
        });
      })
    );
    return;
  }

  // JS/CSS app shell: cache-first, update in background (stale-while-revalidate)
  if (url.pathname.match(/\.(js|css)$/i) || url.pathname === "/" || url.pathname === "/index.html") {
    event.respondWith(
      caches.match(request).then((cached) => {
        const fetchPromise = fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return res;
        });
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Everything else: network with cache fallback
  event.respondWith(
    fetch(request)
      .then((res) => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, clone));
        }
        return res;
      })
      .catch(() => caches.match(request).then((cached) => cached || caches.match("/index.html")))
  );
});

// ── Background Sync (for play count when offline) ───────────────────────────
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-plays") {
    event.waitUntil(syncOfflinePlays());
  }
});

async function syncOfflinePlays() {
  // When back online, sync any queued play events
  const cache  = await caches.open(RUNTIME_CACHE);
  const keys   = await cache.keys();
  const queued = keys.filter((k) => k.url.includes("offline-play-queue"));
  for (const key of queued) {
    const data = await (await cache.match(key)).json();
    try {
      await fetch(`/api/songs/${data.songId}/play`, { method: "POST" });
      await cache.delete(key);
    } catch {}
  }
}

// ── Push Notifications ───────────────────────────────────────────────────────
self.addEventListener("push", (event) => {
  if (!event.data) return;
  const data = event.data.json();
  event.waitUntil(
    self.registration.showNotification(data.title || "YoMusic", {
      body:    data.body || "New music added!",
      icon:    "/icons/icon-192.png",
      badge:   "/icons/icon-96.png",
      vibrate: [200, 100, 200],
      data:    { url: data.url || "/" },
      actions: [
        { action: "open",    title: "Open YoMusic" },
        { action: "dismiss", title: "Dismiss" },
      ],
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  if (event.action === "dismiss") return;
  const url = event.notification.data?.url || "/";
  event.waitUntil(
    clients.matchAll({ type: "window" }).then((clientList) => {
      const existing = clientList.find((c) => c.url === url && "focus" in c);
      if (existing) return existing.focus();
      return clients.openWindow(url);
    })
  );
});

// ── Media Session API (lock screen controls) ────────────────────────────────
self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
  if (event.data?.type === "UPDATE_MEDIA_SESSION") {
    // Handled in main thread via navigator.mediaSession
  }
});
