# 🎵 YoMusic — Full-Stack Music Streaming App

A Spotify-like music streaming platform you own completely.
Upload your own music, stream it anywhere, manage users.

---

## 🚀 Tech Stack (All Free)

| Layer      | Tech                        | Hosting         |
|------------|-----------------------------|-----------------|
| Backend    | Python + FastAPI            | Render.com      |
| Database   | PostgreSQL (via Supabase)   | Supabase (free) |
| Storage    | Supabase Storage            | Supabase (free) |
| Frontend   | React                       | Vercel (free)   |
| Auth       | Custom JWT                  | Built-in        |

---

## 📦 Project Structure

```
yomusic/
├── backend/
│   ├── main.py           ← FastAPI app (all API routes)
│   ├── schema.sql        ← Database schema (run once in Supabase)
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── App.js
    │   ├── index.css
    │   ├── store/index.js       ← Zustand state (auth + player)
    │   ├── utils/api.js         ← All API calls
    │   ├── components/
    │   │   ├── Layout.js        ← Sidebar + topbar shell
    │   │   ├── Player.js        ← Audio player bar
    │   │   └── SongRow.js       ← Song list item + context menu
    │   └── pages/
    │       ├── Home.js          ← Featured, recent, genres
    │       ├── Search.js        ← Search + genre browse
    │       ├── Library.js       ← Your playlists
    │       ├── PlaylistPage.js  ← Playlist detail
    │       ├── LikedSongs.js    ← Liked + History pages
    │       ├── Upload.js        ← Drag & drop upload
    │       ├── Login.js         ← Login + Register
    │       ├── Profile.js       ← Edit profile
    │       └── Admin.js         ← Admin dashboard
    └── .env.example
```

---

## ⚙️ Step 1 — Set Up Supabase (Free)

1. Go to **https://supabase.com** → Sign up → Create new project
2. Note your **Project URL** and **Service Role Key** (Settings → API)
3. Go to **SQL Editor** → paste entire contents of `backend/schema.sql` → Run
4. Go to **Storage** → confirm `music` and `artwork` buckets were created
   - If not: create them manually, set both to **Public**

---

## ⚙️ Step 2 — Run Backend Locally

```bash
cd backend

# Copy env file
cp .env.example .env
# Edit .env — add your Supabase URL + Key + a random JWT secret

# Install dependencies
pip install -r requirements.txt

# Start server
python main.py
# → API running at http://localhost:8000
# → API docs at http://localhost:8000/api/docs
```

---

## ⚙️ Step 3 — Run Frontend Locally

```bash
cd frontend

# Copy env file
cp .env.example .env
# REACT_APP_API_URL=http://localhost:8000 (already set for local)

# Install dependencies
npm install

# Start app
npm start
# → Opens http://localhost:3000
```

---

## 🌍 Step 4 — Deploy Backend to Render (Free)

1. Push your backend folder to a GitHub repo
2. Go to **https://render.com** → New Web Service → Connect your repo
3. Settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Environment:** Python 3
4. Add environment variables (same as your `.env`):
   - `SUPABASE_URL`
   - `SUPABASE_KEY`
   - `JWT_SECRET`
5. Deploy — you'll get a URL like `https://yomusic-api.onrender.com`

---

## 🌍 Step 5 — Deploy Frontend to Vercel (Free)

1. Push your frontend folder to a GitHub repo
2. Go to **https://vercel.com** → New Project → Import your repo
3. Add environment variable:
   - `REACT_APP_API_URL` = your Render backend URL (e.g. `https://yomusic-api.onrender.com`)
4. Deploy — you'll get a URL like `https://yomusic.vercel.app`

---

## ✨ Features

### For Users
- 🎵 Stream music with full player controls
- ⏭️ Skip, shuffle, repeat (one/all)
- 💜 Like songs
- 📋 Create & manage playlists
- 🕐 Play history
- 🔍 Search by title, artist, album, genre
- 🎭 Browse by genre
- 📱 Fully responsive (mobile + desktop)

### For Admins (first user registered = auto admin)
- ⬆️ Upload songs (drag & drop, MP3/WAV/FLAC/AAC)
- 🖼️ Custom cover art per song
- 🛡️ Admin dashboard: stats, manage users, delete songs
- 👥 Promote/demote users

---

## 🔑 First Time Login

1. Open the app → click **Sign up free**
2. **The very first user to register automatically becomes Admin**
3. You can then upload music via the Upload page
4. Share the app URL with others — they register as regular users

---

## 📡 API Endpoints

| Method | Endpoint                        | Description              |
|--------|---------------------------------|--------------------------|
| POST   | /api/auth/register              | Register                 |
| POST   | /api/auth/login                 | Login                    |
| GET    | /api/auth/me                    | Current user             |
| GET    | /api/songs                      | List songs (+ search)    |
| POST   | /api/songs/upload               | Upload song              |
| GET    | /api/songs/featured             | Top played               |
| POST   | /api/songs/:id/play             | Increment play count     |
| GET    | /api/playlists                  | My playlists             |
| POST   | /api/playlists                  | Create playlist          |
| POST   | /api/playlists/:id/songs        | Add song to playlist     |
| GET    | /api/likes                      | Liked songs              |
| POST   | /api/likes/:id                  | Toggle like              |
| GET    | /api/history                    | Play history             |
| GET    | /api/search?q=                  | Search                   |
| GET    | /api/admin/stats                | Admin stats              |

Full interactive docs: `http://localhost:8000/api/docs`

---

## 💡 Tips

- Supabase free tier: 500MB storage, 2GB bandwidth/month — good for ~100+ songs
- Render free tier: spins down after inactivity — upgrade ($7/mo) for always-on
- For higher storage, switch to Cloudflare R2 (free 10GB) by changing the upload logic
- Keep your `JWT_SECRET` secret and long (32+ random characters)
