"""
🎵 YoMusic API - Complete Music Streaming Backend
Features: Auth, Streaming, Playlists, Likes, History,
          Traffic Monitoring, Geolocation, Premium/Download
"""

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from datetime import datetime, timedelta, timezone
from typing import Optional, List
from dotenv import load_dotenv
import uuid, os, httpx, asyncio
from supabase import create_client, Client
import jwt as pyjwt

load_dotenv()

SUPABASE_URL     = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY     = os.getenv("SUPABASE_KEY", "")
JWT_SECRET       = os.getenv("JWT_SECRET", "yomusic-secret-change-this-32chars")
JWT_ALGORITHM    = "HS256"
JWT_EXPIRE_HOURS = 24 * 7
MUSIC_BUCKET     = "music"
ART_BUCKET       = "artwork"

app = FastAPI(title="YoMusic API", version="2.0.0", docs_url="/api/docs")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

# ── Supabase ──────────────────────────────────────────────────────────────────
def get_sb() -> Client:
    if not SUPABASE_URL or not SUPABASE_KEY:
        raise HTTPException(500, "Supabase not configured")
    return create_client(SUPABASE_URL, SUPABASE_KEY)

# ── Auth helpers ──────────────────────────────────────────────────────────────
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer  = HTTPBearer(auto_error=False)

def hash_pw(pw): return pwd_ctx.hash(pw)
def verify_pw(plain, hashed): return pwd_ctx.verify(plain, hashed)

def make_token(uid, email, role):
    return pyjwt.encode({
        "sub": uid, "email": email, "role": role,
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRE_HOURS),
        "iat": datetime.now(timezone.utc),
    }, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_token(token):
    try:
        return pyjwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except pyjwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except Exception:
        raise HTTPException(401, "Invalid token")

async def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if not creds: raise HTTPException(401, "Not authenticated")
    return decode_token(creds.credentials)

async def optional_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if not creds: return None
    try: return decode_token(creds.credentials)
    except: return None

async def admin_user(user=Depends(current_user)):
    if user.get("role") not in ("admin", "superadmin"):
        raise HTTPException(403, "Admin required")
    return user

async def premium_or_admin(user=Depends(current_user)):
    if user.get("role") not in ("premium", "admin", "superadmin"):
        raise HTTPException(403, "Premium subscription required")
    return user

# ── DB helpers ────────────────────────────────────────────────────────────────
def db_user_by_email(sb, email):
    r = sb.table("users").select("*").eq("email", email).execute()
    return r.data[0] if r.data else None

def db_user_by_id(sb, uid):
    r = sb.table("users").select("*").eq("id", uid).execute()
    return r.data[0] if r.data else None

def safe_user(u):
    return {k: v for k, v in u.items() if k != "password_hash"}

# ── Geolocation ───────────────────────────────────────────────────────────────
async def get_geo(ip: str) -> dict:
    """Free geolocation via ip-api.com (no key needed, 45 req/min)"""
    if not ip or ip in ("127.0.0.1", "::1", "localhost"):
        return {"country": "Local", "country_code": "LO", "city": "Local", "lat": 0, "lon": 0, "isp": "Local"}
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            r = await client.get(f"http://ip-api.com/json/{ip}?fields=status,country,countryCode,city,lat,lon,isp,org,regionName")
            d = r.json()
            if d.get("status") == "success":
                return {
                    "country": d.get("country", "Unknown"),
                    "country_code": d.get("countryCode", "??"),
                    "city": d.get("city", "Unknown"),
                    "region": d.get("regionName", ""),
                    "lat": d.get("lat", 0),
                    "lon": d.get("lon", 0),
                    "isp": d.get("isp", "Unknown"),
                }
    except Exception:
        pass
    return {"country": "Unknown", "country_code": "??", "city": "Unknown", "lat": 0, "lon": 0, "isp": "Unknown"}

def get_real_ip(request: Request) -> str:
    cf = request.headers.get("CF-Connecting-IP")
    if cf: return cf
    fwd = request.headers.get("X-Forwarded-For")
    if fwd: return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"

def get_device(request: Request) -> str:
    ua = request.headers.get("user-agent", "").lower()
    if "mobile" in ua or "android" in ua or "iphone" in ua: return "mobile"
    if "tablet" in ua or "ipad" in ua: return "tablet"
    return "desktop"

def get_browser(request: Request) -> str:
    ua = request.headers.get("user-agent", "").lower()
    if "chrome" in ua and "edg" not in ua: return "Chrome"
    if "firefox" in ua: return "Firefox"
    if "safari" in ua and "chrome" not in ua: return "Safari"
    if "edg" in ua: return "Edge"
    return "Other"

async def log_traffic(sb, request: Request, user_id: Optional[str], event_type: str, meta: dict = {}):
    """Log every significant event for traffic analytics"""
    try:
        ip = get_real_ip(request)
        geo = await get_geo(ip)
        sb.table("traffic_logs").insert({
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "ip_address": ip,
            "event_type": event_type,  # play, search, login, upload, page_view
            "country": geo.get("country"),
            "country_code": geo.get("country_code"),
            "city": geo.get("city"),
            "region": geo.get("region"),
            "lat": geo.get("lat"),
            "lon": geo.get("lon"),
            "isp": geo.get("isp"),
            "device": get_device(request),
            "browser": get_browser(request),
            "meta": str(meta),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }).execute()
    except Exception as e:
        pass  # Never let analytics break the main request

# ══════════════════════════════════════════════════════════════════════════════
# AUTH ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/")
async def root(): return {"name": "YoMusic API", "version": "2.0.0", "docs": "/api/docs"}

@app.get("/api/health")
async def health(): return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}

@app.post("/api/auth/register")
async def register(
    request: Request,
    name: str = Form(...), email: str = Form(...), password: str = Form(...),
):
    sb = get_sb()
    if db_user_by_email(sb, email): raise HTTPException(400, "Email already registered")
    if len(password) < 6: raise HTTPException(400, "Password must be at least 6 characters")
    uid = str(uuid.uuid4())
    # First user = superadmin
    count = sb.table("users").select("id", count="exact").execute().count or 0
    role = "superadmin" if count == 0 else "user"
    user = {
        "id": uid, "name": name, "email": email,
        "password_hash": hash_pw(password), "role": role,
        "avatar_url": None, "created_at": datetime.now(timezone.utc).isoformat(),
    }
    sb.table("users").insert(user).execute()
    asyncio.create_task(log_traffic(sb, request, uid, "register", {"email": email}))
    token = make_token(uid, email, role)
    return {"token": token, "user": safe_user(user)}

@app.post("/api/auth/login")
async def login(request: Request, email: str = Form(...), password: str = Form(...)):
    sb = get_sb()
    user = db_user_by_email(sb, email)
    if not user or not verify_pw(password, user["password_hash"]):
        raise HTTPException(401, "Invalid email or password")
    asyncio.create_task(log_traffic(sb, request, user["id"], "login", {"email": email}))
    token = make_token(user["id"], email, user.get("role", "user"))
    return {"token": token, "user": safe_user(user)}

@app.get("/api/auth/me")
async def me(user=Depends(current_user)):
    sb = get_sb()
    u = db_user_by_id(sb, user["sub"])
    if not u: raise HTTPException(404, "User not found")
    return safe_user(u)

@app.put("/api/auth/me")
async def update_me(
    name: Optional[str] = Form(None),
    avatar: Optional[UploadFile] = File(None),
    user=Depends(current_user),
):
    sb = get_sb(); updates = {}
    if name: updates["name"] = name
    if avatar:
        data = await avatar.read()
        ext  = avatar.filename.rsplit(".", 1)[-1]
        path = f"avatars/{user['sub']}.{ext}"
        sb.storage.from_(ART_BUCKET).upload(path, data, {"content-type": avatar.content_type, "upsert": "true"})
        updates["avatar_url"] = sb.storage.from_(ART_BUCKET).get_public_url(path)
    if updates: sb.table("users").update(updates).eq("id", user["sub"]).execute()
    return safe_user(db_user_by_id(sb, user["sub"]))

# ══════════════════════════════════════════════════════════════════════════════
# SONGS ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/songs")
async def list_songs(
    search: Optional[str] = None, genre: Optional[str] = None,
    artist: Optional[str] = None, album: Optional[str] = None,
    limit: int = 50, offset: int = 0,
):
    sb = get_sb()
    q  = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name,avatar_url)").eq("is_public", True)
    if search: q = q.or_(f"title.ilike.%{search}%,artist.ilike.%{search}%,album.ilike.%{search}%")
    if genre:  q = q.eq("genre", genre)
    if artist: q = q.ilike("artist", f"%{artist}%")
    if album:  q = q.ilike("album", f"%{album}%")
    r = q.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return {"songs": r.data, "total": len(r.data), "offset": offset}

@app.get("/api/songs/featured")
async def featured():
    sb = get_sb()
    r  = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name)").eq("is_public", True)\
           .order("play_count", desc=True).limit(12).execute()
    return r.data

@app.get("/api/songs/recent")
async def recent():
    sb = get_sb()
    r  = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name)").eq("is_public", True)\
           .order("created_at", desc=True).limit(20).execute()
    return r.data

@app.get("/api/songs/genres")
async def genres():
    sb = get_sb()
    r  = sb.table("songs").select("genre").eq("is_public", True).execute()
    return sorted(set(s["genre"] for s in r.data if s.get("genre")))

@app.get("/api/songs/artists")
async def artists():
    sb = get_sb()
    r  = sb.table("songs").select("artist, cover_url").eq("is_public", True).execute()
    seen = {}
    for s in r.data:
        a = s["artist"]
        if a not in seen: seen[a] = {"artist": a, "cover_url": s.get("cover_url")}
    return sorted(seen.values(), key=lambda x: x["artist"])

@app.get("/api/songs/albums")
async def albums():
    sb = get_sb()
    r  = sb.table("songs").select("album, artist, cover_url, year").eq("is_public", True).not_.is_("album", "null").execute()
    seen = {}
    for s in r.data:
        k = f"{s['album']}|{s['artist']}"
        if k not in seen: seen[k] = {"album": s["album"], "artist": s["artist"], "cover_url": s.get("cover_url"), "year": s.get("year")}
    return sorted(seen.values(), key=lambda x: x["album"] or "")

@app.get("/api/songs/new-releases")
async def new_releases():
    sb = get_sb()
    r  = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name)").eq("is_public", True)\
           .order("created_at", desc=True).limit(8).execute()
    return r.data

@app.get("/api/songs/recommended")
async def recommended(user=Depends(optional_user)):
    sb = get_sb()
    if user:
        hist = sb.table("play_history").select("songs(genre, artist)").eq("user_id", user["sub"])\
                 .order("played_at", desc=True).limit(20).execute()
        genres_played  = [h["songs"]["genre"]  for h in hist.data if h.get("songs") and h["songs"].get("genre")]
        artists_played = [h["songs"]["artist"] for h in hist.data if h.get("songs") and h["songs"].get("artist")]
        if genres_played:
            top_genre = max(set(genres_played), key=genres_played.count)
            r = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name)").eq("is_public", True)\
                  .eq("genre", top_genre).order("play_count", desc=True).limit(10).execute()
            if r.data: return r.data
    r = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name)").eq("is_public", True)\
          .order("play_count", desc=True).limit(10).execute()
    return r.data

@app.get("/api/songs/{song_id}")
async def get_song(song_id: str):
    sb = get_sb()
    r  = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name,avatar_url)").eq("id", song_id).execute()
    if not r.data: raise HTTPException(404, "Song not found")
    return r.data[0]

@app.get("/api/songs/artist/{artist_name}")
async def songs_by_artist(artist_name: str):
    sb = get_sb()
    r  = sb.table("songs").select("*").eq("is_public", True).ilike("artist", artist_name)\
           .order("created_at", desc=True).execute()
    return r.data

@app.get("/api/songs/album/{album_name}")
async def songs_by_album(album_name: str):
    sb = get_sb()
    r  = sb.table("songs").select("*").eq("is_public", True).ilike("album", album_name)\
           .order("created_at", desc=True).execute()
    return r.data

@app.post("/api/songs/{song_id}/play")
async def play_song(song_id: str, request: Request, user=Depends(optional_user)):
    sb  = get_sb()
    r   = sb.table("songs").select("play_count, title, artist").eq("id", song_id).execute()
    if not r.data: raise HTTPException(404, "Song not found")
    cnt = (r.data[0].get("play_count") or 0) + 1
    sb.table("songs").update({"play_count": cnt}).eq("id", song_id).execute()
    uid = user["sub"] if user else None
    asyncio.create_task(log_traffic(sb, request, uid, "play", {
        "song_id": song_id, "title": r.data[0].get("title"), "artist": r.data[0].get("artist")
    }))
    return {"play_count": cnt}

@app.get("/api/songs/{song_id}/download")
async def download_song(song_id: str, user=Depends(premium_or_admin)):
    """Premium/Admin only download"""
    sb = get_sb()
    r  = sb.table("songs").select("*").eq("id", song_id).execute()
    if not r.data: raise HTTPException(404, "Song not found")
    song = r.data[0]
    # Log the download
    sb.table("downloads").insert({
        "id": str(uuid.uuid4()), "user_id": user["sub"],
        "song_id": song_id, "downloaded_at": datetime.now(timezone.utc).isoformat()
    }).execute()
    return {"download_url": song["audio_url"], "filename": f"{song['artist']} - {song['title']}.mp3"}

@app.post("/api/songs/upload")
async def upload_song(
    request: Request,
    title: str = Form(...), artist: str = Form(...),
    album: Optional[str] = Form(None), genre: Optional[str] = Form(None),
    year: Optional[int] = Form(None), is_public: bool = Form(True),
    duration: Optional[int] = Form(None),
    audio_file: UploadFile = File(...),
    cover_art: Optional[UploadFile] = File(None),
    user=Depends(admin_user),
):
    sb      = get_sb()
    song_id = str(uuid.uuid4())
    audio_d = await audio_file.read()
    ext     = audio_file.filename.rsplit(".", 1)[-1].lower()
    a_path  = f"songs/{song_id}.{ext}"
    sb.storage.from_(MUSIC_BUCKET).upload(a_path, audio_d, {"content-type": audio_file.content_type or "audio/mpeg", "upsert": "true"})
    audio_url = sb.storage.from_(MUSIC_BUCKET).get_public_url(a_path)

    art_url = None
    if cover_art:
        art_d   = await cover_art.read()
        art_ext = cover_art.filename.rsplit(".", 1)[-1].lower()
        c_path  = f"covers/{song_id}.{art_ext}"
        sb.storage.from_(ART_BUCKET).upload(c_path, art_d, {"content-type": cover_art.content_type or "image/jpeg", "upsert": "true"})
        art_url = sb.storage.from_(ART_BUCKET).get_public_url(c_path)

    song = {
        "id": song_id, "title": title, "artist": artist,
        "album": album, "genre": genre, "year": year,
        "audio_url": audio_url, "cover_url": art_url,
        "is_public": is_public, "play_count": 0,
        "duration": duration or 0,
        "uploaded_by": user["sub"],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    sb.table("songs").insert(song).execute()
    asyncio.create_task(log_traffic(sb, request, user["sub"], "upload", {"song_id": song_id, "title": title}))
    return song

@app.put("/api/songs/{song_id}")
async def update_song(
    song_id: str,
    title: Optional[str] = Form(None), artist: Optional[str] = Form(None),
    album: Optional[str] = Form(None), genre: Optional[str] = Form(None),
    year: Optional[int] = Form(None), is_public: Optional[bool] = Form(None),
    duration: Optional[int] = Form(None),
    cover_art: Optional[UploadFile] = File(None),
    user=Depends(current_user),
):
    sb = get_sb()
    r  = sb.table("songs").select("*").eq("id", song_id).execute()
    if not r.data: raise HTTPException(404, "Song not found")
    song = r.data[0]
    if song["uploaded_by"] != user["sub"] and user.get("role") not in ("admin","superadmin"):
        raise HTTPException(403, "Not authorized")
    updates = {k: v for k, v in {"title":title,"artist":artist,"album":album,"genre":genre,"year":year,"is_public":is_public,"duration":duration}.items() if v is not None}
    if cover_art:
        art_d   = await cover_art.read()
        art_ext = cover_art.filename.rsplit(".", 1)[-1]
        c_path  = f"covers/{song_id}.{art_ext}"
        sb.storage.from_(ART_BUCKET).upload(c_path, art_d, {"content-type": cover_art.content_type, "upsert": "true"})
        updates["cover_url"] = sb.storage.from_(ART_BUCKET).get_public_url(c_path)
    if updates: sb.table("songs").update(updates).eq("id", song_id).execute()
    return {**song, **updates}

@app.delete("/api/songs/{song_id}")
async def delete_song(song_id: str, user=Depends(current_user)):
    sb = get_sb()
    r  = sb.table("songs").select("*").eq("id", song_id).execute()
    if not r.data: raise HTTPException(404, "Song not found")
    if r.data[0]["uploaded_by"] != user["sub"] and user.get("role") not in ("admin","superadmin"):
        raise HTTPException(403, "Not authorized")
    sb.table("songs").delete().eq("id", song_id).execute()
    return {"message": "Deleted"}

# ══════════════════════════════════════════════════════════════════════════════
# PLAYLISTS
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/playlists")
async def my_playlists(user=Depends(current_user)):
    sb = get_sb()
    r  = sb.table("playlists").select("*").eq("user_id", user["sub"]).order("created_at", desc=True).execute()
    return r.data

@app.get("/api/playlists/public")
async def public_playlists():
    sb = get_sb()
    r  = sb.table("playlists").select("*, users!playlists_user_id_fkey(name)")\
           .eq("is_public", True).order("created_at", desc=True).limit(20).execute()
    return r.data

@app.post("/api/playlists")
async def create_playlist(
    name: str = Form(...), description: Optional[str] = Form(None),
    is_public: bool = Form(False), user=Depends(current_user),
):
    sb = get_sb()
    pl = {"id": str(uuid.uuid4()), "name": name, "description": description,
          "is_public": is_public, "user_id": user["sub"], "cover_url": None,
          "created_at": datetime.now(timezone.utc).isoformat()}
    sb.table("playlists").insert(pl).execute()
    return pl

@app.get("/api/playlists/{pl_id}")
async def get_playlist(pl_id: str, user=Depends(optional_user)):
    sb = get_sb()
    r  = sb.table("playlists").select("*, users!playlists_user_id_fkey(name,avatar_url)").eq("id", pl_id).execute()
    if not r.data: raise HTTPException(404, "Playlist not found")
    pl = r.data[0]
    if not pl["is_public"] and (not user or pl["user_id"] != user.get("sub")):
        raise HTTPException(403, "Private playlist")
    sr = sb.table("playlist_songs").select("*, songs(*, users!songs_uploaded_by_fkey(name))")\
           .eq("playlist_id", pl_id).order("position").execute()
    pl["songs"] = [s["songs"] for s in sr.data if s.get("songs")]
    return pl

@app.put("/api/playlists/{pl_id}")
async def update_playlist(
    pl_id: str, name: Optional[str] = Form(None),
    description: Optional[str] = Form(None), is_public: Optional[bool] = Form(None),
    user=Depends(current_user),
):
    sb = get_sb()
    r  = sb.table("playlists").select("user_id").eq("id", pl_id).execute()
    if not r.data or r.data[0]["user_id"] != user["sub"]: raise HTTPException(403, "Not authorized")
    updates = {k: v for k, v in {"name":name,"description":description,"is_public":is_public}.items() if v is not None}
    sb.table("playlists").update(updates).eq("id", pl_id).execute()
    return {**r.data[0], **updates}

@app.delete("/api/playlists/{pl_id}")
async def delete_playlist(pl_id: str, user=Depends(current_user)):
    sb = get_sb()
    r  = sb.table("playlists").select("user_id").eq("id", pl_id).execute()
    if not r.data or r.data[0]["user_id"] != user["sub"]: raise HTTPException(403, "Not authorized")
    sb.table("playlists").delete().eq("id", pl_id).execute()
    return {"message": "Deleted"}

@app.post("/api/playlists/{pl_id}/songs")
async def add_to_playlist(pl_id: str, song_id: str = Form(...), user=Depends(current_user)):
    sb = get_sb()
    pl = sb.table("playlists").select("user_id").eq("id", pl_id).execute()
    if not pl.data or pl.data[0]["user_id"] != user["sub"]: raise HTTPException(403, "Not authorized")
    exists = sb.table("playlist_songs").select("id").eq("playlist_id", pl_id).eq("song_id", song_id).execute()
    if exists.data: raise HTTPException(400, "Song already in playlist")
    pos_r = sb.table("playlist_songs").select("position").eq("playlist_id", pl_id).order("position", desc=True).limit(1).execute()
    pos   = (pos_r.data[0]["position"] + 1) if pos_r.data else 1
    entry = {"id": str(uuid.uuid4()), "playlist_id": pl_id, "song_id": song_id, "position": pos}
    sb.table("playlist_songs").insert(entry).execute()
    return entry

@app.delete("/api/playlists/{pl_id}/songs/{song_id}")
async def remove_from_playlist(pl_id: str, song_id: str, user=Depends(current_user)):
    sb = get_sb()
    pl = sb.table("playlists").select("user_id").eq("id", pl_id).execute()
    if not pl.data or pl.data[0]["user_id"] != user["sub"]: raise HTTPException(403, "Not authorized")
    sb.table("playlist_songs").delete().eq("playlist_id", pl_id).eq("song_id", song_id).execute()
    return {"message": "Removed"}

# ══════════════════════════════════════════════════════════════════════════════
# LIKES / HISTORY
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/likes")
async def liked_songs(user=Depends(current_user)):
    sb = get_sb()
    r  = sb.table("likes").select("*, songs(*, users!songs_uploaded_by_fkey(name))")\
           .eq("user_id", user["sub"]).order("created_at", desc=True).execute()
    return [i["songs"] for i in r.data if i.get("songs")]

@app.post("/api/likes/{song_id}")
async def toggle_like(song_id: str, user=Depends(current_user)):
    sb  = get_sb()
    ex  = sb.table("likes").select("id").eq("user_id", user["sub"]).eq("song_id", song_id).execute()
    if ex.data:
        sb.table("likes").delete().eq("user_id", user["sub"]).eq("song_id", song_id).execute()
        return {"liked": False}
    sb.table("likes").insert({"id": str(uuid.uuid4()), "user_id": user["sub"], "song_id": song_id,
                               "created_at": datetime.now(timezone.utc).isoformat()}).execute()
    return {"liked": True}

@app.get("/api/likes/{song_id}")
async def check_like(song_id: str, user=Depends(current_user)):
    sb = get_sb()
    r  = sb.table("likes").select("id").eq("user_id", user["sub"]).eq("song_id", song_id).execute()
    return {"liked": bool(r.data)}

@app.get("/api/history")
async def history(limit: int = 30, user=Depends(current_user)):
    sb = get_sb()
    r  = sb.table("play_history").select("*, songs(*, users!songs_uploaded_by_fkey(name))")\
           .eq("user_id", user["sub"]).order("played_at", desc=True).limit(limit).execute()
    return [i["songs"] for i in r.data if i.get("songs")]

@app.post("/api/history/{song_id}")
async def add_history(song_id: str, user=Depends(current_user)):
    sb = get_sb()
    sb.table("play_history").insert({
        "id": str(uuid.uuid4()), "user_id": user["sub"],
        "song_id": song_id, "played_at": datetime.now(timezone.utc).isoformat()
    }).execute()
    return {"ok": True}

# ══════════════════════════════════════════════════════════════════════════════
# SEARCH
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/search")
async def search(q: str, request: Request, user=Depends(optional_user)):
    if not q or len(q) < 2: return {"songs": [], "playlists": [], "artists": []}
    sb    = get_sb()
    songs = sb.table("songs").select("*, users!songs_uploaded_by_fkey(name)").eq("is_public", True)\
               .or_(f"title.ilike.%{q}%,artist.ilike.%{q}%,album.ilike.%{q}%,genre.ilike.%{q}%")\
               .limit(20).execute()
    pls   = sb.table("playlists").select("*, users!playlists_user_id_fkey(name)").eq("is_public", True)\
               .ilike("name", f"%{q}%").limit(6).execute()
    # Unique artists from results
    artists = list({s["artist"]: {"artist": s["artist"], "cover_url": s.get("cover_url")}
                    for s in songs.data}.values())
    asyncio.create_task(log_traffic(sb, request, user["sub"] if user else None, "search", {"q": q}))
    return {"songs": songs.data, "playlists": pls.data, "artists": artists[:6]}

# ══════════════════════════════════════════════════════════════════════════════
# TRAFFIC & ANALYTICS (Admin only)
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/admin/traffic/overview")
async def traffic_overview(days: int = 7, user=Depends(admin_user)):
    sb    = get_sb()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    logs  = sb.table("traffic_logs").select("*").gte("timestamp", since).execute().data

    total_events  = len(logs)
    unique_ips    = len(set(l["ip_address"] for l in logs if l.get("ip_address")))
    plays         = [l for l in logs if l["event_type"] == "play"]
    searches      = [l for l in logs if l["event_type"] == "search"]
    logins        = [l for l in logs if l["event_type"] == "login"]

    # By country
    from collections import Counter
    country_counts = Counter(l["country"] for l in logs if l.get("country"))
    device_counts  = Counter(l["device"]  for l in logs if l.get("device"))
    browser_counts = Counter(l["browser"] for l in logs if l.get("browser"))

    # Daily breakdown
    daily = {}
    for l in logs:
        day = l["timestamp"][:10] if l.get("timestamp") else "unknown"
        if day not in daily: daily[day] = {"date": day, "plays": 0, "total": 0, "logins": 0}
        daily[day]["total"] += 1
        if l["event_type"] == "play":   daily[day]["plays"]  += 1
        if l["event_type"] == "login":  daily[day]["logins"] += 1

    # Geo points for map
    geo_points = [
        {"lat": l["lat"], "lon": l["lon"], "country": l["country"],
         "city": l["city"], "event": l["event_type"]}
        for l in logs if l.get("lat") and l.get("lon") and l["lat"] != 0
    ]

    return {
        "summary": {
            "total_events":  total_events,
            "unique_visitors": unique_ips,
            "total_plays":   len(plays),
            "total_searches": len(searches),
            "total_logins":  len(logins),
        },
        "by_country": [{"country": c, "count": n} for c, n in country_counts.most_common(20)],
        "by_device":  [{"device": d, "count": n}  for d, n in device_counts.most_common()],
        "by_browser": [{"browser": b, "count": n} for b, n in browser_counts.most_common()],
        "daily":      sorted(daily.values(), key=lambda x: x["date"]),
        "geo_points": geo_points[:500],
    }

@app.get("/api/admin/traffic/live")
async def traffic_live(user=Depends(admin_user)):
    """Last 30 minutes of activity"""
    sb    = get_sb()
    since = (datetime.now(timezone.utc) - timedelta(minutes=30)).isoformat()
    logs  = sb.table("traffic_logs").select("*").gte("timestamp", since)\
              .order("timestamp", desc=True).limit(50).execute().data
    active_ips = len(set(l["ip_address"] for l in logs if l.get("ip_address")))
    return {"active_now": active_ips, "recent_events": logs}

@app.get("/api/admin/traffic/top-songs")
async def top_songs_traffic(days: int = 7, user=Depends(admin_user)):
    sb    = get_sb()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    logs  = sb.table("traffic_logs").select("meta").eq("event_type", "play")\
              .gte("timestamp", since).execute().data
    from collections import Counter
    titles = []
    for l in logs:
        try:
            import ast
            m = ast.literal_eval(l["meta"]) if isinstance(l["meta"], str) else l["meta"]
            if m.get("title"): titles.append(f"{m.get('artist','?')} - {m.get('title','?')}")
        except: pass
    counts = Counter(titles)
    return [{"song": s, "plays": n} for s, n in counts.most_common(10)]

@app.get("/api/admin/stats")
async def admin_stats(user=Depends(admin_user)):
    sb     = get_sb()
    songs  = sb.table("songs").select("id", count="exact").execute()
    users  = sb.table("users").select("id", count="exact").execute()
    pls    = sb.table("playlists").select("id", count="exact").execute()
    plays  = sb.table("play_history").select("id", count="exact").execute()
    dls    = sb.table("downloads").select("id", count="exact").execute()
    premium= sb.table("users").select("id", count="exact").eq("role", "premium").execute()
    # Traffic last 24h
    since  = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
    traffic= sb.table("traffic_logs").select("id", count="exact").gte("timestamp", since).execute()
    return {
        "total_songs":     songs.count or 0,
        "total_users":     users.count or 0,
        "total_playlists": pls.count or 0,
        "total_plays":     plays.count or 0,
        "total_downloads": dls.count or 0,
        "premium_users":   premium.count or 0,
        "traffic_24h":     traffic.count or 0,
    }

@app.get("/api/admin/users")
async def admin_users(user=Depends(admin_user)):
    sb = get_sb()
    r  = sb.table("users").select("id,name,email,role,created_at,avatar_url").order("created_at", desc=True).execute()
    return r.data

@app.put("/api/admin/users/{uid}/role")
async def set_role(uid: str, role: str = Form(...), user=Depends(admin_user)):
    valid = ("user", "premium", "admin", "superadmin")
    if role not in valid: raise HTTPException(400, f"Role must be one of: {valid}")
    get_sb().table("users").update({"role": role}).eq("id", uid).execute()
    return {"ok": True}

@app.get("/api/admin/downloads")
async def admin_downloads(user=Depends(admin_user)):
    sb = get_sb()
    r  = sb.table("downloads").select("*, users!downloads_user_id_fkey(name,email), songs!downloads_song_id_fkey(title,artist)")\
           .order("downloaded_at", desc=True).limit(100).execute()
    return r.data

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

# ══════════════════════════════════════════════════════════════════════════════
# AI ROUTES (Claude API)
# ══════════════════════════════════════════════════════════════════════════════

CLAUDE_API_KEY = os.getenv("CLAUDE_API_KEY", "")
CLAUDE_MODEL   = "claude-sonnet-4-6"

async def call_claude(system: str, prompt: str, max_tokens: int = 1024) -> str:
    """Call Claude API — returns empty string on failure (never breaks app)"""
    if not CLAUDE_API_KEY:
        return ""
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key":         CLAUDE_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type":      "application/json",
                },
                json={
                    "model":      CLAUDE_MODEL,
                    "max_tokens": max_tokens,
                    "system":     system,
                    "messages":   [{"role": "user", "content": prompt}],
                }
            )
            data = r.json()
            return data["content"][0]["text"].strip()
    except Exception as e:
        print(f"Claude API error: {e}")
        return ""

# ── 1. Smart Recommendations ──────────────────────────────────────────────────
@app.get("/api/ai/recommendations")
async def ai_recommendations(user=Depends(current_user)):
    """AI-powered personal recommendations based on listening history"""
    sb = get_sb()

    # Get user's listening history
    hist = sb.table("play_history")\
             .select("songs(title, artist, genre, album)")\
             .eq("user_id", user["sub"])\
             .order("played_at", desc=True).limit(30).execute()

    listened = [h["songs"] for h in hist.data if h.get("songs")]

    # Get all available songs
    all_songs = sb.table("songs").select("id, title, artist, genre, album, play_count")\
                  .eq("is_public", True).order("play_count", desc=True).limit(100).execute().data

    if not listened:
        # New user — return top songs
        return {"songs": all_songs[:10], "reason": "Top songs on YoMusic for new listeners", "ai_powered": False}

    # Build context for Claude
    history_text = "\n".join([f"- {s['title']} by {s['artist']} ({s.get('genre','?')})" for s in listened[:15]])
    library_text = "\n".join([f"ID:{s['id']}|{s['title']} by {s['artist']} ({s.get('genre','?')})" for s in all_songs])

    system = """You are a music recommendation engine for YoMusic.
Analyze the user's listening history and recommend songs from the available library.
Respond ONLY with valid JSON: {"song_ids": ["id1","id2",...], "reason": "brief explanation"}
Pick 8-10 song IDs. Never include songs already in the listening history."""

    prompt = f"""User's recent listening history:
{history_text}

Available songs in library:
{library_text}

Recommend songs the user would love based on their taste."""

    result = await call_claude(system, prompt, 512)

    try:
        import json, re
        # Extract JSON from response
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            data       = json.loads(match.group())
            song_ids   = data.get("song_ids", [])
            reason     = data.get("reason", "Picked for your taste")
            # Fetch recommended songs in order
            rec_songs  = [s for sid in song_ids for s in all_songs if s["id"] == sid]
            if rec_songs:
                return {"songs": rec_songs, "reason": reason, "ai_powered": True}
    except Exception as e:
        print(f"AI rec parse error: {e}")

    # Fallback
    return {"songs": all_songs[:10], "reason": "Popular songs you might enjoy", "ai_powered": False}


# ── 2. Mood-Based Playlist ────────────────────────────────────────────────────
@app.post("/api/ai/mood-playlist")
async def mood_playlist(mood: str = Form(...), user=Depends(current_user)):
    """Generate a playlist from a mood/vibe description"""
    sb       = get_sb()
    all_songs = sb.table("songs").select("id, title, artist, genre, album, play_count")\
                  .eq("is_public", True).execute().data

    if not all_songs:
        return {"songs": [], "playlist_name": "Empty Library", "description": "No songs yet"}

    library_text = "\n".join([
        f"ID:{s['id']}|{s['title']} by {s['artist']} ({s.get('genre','?')})"
        for s in all_songs
    ])

    system = """You are a music curator for YoMusic.
Given a mood or vibe description, select songs from the library that fit perfectly.
Respond ONLY with valid JSON:
{"playlist_name": "creative name", "description": "1 sentence description", "song_ids": ["id1","id2",...]}
Select 8-15 songs. Make the playlist name creative and relevant to the mood."""

    prompt = f"""User's mood/vibe request: "{mood}"

Available songs:
{library_text}

Create a perfect playlist for this mood."""

    result   = await call_claude(system, prompt, 600)
    fallback = {"songs": all_songs[:10], "playlist_name": f"{mood.title()} Vibes",
                "description": f"Songs for: {mood}", "ai_powered": False}

    try:
        import json, re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            data          = json.loads(match.group())
            song_ids      = data.get("song_ids", [])
            playlist_name = data.get("playlist_name", f"{mood.title()} Vibes")
            description   = data.get("description", "")
            songs         = [s for sid in song_ids for s in all_songs if s["id"] == sid]
            if songs:
                return {
                    "songs":         songs,
                    "playlist_name": playlist_name,
                    "description":   description,
                    "ai_powered":    True
                }
    except Exception as e:
        print(f"Mood playlist parse error: {e}")

    return fallback


# ── 3. Natural Language Search ────────────────────────────────────────────────
@app.get("/api/ai/search")
async def ai_search(q: str, user=Depends(optional_user)):
    """Natural language search — understands vague queries"""
    if not q or len(q) < 3:
        return {"songs": [], "interpreted_as": ""}

    sb        = get_sb()
    all_songs = sb.table("songs").select("id, title, artist, genre, album, year, play_count, cover_url")\
                  .eq("is_public", True).execute().data

    if not all_songs:
        return {"songs": [], "interpreted_as": q}

    library_text = "\n".join([
        f"ID:{s['id']}|{s['title']} by {s['artist']} | Genre:{s.get('genre','?')} | Album:{s.get('album','?')} | Year:{s.get('year','?')}"
        for s in all_songs
    ])

    system = """You are a music search engine for YoMusic.
Understand natural language queries and find matching songs.
Respond ONLY with valid JSON:
{"interpreted_as": "what you understood", "song_ids": ["id1","id2",...]}
Be generous — include up to 20 results. Understand vague descriptions like "chill Sunday music" or "something fast"."""

    prompt = f"""Search query: "{q}"

Available songs:
{library_text}

Find songs matching this query."""

    result = await call_claude(system, prompt, 500)

    try:
        import json, re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            data           = json.loads(match.group())
            song_ids       = data.get("song_ids", [])
            interpreted_as = data.get("interpreted_as", q)
            songs          = [s for sid in song_ids for s in all_songs if s["id"] == sid]
            if songs:
                return {"songs": songs, "interpreted_as": interpreted_as, "ai_powered": True}
    except Exception as e:
        print(f"AI search parse error: {e}")

    # Fallback to basic text search
    q_lower = q.lower()
    songs   = [s for s in all_songs if
               q_lower in s["title"].lower() or
               q_lower in s["artist"].lower() or
               q_lower in (s.get("genre") or "").lower()]
    return {"songs": songs[:15], "interpreted_as": q, "ai_powered": False}


# ── 4. Traffic Insights in Plain English (Admin) ───────────────────────────────
@app.get("/api/ai/traffic-insights")
async def traffic_insights(days: int = 7, user=Depends(admin_user)):
    """AI reads your traffic data and writes a plain English summary"""
    sb    = get_sb()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    logs  = sb.table("traffic_logs").select("*").gte("timestamp", since).execute().data

    if not logs:
        return {"insights": "No traffic data available yet for this period.", "ai_powered": False}

    from collections import Counter
    total        = len(logs)
    unique_ips   = len(set(l["ip_address"] for l in logs if l.get("ip_address")))
    plays        = sum(1 for l in logs if l["event_type"] == "play")
    searches     = sum(1 for l in logs if l["event_type"] == "search")
    logins       = sum(1 for l in logs if l["event_type"] == "login")
    registers    = sum(1 for l in logs if l["event_type"] == "register")
    countries    = Counter(l["country"] for l in logs if l.get("country") and l["country"] != "Unknown")
    devices      = Counter(l["device"]  for l in logs if l.get("device"))
    top_countries = countries.most_common(5)
    top_devices   = devices.most_common(3)

    # Daily plays
    daily = {}
    for l in logs:
        day = l["timestamp"][:10] if l.get("timestamp") else "unknown"
        daily[day] = daily.get(day, 0) + (1 if l["event_type"] == "play" else 0)
    daily_sorted = sorted(daily.items())
    trend = "increasing" if len(daily_sorted) > 1 and daily_sorted[-1][1] >= daily_sorted[0][1] else "decreasing"

    # Get stats
    stats_r  = sb.table("users").select("id", count="exact").execute()
    songs_r  = sb.table("songs").select("id", count="exact").execute()
    premium_r= sb.table("users").select("id", count="exact").eq("role","premium").execute()

    system = """You are an analytics expert for YoMusic, a music streaming platform.
Write a clear, friendly, insightful summary for the platform admin.
Be specific with numbers. Highlight wins, flag concerns, give 2-3 actionable suggestions.
Keep it conversational — like a smart business analyst briefing their boss.
Use emojis sparingly. Format with short paragraphs, not bullet lists."""

    prompt = f"""Here is YoMusic's platform data for the last {days} days:

TRAFFIC:
- Total events: {total}
- Unique visitors: {unique_ips}
- Songs played: {plays}
- Searches: {searches}
- Logins: {logins}
- New registrations: {registers}
- Play trend: {trend}

TOP COUNTRIES: {', '.join([f"{c} ({n})" for c,n in top_countries])}
DEVICES: {', '.join([f"{d} ({n})" for d,n in top_devices])}

PLATFORM:
- Total users: {stats_r.count or 0}
- Premium users: {premium_r.count or 0}
- Total songs: {songs_r.count or 0}

Write a plain English insights report."""

    result = await call_claude(system, prompt, 800)

    if result:
        return {"insights": result, "ai_powered": True, "period_days": days}

    # Fallback plain text
    fallback = f"In the last {days} days: {total} events from {unique_ips} unique visitors. {plays} songs played across {len(top_countries)} countries. Top location: {top_countries[0][0] if top_countries else 'Unknown'}."
    return {"insights": fallback, "ai_powered": False, "period_days": days}


# ── 5. Submission Pre-Screening (Admin) ───────────────────────────────────────
@app.post("/api/ai/screen-submission")
async def screen_submission(
    artist_name: str          = Form(...),
    genre:       str          = Form(...),
    music_links: str          = Form(...),
    message:     str          = Form(""),
    user=Depends(admin_user),
):
    """AI pre-screens an artist submission and gives a quality score"""
    system = """You are a music curator assistant for YoMusic.
Screen artist submissions and give honest, fair assessments.
Respond ONLY with valid JSON:
{
  "score": <1-10>,
  "recommendation": "approve" | "review" | "decline",
  "strengths": ["point1", "point2"],
  "concerns": ["concern1"],
  "summary": "2-3 sentence assessment",
  "questions_for_artist": ["optional follow-up questions"]
}
Be constructive and fair. Score 8+ = approve, 5-7 = review manually, below 5 = decline."""

    prompt = f"""Artist submission for YoMusic:

Artist Name: {artist_name}
Genre: {genre}
Music Links: {music_links}
Artist's Message: {message or "No message provided"}

Assess this submission. Check if the links look legitimate (SoundCloud, YouTube, Google Drive, Dropbox are good signs).
Consider the genre fit, professionalism of the submission, and completeness."""

    result = await call_claude(system, prompt, 600)

    try:
        import json, re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            data = json.loads(match.group())
            data["ai_powered"] = True
            return data
    except Exception as e:
        print(f"Screening parse error: {e}")

    return {
        "score":                  5,
        "recommendation":         "review",
        "strengths":              ["Submission received"],
        "concerns":               ["Could not auto-screen — please review manually"],
        "summary":                "Manual review required.",
        "questions_for_artist":   [],
        "ai_powered":             False
    }


# ── 6. Auto Playlist Name/Description Generator ───────────────────────────────
@app.post("/api/ai/playlist-describe")
async def playlist_describe(playlist_id: str = Form(...), user=Depends(current_user)):
    """Generate a creative name and description for a playlist based on its songs"""
    sb = get_sb()
    r  = sb.table("playlist_songs")\
           .select("songs(title, artist, genre)")\
           .eq("playlist_id", playlist_id).limit(20).execute()

    songs = [s["songs"] for s in r.data if s.get("songs")]
    if not songs:
        return {"name": None, "description": None, "ai_powered": False}

    songs_text = "\n".join([f"- {s['title']} by {s['artist']} ({s.get('genre','?')})" for s in songs])

    system = """You are a creative playlist curator.
Given a list of songs, generate a creative playlist name and description.
Respond ONLY with valid JSON: {"name": "playlist name", "description": "1-2 sentence vibe description"}
The name should be evocative and unique, not generic. Max 30 characters for name."""

    prompt = f"""Songs in this playlist:
{songs_text}

Generate a creative name and description for this playlist."""

    result = await call_claude(system, prompt, 200)

    try:
        import json, re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            data = json.loads(match.group())
            data["ai_powered"] = True
            return data
    except Exception:
        pass

    return {"name": None, "description": None, "ai_powered": False}
