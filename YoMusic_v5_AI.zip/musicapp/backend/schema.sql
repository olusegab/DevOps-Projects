-- YoMusic Complete Database Schema v2
-- Run this in Supabase SQL Editor

-- Users (roles: user, premium, admin, superadmin)
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','premium','admin','superadmin')),
  avatar_url    TEXT,
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- Songs
CREATE TABLE IF NOT EXISTS songs (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title        TEXT NOT NULL,
  artist       TEXT NOT NULL,
  album        TEXT,
  genre        TEXT,
  year         INTEGER,
  audio_url    TEXT NOT NULL,
  cover_url    TEXT,
  duration     INTEGER DEFAULT 0,
  play_count   INTEGER DEFAULT 0,
  is_public    BOOLEAN DEFAULT true,
  uploaded_by  UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_songs_artist  ON songs(artist);
CREATE INDEX IF NOT EXISTS idx_songs_genre   ON songs(genre);
CREATE INDEX IF NOT EXISTS idx_songs_plays   ON songs(play_count DESC);

-- Playlists
CREATE TABLE IF NOT EXISTS playlists (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  description TEXT,
  cover_url   TEXT,
  is_public   BOOLEAN DEFAULT false,
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT now()
);

-- Playlist songs
CREATE TABLE IF NOT EXISTS playlist_songs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
  song_id     UUID REFERENCES songs(id) ON DELETE CASCADE,
  position    INTEGER DEFAULT 1,
  UNIQUE(playlist_id, song_id)
);

-- Likes
CREATE TABLE IF NOT EXISTS likes (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  song_id    UUID REFERENCES songs(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, song_id)
);

-- Play history
CREATE TABLE IF NOT EXISTS play_history (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id   UUID REFERENCES users(id) ON DELETE CASCADE,
  song_id   UUID REFERENCES songs(id) ON DELETE CASCADE,
  played_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_history_user ON play_history(user_id, played_at DESC);

-- Downloads (premium only)
CREATE TABLE IF NOT EXISTS downloads (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  song_id       UUID REFERENCES songs(id) ON DELETE CASCADE,
  downloaded_at TIMESTAMPTZ DEFAULT now()
);

-- Traffic logs (for analytics)
CREATE TABLE IF NOT EXISTS traffic_logs (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  ip_address   TEXT,
  event_type   TEXT NOT NULL, -- play, search, login, register, upload, page_view
  country      TEXT,
  country_code TEXT,
  city         TEXT,
  region       TEXT,
  lat          FLOAT,
  lon          FLOAT,
  isp          TEXT,
  device       TEXT,  -- desktop, mobile, tablet
  browser      TEXT,
  meta         TEXT,  -- JSON string of extra info
  timestamp    TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_traffic_ts      ON traffic_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_traffic_type    ON traffic_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_traffic_country ON traffic_logs(country);
CREATE INDEX IF NOT EXISTS idx_traffic_user    ON traffic_logs(user_id);

-- Disable RLS (API handles auth)
ALTER TABLE users          DISABLE ROW LEVEL SECURITY;
ALTER TABLE songs          DISABLE ROW LEVEL SECURITY;
ALTER TABLE playlists      DISABLE ROW LEVEL SECURITY;
ALTER TABLE playlist_songs DISABLE ROW LEVEL SECURITY;
ALTER TABLE likes          DISABLE ROW LEVEL SECURITY;
ALTER TABLE play_history   DISABLE ROW LEVEL SECURITY;
ALTER TABLE downloads      DISABLE ROW LEVEL SECURITY;
ALTER TABLE traffic_logs   DISABLE ROW LEVEL SECURITY;

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('music',   'music',   true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('artwork', 'artwork', true) ON CONFLICT DO NOTHING;
