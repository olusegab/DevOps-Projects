#!/usr/bin/env python3
"""
AbayoNet Enterprise Network Monitor v4.0
Fixes: Database lock (per-thread connection pool)
New:   Login page, Admin/ReadOnly users, User management, Host import/export
"""
import os, sys, threading, time, json, sqlite3, subprocess, platform
import socket, re, smtplib, logging, csv, io, ipaddress, hashlib, secrets
import webbrowser
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime, timedelta
from http.server import HTTPServer, ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

os.makedirs('data', exist_ok=True)
_log_handler = TimedRotatingFileHandler(
    'data/abayonet.log',
    when='midnight',       # rotate at midnight
    interval=1,
    backupCount=7,         # keep 7 days of logs, auto-delete older ones
    encoding='utf-8'
)
_log_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
_console_handler = logging.StreamHandler(sys.stdout)
_console_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
logging.basicConfig(level=logging.INFO, handlers=[_log_handler, _console_handler])
log = logging.getLogger('AbayoNet')
DB_PATH = 'data/abayonet.db'
VERSION = '5.2.0-port8780'

# ═══════════════════════════════════════════════════════════════
# DATABASE - Single shared connection with RLock
# One connection shared across all threads (check_same_thread=False)
# protected by a reentrant lock. Eliminates all "database is locked"
# errors from multiple per-thread connections competing for WAL writes.
# ═══════════════════════════════════════════════════════════════
_db_lock = threading.RLock()
_db_conn = None

def get_db():
    global _db_conn
    if _db_conn is None:
        c = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA journal_mode=WAL')
        c.execute('PRAGMA synchronous=NORMAL')
        c.execute('PRAGMA foreign_keys=ON')
        c.execute('PRAGMA cache_size=-8000')
        _db_conn = c
    return _db_conn

def close_thread_db():
    pass  # No-op: single shared connection, not per-thread

def db_exec(sql, params=()):
    with _db_lock:
        conn = get_db()
        cur = conn.execute(sql, params)
        conn.commit()
        return cur

def db_one(sql, params=()):
    with _db_lock:
        return get_db().execute(sql, params).fetchone()

def db_all(sql, params=()):
    with _db_lock:
        return get_db().execute(sql, params).fetchall()

# ── TIMESTAMP HELPERS ────────────────────────────────────────────
# IMPORTANT: SQLite's `datetime('now')` (used as the column DEFAULT for
# ping_results/alerts/port_results.timestamp) produces strings like
# '2026-06-21 13:55:40' — a SPACE between date and time.
# Python's datetime.isoformat() produces '2026-06-21T13:55:40.123456' — a
# 'T' separator (plus microseconds). When these two formats are compared
# as TEXT in SQL (e.g. "WHERE timestamp > ?"), SQLite does a plain
# lexicographic string comparison. Since ' ' (0x20) sorts before 'T'
# (0x54), any same-calendar-day comparison silently evaluates wrong
# (real, recent rows look "older" than the cutoff), while comparisons
# that cross a date boundary happen to still work because the YYYY-MM-DD
# prefix alone already differs. This is why narrow ranges like 1H/3H/6H/
# 12H came back empty while 24H+ worked. Always use these helpers (not
# .isoformat()) when building a `since`/`cutoff` value that gets compared
# against a column populated by SQLite's `datetime('now')` default.
def utc_now_str():
    return datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

def utc_since_str(hours=0, days=0):
    return (datetime.utcnow() - timedelta(hours=hours, days=days)).strftime('%Y-%m-%d %H:%M:%S')

def cfg(key, default=''):
    try:
        r = db_one('SELECT value FROM settings WHERE key=?', (key,))
        return r['value'] if r else default
    except:
        return default

# ── DATABASE INIT ────────────────────────────────────────────────
def init_db():
    conn = get_db()  # use the shared connection
    c = conn.cursor()
    c.executescript('''
        PRAGMA foreign_keys=ON;

        CREATE TABLE IF NOT EXISTS hosts (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ip              TEXT UNIQUE NOT NULL,
            name            TEXT DEFAULT '',
            group_name      TEXT DEFAULT 'Default',
            tags            TEXT DEFAULT '',
            description     TEXT DEFAULT '',
            location        TEXT DEFAULT '',
            alert_email     TEXT DEFAULT '',
            ping_interval   INTEGER DEFAULT 30,
            packet_count    INTEGER DEFAULT 4,
            timeout_ms      INTEGER DEFAULT 1000,
            port_checks     TEXT DEFAULT '',
            snmp_community  TEXT DEFAULT 'public',
            enabled         INTEGER DEFAULT 1,
            created_at      TEXT DEFAULT (datetime('now')),
            notes           TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS ping_results (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            host_id     INTEGER NOT NULL,
            timestamp   TEXT DEFAULT (datetime('now')),
            status      TEXT NOT NULL,
            latency_ms  REAL,
            packet_loss REAL,
            jitter_ms   REAL,
            ttl         INTEGER,
            FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_ping_host_ts ON ping_results(host_id,timestamp DESC);

        CREATE TABLE IF NOT EXISTS port_results (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            host_id     INTEGER NOT NULL,
            timestamp   TEXT DEFAULT (datetime('now')),
            port        INTEGER NOT NULL,
            status      TEXT NOT NULL,
            latency_ms  REAL,
            FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS alerts (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            host_id         INTEGER NOT NULL,
            type            TEXT NOT NULL,
            message         TEXT NOT NULL,
            severity        TEXT DEFAULT 'warning',
            timestamp       TEXT DEFAULT (datetime('now')),
            acknowledged    INTEGER DEFAULT 0,
            ack_by          TEXT DEFAULT '',
            ack_at          TEXT DEFAULT '',
            FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(timestamp DESC);

        CREATE TABLE IF NOT EXISTS alert_rules (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            name            TEXT NOT NULL,
            host_id         INTEGER DEFAULT 0,
            condition       TEXT NOT NULL,
            threshold       REAL DEFAULT 0,
            duration_mins   INTEGER DEFAULT 0,
            notify_email    TEXT DEFAULT '',
            notify_webhook  TEXT DEFAULT '',
            enabled         INTEGER DEFAULT 1,
            cooldown_mins   INTEGER DEFAULT 5,
            last_triggered  TEXT,
            trigger_count   INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS maintenance (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            host_id     INTEGER,
            name        TEXT NOT NULL,
            start_time  TEXT NOT NULL,
            end_time    TEXT NOT NULL,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT UNIQUE NOT NULL,
            password    TEXT NOT NULL,
            role        TEXT DEFAULT 'readonly',
            full_name   TEXT DEFAULT '',
            email       TEXT DEFAULT '',
            created_at  TEXT DEFAULT (datetime('now')),
            last_login  TEXT DEFAULT '',
            active      INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS sessions (
            token       TEXT PRIMARY KEY,
            user_id     INTEGER NOT NULL,
            username    TEXT NOT NULL,
            role        TEXT NOT NULL,
            created_at  TEXT DEFAULT (datetime('now')),
            expires_at  TEXT NOT NULL,
            ip          TEXT DEFAULT ''
        );
    ''')

    defaults = [
        ('smtp_host',''),('smtp_port','587'),('smtp_user',''),('smtp_pass',''),
        ('smtp_from',''),('smtp_tls','1'),('alert_cooldown','300'),
        ('data_retention_days','30'),('theme','dark'),('refresh_interval','10'),
        ('webhook_url',''),('company_name','AbayoNet Enterprise'),
    ]
    for k,v in defaults:
        c.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',(k,v))

    c.execute('SELECT COUNT(*) FROM alert_rules')
    if c.fetchone()[0] == 0:
        rules = [
            ('Host Offline',0,'offline',0,0,'','',1,5),
            ('High Latency >200ms',0,'latency_gt',200,0,'','',1,5),
            ('Packet Loss >10%',0,'loss_gt',10,0,'','',1,5),
        ]
        for r in rules:
            c.execute('INSERT INTO alert_rules(name,host_id,condition,threshold,duration_mins,notify_email,notify_webhook,enabled,cooldown_mins) VALUES(?,?,?,?,?,?,?,?,?)',r)

    c.execute('SELECT COUNT(*) FROM users')
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users(username,password,role,full_name,email) VALUES('admin',?,'admin','Administrator','admin@abayonet.local')",(hashpw('admin123'),))
        log.info('='*55)
        log.info('DEFAULT ADMIN CREATED')
        log.info('  Username: admin')
        log.info('  Password: admin123')
        log.info('  CHANGE THIS PASSWORD after first login!')
        log.info('='*55)

    c.execute('SELECT COUNT(*) FROM hosts')
    if c.fetchone()[0] == 0:
        sample = [
            ('8.8.8.8','Google DNS','External DNS','dns,google','Primary Google DNS'),
            ('1.1.1.1','Cloudflare DNS','External DNS','dns,cloudflare','Cloudflare primary'),
            ('8.8.4.4','Google DNS 2','External DNS','dns,google','Secondary Google DNS'),
        ]
        for s in sample:
            c.execute('INSERT OR IGNORE INTO hosts(ip,name,group_name,tags,description) VALUES(?,?,?,?,?)',s)

    conn.commit()
    log.info(f'AbayoNet v{VERSION} database ready')

# ── AUTH ─────────────────────────────────────────────────────────
def hashpw(p):
    return hashlib.sha256(('AbayoNet_salt_v4_'+p).encode()).hexdigest()

def make_session(uid, uname, role, ip=''):
    token = secrets.token_urlsafe(48)
    exp = (datetime.utcnow()+timedelta(days=30)).isoformat()
    db_exec('INSERT INTO sessions(token,user_id,username,role,expires_at,ip) VALUES(?,?,?,?,?,?)',(token,uid,uname,role,exp,ip))
    db_exec('UPDATE users SET last_login=? WHERE id=?',(datetime.now().isoformat(),uid))
    return token

def renew_session(token):
    """Slide the expiry window forward on each heartbeat — keeps active sessions alive indefinitely."""
    exp = (datetime.utcnow()+timedelta(days=30)).isoformat()
    db_exec('UPDATE sessions SET expires_at=? WHERE token=?',(exp,token))

def check_session(token):
    if not token: return None
    try:
        r = db_one('SELECT username,role,expires_at FROM sessions WHERE token=?',(token,))
        if not r: return None
        if datetime.fromisoformat(r["expires_at"]) < datetime.utcnow():
            db_exec('DELETE FROM sessions WHERE token=?',(token,))
            return None
        return {'username':r['username'],'role':r['role']}
    except:
        return None

def get_token(handler):
    for part in handler.headers.get('Cookie','').split(';'):
        p = part.strip()
        if p.startswith('abn_token='):
            return p.split('=',1)[1].strip()
    a = handler.headers.get('Authorization','')
    if a.startswith('Bearer '): return a[7:].strip()
    return None

def auth(handler, admin=False):
    sess = check_session(get_token(handler))
    if not sess:
        handler.json({'error':'Unauthorized','login_required':True},401)
        return None
    if admin and sess['role']!='admin':
        handler.json({'error':'Admin access required'},403)
        return None
    return sess

# ── PING ENGINE ──────────────────────────────────────────────────
def ping(ip, count=4, timeout_ms=1000):
    sname = platform.system().lower()
    ts = max(1, timeout_ms//1000)
    try:
        cmd = (['ping','-n',str(count),'-w',str(timeout_ms),ip]
               if sname=='windows' else
               ['ping','-c',str(count),'-W',str(ts),ip])
        r = subprocess.run(cmd,capture_output=True,text=True,timeout=count*ts+8)
        return parse_ping(r.stdout+r.stderr,sname,count)
    except:
        return offline()

def parse_ping(out, sname, count):
    lats = []
    ttl = None
    loss = 100.0
    if sname == 'windows':
        for m in re.finditer(r'time[=<](\d+)ms',out,re.I): lats.append(float(m.group(1)))
        m=re.search(r'TTL=(\d+)',out,re.I); ttl=int(m.group(1)) if m else None
        m=re.search(r'\((\d+)%\s*loss\)',out,re.I); loss=float(m.group(1)) if m else 100.0
    else:
        for m in re.finditer(r'time=(\d+\.?\d*)\s*ms',out): lats.append(float(m.group(1)))
        m=re.search(r'ttl=(\d+)',out,re.I); ttl=int(m.group(1)) if m else None
        m=re.search(r'(\d+)%\s*packet loss',out); loss=float(m.group(1)) if m else 100.0
    if not lats: return offline()
    avg = sum(lats)/len(lats)
    loss = max(0.0,(count-len(lats))/count*100)
    jitter = sum(abs(l-avg) for l in lats)/len(lats) if len(lats)>1 else 0.0
    return {'status':'online' if loss<100 else 'offline',
            'latency':round(avg,2),'loss':round(loss,1),
            'jitter':round(jitter,2),'ttl':ttl,
            'min_ms':round(min(lats),2),'max_ms':round(max(lats),2)}

def offline():
    return {'status':'offline','latency':None,'loss':100.0,'jitter':None,'ttl':None,'min_ms':None,'max_ms':None}

def check_port(ip, port, timeout=2):
    try:
        t0=time.time()
        with socket.create_connection((ip,port),timeout=timeout):
            return {'port':port,'status':'open','latency_ms':round((time.time()-t0)*1000,2)}
    except:
        return {'port':port,'status':'closed','latency_ms':None}

def resolve(ip):
    try: return socket.gethostbyaddr(ip)[0]
    except: return ''

# ── ALERT ENGINE ─────────────────────────────────────────────────
_astate = {}

def fire_alerts(host_id, hname, ip, result):
    try:
        rules = db_all('SELECT * FROM alert_rules WHERE (host_id=? OR host_id=0) AND enabled=1',(host_id,))
        now = datetime.utcnow()
        for rule in rules:
            rule=dict(rule); rid=rule['id']; cond=rule['condition']
            thresh=rule['threshold']; cooldown=rule['cooldown_mins']*60
            triggered=False; msg=''; sev='warning'
            if cond=='offline' and result['status']=='offline':
                triggered=True; sev='critical'; msg=f'🔴 {hname} ({ip}) is OFFLINE'
            elif cond=='online' and result['status']=='online':
                triggered=True; sev='info'; msg=f'🟢 {hname} ({ip}) is back ONLINE'
            elif cond=='latency_gt' and result.get('latency') and result['latency']>thresh:
                triggered=True; msg=f'⚡ High latency on {hname} ({ip}): {result["latency"]:.1f}ms > {thresh}ms'
            elif cond=='loss_gt' and result['loss']>thresh:
                triggered=True; msg=f'📦 Packet loss on {hname} ({ip}): {result["loss"]:.1f}% > {thresh}%'
            elif cond=='jitter_gt' and result.get('jitter') and result['jitter']>thresh:
                triggered=True; msg=f'〰 Jitter on {hname} ({ip}): {result["jitter"]:.1f}ms > {thresh}ms'
            if not triggered: continue
            key=(host_id,rid)
            last=_astate.get(key)
            if last and (now-last).total_seconds()<cooldown: continue
            _astate[key]=now
            db_exec('INSERT INTO alerts(host_id,type,message,severity) VALUES(?,?,?,?)',(host_id,cond,msg,sev))
            db_exec('UPDATE alert_rules SET last_triggered=?,trigger_count=trigger_count+1 WHERE id=?',(now.isoformat(),rid))
            log.warning(f'ALERT [{sev}]: {msg}')
            em=rule.get('notify_email','')
            if em: threading.Thread(target=_send_email,args=(em,sev,hname,msg),daemon=True).start()
    except Exception as e:
        log.error(f'Alert error: {e}')

def _send_email(to, sev, host, msg):
    try:
        h=cfg('smtp_host'); port=int(cfg('smtp_port','587'))
        u=cfg('smtp_user'); p=cfg('smtp_pass'); frm=cfg('smtp_from') or u
        if not h or not u: return
        mm=MIMEMultipart(); mm['From']=frm; mm['To']=to
        mm['Subject']=f'[AbayoNet] {sev.upper()}: {host}'
        mm.attach(MIMEText(msg,'plain'))
        s=smtplib.SMTP(h,port,timeout=10)
        if cfg('smtp_tls','1')=='1': s.starttls()
        s.login(u,p); s.send_message(mm); s.quit()
    except Exception as e:
        log.error(f'Email error: {e}')

def in_maintenance(host_id):
    now=datetime.utcnow().isoformat()
    try:
        r=db_one('SELECT id FROM maintenance WHERE (host_id=? OR host_id IS NULL) AND start_time<=? AND end_time>=?',(host_id,now,now))
        return r is not None
    except: return False

# ── MONITOR LOOPS ────────────────────────────────────────────────
_running = True
_hthreads = {}

def monitor_host(host_id, ip, name, interval, pcount, timeout_ms, ports_str):
    log.info(f'Monitor: {name} ({ip}) every {interval}s')
    while _running:
        try:
            result = ping(ip, pcount, timeout_ms)
            db_exec('INSERT INTO ping_results(host_id,status,latency_ms,packet_loss,jitter_ms,ttl) VALUES(?,?,?,?,?,?)',
                (host_id,result['status'],result.get('latency'),result['loss'],result.get('jitter'),result.get('ttl')))
            if not in_maintenance(host_id):
                fire_alerts(host_id, name, ip, result)
            if ports_str:
                for port in [int(p.strip()) for p in ports_str.split(',') if p.strip().isdigit()]:
                    pr=check_port(ip,port)
                    db_exec('INSERT INTO port_results(host_id,port,status,latency_ms) VALUES(?,?,?,?)',(host_id,port,pr['status'],pr.get('latency_ms')))
        except Exception as e:
            log.error(f'Monitor error {ip}: {e}')
        time.sleep(interval)
    close_thread_db()

def start_monitor(h):
    t = threading.Thread(
        target=monitor_host,
        args=(h['id'],h['ip'],h['name'] or h['ip'],h['ping_interval'],
              h['packet_count'],h.get('timeout_ms',1000),h.get('port_checks','')),
        daemon=True, name=f'mon-{h["ip"]}'
    )
    t.start(); _hthreads[h['id']]=t

def start_all():
    hosts = db_all('SELECT * FROM hosts WHERE enabled=1')
    for h in hosts: start_monitor(dict(h))
    log.info(f'Monitoring {len(hosts)} hosts')

# Max ping rows kept per host regardless of time (safety cap).
# At 1 ping/30s = 2880/day. 30 days * 2880 = 86,400 rows max per host.
_MAX_PING_ROWS_PER_HOST = 90000

def run_cleanup(forced=False):
    """Purge old data. Called at startup then every 6 hours. Non-blocking — no VACUUM."""
    try:
        days = int(cfg('data_retention_days', '30'))
        cutoff = utc_since_str(days=days)

        # Delete old ping results by time
        r1 = db_exec('DELETE FROM ping_results WHERE timestamp<?', (cutoff,)).rowcount

        # Safety cap: if a host somehow accumulates too many rows, trim oldest
        hosts = db_all('SELECT id FROM hosts')
        capped = 0
        for h in hosts:
            hid = h['id']
            count = db_one('SELECT COUNT(*) FROM ping_results WHERE host_id=?', (hid,))[0]
            if count > _MAX_PING_ROWS_PER_HOST:
                excess = count - _MAX_PING_ROWS_PER_HOST
                db_exec(
                    'DELETE FROM ping_results WHERE id IN '
                    '(SELECT id FROM ping_results WHERE host_id=? ORDER BY timestamp ASC LIMIT ?)',
                    (hid, excess)
                )
                capped += excess

        r2 = db_exec('DELETE FROM port_results WHERE timestamp<?', (cutoff,)).rowcount
        # Only delete acknowledged alerts; keep unacknowledged indefinitely
        r3 = db_exec('DELETE FROM alerts WHERE timestamp<? AND acknowledged=1', (cutoff,)).rowcount
        db_exec('DELETE FROM sessions WHERE expires_at<?', (datetime.utcnow().isoformat(),))

        # Use incremental WAL checkpoint instead of blocking VACUUM.
        # This frees space without locking the DB.
        with _db_lock:
            get_db().execute('PRAGMA wal_checkpoint(PASSIVE)')

        if r1 or r2 or r3 or capped or forced:
            log.info(f'Cleanup: -{r1} pings, -{r2} port results, -{r3} alerts, -{capped} capped rows (>{days}d retention)')
        else:
            log.info(f'Cleanup: DB healthy, nothing to purge (retention={days}d)')
    except Exception as e:
        log.error(f'Cleanup error: {e}')

def cleanup_loop():
    run_cleanup(forced=True)        # run immediately at startup
    while _running:
        time.sleep(6 * 3600)        # then every 6 hours
        run_cleanup()

# ── STATS ────────────────────────────────────────────────────────
def get_stats(host_id, hours):
    since=utc_since_str(hours=hours)
    r=db_one('SELECT COUNT(*) t,SUM(CASE WHEN status="online" THEN 1 ELSE 0 END) u,AVG(latency_ms) al,MIN(latency_ms) mn,MAX(latency_ms) mx,AVG(packet_loss) ap,AVG(jitter_ms) aj FROM ping_results WHERE host_id=? AND timestamp>?',(host_id,since))
    r=dict(r); total=r['t'] or 0; online=r['u'] or 0
    uptime=round(online/total*100,3) if total else 0.0
    lats=[row[0] for row in db_all('SELECT latency_ms FROM ping_results WHERE host_id=? AND status="online" AND timestamp>? AND latency_ms IS NOT NULL ORDER BY latency_ms',(host_id,since))]
    p95=lats[int(len(lats)*0.95)] if lats else None
    p99=lats[int(len(lats)*0.99)] if lats else None
    return {'total_checks':total,'online_count':online,'uptime_pct':uptime,
            'avg_latency':round(r['al'],2) if r['al'] else None,
            'min_latency':round(r['mn'],2) if r['mn'] else None,
            'max_latency':round(r['mx'],2) if r['mx'] else None,
            'avg_loss':round(r['ap'],2) if r['ap'] else None,
            'avg_jitter':round(r['aj'],2) if r['aj'] else None,
            'p95_latency':round(p95,2) if p95 else None,
            'p99_latency':round(p99,2) if p99 else None}

def get_report(days=30):
    hosts = db_all('SELECT * FROM hosts ORDER BY group_name, name')
    out = []
    for h in hosts:
        h = dict(h); hid = h['id']
        def up(d):
            s = utc_since_str(days=d)
            r = db_one('SELECT COUNT(*) t,SUM(CASE WHEN status="online" THEN 1 ELSE 0 END) u FROM ping_results WHERE host_id=? AND timestamp>?',(hid,s))
            return round((r[1] or 0)/(r[0] or 1)*100, 3)
        since = utc_since_str(days=days)
        inc  = db_one('SELECT COUNT(*) FROM alerts WHERE host_id=? AND type="offline" AND timestamp>?',(hid,since))[0]
        dwn  = db_one("SELECT COUNT(*) FROM ping_results WHERE host_id=? AND status='offline' AND timestamp>?",(hid,since))[0]
        stats_row = db_one('SELECT AVG(latency_ms) al,MIN(latency_ms) mn,MAX(latency_ms) mx,AVG(packet_loss) ap,AVG(jitter_ms) aj FROM ping_results WHERE host_id=? AND status="online" AND timestamp>?',(hid,since))
        last = db_one('SELECT status,latency_ms,timestamp FROM ping_results WHERE host_id=? ORDER BY timestamp DESC LIMIT 1',(hid,))
        out.append({
            'host_id': hid, 'name': h['name'], 'ip': h['ip'],
            'group': h['group_name'], 'location': h.get('location',''),
            'uptime_1d':  up(1),  'uptime_7d':  up(7),
            'uptime_30d': up(30), 'incidents': inc,
            'downtime_mins': round(dwn * h['ping_interval'] / 60, 1),
            'avg_latency':  round(stats_row['al'],2) if stats_row and stats_row['al'] else None,
            'min_latency':  round(stats_row['mn'],2) if stats_row and stats_row['mn'] else None,
            'max_latency':  round(stats_row['mx'],2) if stats_row and stats_row['mx'] else None,
            'avg_loss':     round(stats_row['ap'],2) if stats_row and stats_row['ap'] else None,
            'avg_jitter':   round(stats_row['aj'],2) if stats_row and stats_row['aj'] else None,
            'current_status':  last['status'] if last else 'unknown',
            'current_latency': round(last['latency_ms'],2) if last and last['latency_ms'] else None,
            'last_check': last['timestamp'] if last else None
        })
    return out

def get_period_report_html(period_days=7, period_label='Weekly', uptime_key='uptime_7d'):
    """Generate a self-contained HTML report (weekly or monthly) suitable for printing or saving as PDF."""
    company = cfg('company_name', 'AbayoNet Enterprise')
    report  = get_report(period_days)
    now_str = datetime.now().strftime('%A, %d %B %Y  %H:%M')
    period_start = (datetime.utcnow()-timedelta(days=period_days)).strftime('%d %b %Y')
    period_end   = datetime.now().strftime('%d %b %Y')
    total   = len(report)
    online  = sum(1 for h in report if h['current_status']=='online')
    avg_up  = round(sum(h[uptime_key] for h in report)/total,2) if total else 0
    total_inc = sum(h['incidents'] for h in report)

    rows = ''
    for h in report:
        up = h[uptime_key]
        up_color = '#16a34a' if up>=99 else '#d97706' if up>=95 else '#dc2626'
        st_color = '#16a34a' if h['current_status']=='online' else '#dc2626' if h['current_status']=='offline' else '#6b7280'
        rows += f"""
        <tr>
          <td><strong>{h['name']}</strong></td>
          <td style="font-family:monospace;font-size:11px;">{h['ip']}</td>
          <td>{h['group']}</td>
          <td>{h['location'] or '—'}</td>
          <td style="color:{st_color};font-weight:700;text-transform:uppercase;">{h['current_status']}</td>
          <td style="color:{up_color};font-weight:700;">{up:.3f}%</td>
          <td>{h['uptime_1d']:.3f}%</td>
          <td style="font-family:monospace;">{h['avg_latency'] if h['avg_latency'] else '—'} ms</td>
          <td style="font-family:monospace;">{h['min_latency'] if h['min_latency'] else '—'} ms</td>
          <td style="font-family:monospace;">{h['max_latency'] if h['max_latency'] else '—'} ms</td>
          <td style="font-family:monospace;">{h['avg_loss'] if h['avg_loss'] else '0.0'}%</td>
          <td style="{'color:#dc2626;font-weight:700;' if h['incidents']>0 else ''}">{h['incidents']}</td>
          <td style="font-family:monospace;">{h['downtime_mins']} min</td>
        </tr>"""

    # Recent alerts for the past 7 days
    alert_rows = ''
    alerts = db_all(f"""
        SELECT a.timestamp, a.type, a.message, a.severity, h.name host_name
        FROM alerts a LEFT JOIN hosts h ON a.host_id=h.id
        WHERE a.timestamp > datetime('now','-{period_days} days')
        ORDER BY a.timestamp DESC LIMIT 100""")
    for a in alerts:
        sev_color = '#dc2626' if a['severity']=='critical' else '#d97706' if a['severity']=='warning' else '#2563eb'
        alert_rows += f"""
        <tr>
          <td style="font-family:monospace;font-size:11px;white-space:nowrap;">{a['timestamp']}</td>
          <td>{a['host_name'] or '—'}</td>
          <td style="color:{sev_color};font-weight:700;text-transform:uppercase;">{a['severity']}</td>
          <td>{a['message']}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{period_label} NOC Report — {company}</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{font-family:'Segoe UI',Arial,sans-serif;font-size:12px;color:#1e293b;background:#f8fafc;}}
  .page{{max-width:1200px;margin:0 auto;padding:28px 24px;}}
  .header{{background:linear-gradient(135deg,#0f172a,#1e3a5f);color:#fff;border-radius:10px;padding:24px 28px;margin-bottom:20px;}}
  .header h1{{font-size:22px;font-weight:700;letter-spacing:1px;margin-bottom:4px;}}
  .header .sub{{color:#94a3b8;font-size:12px;}}
  .header .period{{color:#38bdf8;font-size:13px;font-weight:600;margin-top:6px;}}
  .kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}}
  .kpi{{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:14px 16px;text-align:center;box-shadow:0 1px 3px #0001;}}
  .kpi .val{{font-size:26px;font-weight:700;margin-bottom:2px;}}
  .kpi .lbl{{font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;}}
  .section{{background:#fff;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:20px;overflow:hidden;box-shadow:0 1px 3px #0001;}}
  .section-title{{background:#f1f5f9;padding:10px 16px;font-weight:700;font-size:12px;color:#334155;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid #e2e8f0;}}
  table{{width:100%;border-collapse:collapse;font-size:11px;}}
  th{{background:#f8fafc;padding:8px 10px;text-align:left;font-weight:600;color:#475569;border-bottom:2px solid #e2e8f0;white-space:nowrap;}}
  td{{padding:7px 10px;border-bottom:1px solid #f1f5f9;vertical-align:middle;}}
  tr:last-child td{{border-bottom:none;}}
  tr:hover td{{background:#f8fafc;}}
  .footer{{text-align:center;color:#94a3b8;font-size:10px;margin-top:16px;}}
  @media print{{
    body{{background:#fff;}}
    .page{{max-width:100%;padding:10px;}}
    .print-btn{{display:none!important;}}
  }}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
      <div>
        <h1>📡 {period_label.upper()} NOC UPTIME REPORT</h1>
        <div class="sub">{company} · Generated: {now_str}</div>
        <div class="period">Report Period: {period_start} → {period_end} ({period_days} days)</div>
      </div>
      <button class="print-btn" onclick="window.print()" style="background:#38bdf8;color:#0f172a;border:none;padding:9px 18px;border-radius:6px;font-weight:700;cursor:pointer;font-size:12px;">🖨 Print / Save PDF</button>
    </div>
  </div>

  <div class="kpis">
    <div class="kpi"><div class="val" style="color:#0f172a;">{total}</div><div class="lbl">Total Hosts</div></div>
    <div class="kpi"><div class="val" style="color:#16a34a;">{online}</div><div class="lbl">Currently Online</div></div>
    <div class="kpi"><div class="val" style="color:{'#16a34a' if avg_up>=99 else '#d97706' if avg_up>=95 else '#dc2626'};">{avg_up:.2f}%</div><div class="lbl">Avg Uptime ({period_days}d)</div></div>
    <div class="kpi"><div class="val" style="color:{'#dc2626' if total_inc>0 else '#16a34a'};">{total_inc}</div><div class="lbl">Total Incidents ({period_days}d)</div></div>
  </div>

  <div class="section">
    <div class="section-title">📋 Host Uptime Summary</div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr>
        <th>Host</th><th>IP Address</th><th>Group</th><th>Location</th>
        <th>Status</th><th>Uptime {period_days}d</th><th>Uptime 24h</th>
        <th>Avg Lat</th><th>Min Lat</th><th>Max Lat</th>
        <th>Pkt Loss</th><th>Incidents</th><th>Downtime</th>
      </tr></thead>
      <tbody>{rows}</tbody>
    </table>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🔔 Alert Log (Last {period_days} Days — up to 100 events)</div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr><th>Timestamp</th><th>Host</th><th>Severity</th><th>Message</th></tr></thead>
      <tbody>{alert_rows if alert_rows else f'<tr><td colspan="4" style="text-align:center;padding:16px;color:#94a3b8;">No alerts in the last {period_days} days ✓</td></tr>'}</tbody>
    </table>
    </div>
  </div>

  <div class="footer">
    AbayoNet Enterprise NOC Monitor · Report generated {now_str} · {total} hosts monitored
  </div>
</div>
</body>
</html>"""

def get_weekly_report_html():
    return get_period_report_html(7, 'Weekly', 'uptime_7d')

def get_monthly_report_html():
    return get_period_report_html(30, 'Monthly', 'uptime_30d')

# ── HOST IMPORT / EXPORT ─────────────────────────────────────────
def export_json():
    hosts=db_all('SELECT ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes FROM hosts ORDER BY group_name,name')
    return json.dumps({'abayonet_export':True,'version':VERSION,'exported_at':datetime.now().isoformat(),'host_count':len(hosts),'hosts':[dict(h) for h in hosts]},indent=2)

def export_csv_hosts():
    hosts=db_all('SELECT ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes FROM hosts ORDER BY group_name,name')
    out=io.StringIO()
    w=csv.DictWriter(out,fieldnames=['ip','name','group_name','tags','description','location','alert_email','ping_interval','packet_count','timeout_ms','port_checks','notes'])
    w.writeheader()
    for h in hosts: w.writerow(dict(h))
    return out.getvalue()

def import_json(data):
    added = skipped = errors = 0
    # Accept: AbayoNet export {"abayonet_export":true,"hosts":[...]}
    # OR plain list [{ip:...}]  OR {"ips":[...]}  OR plain IP strings
    if isinstance(data, list):
        host_list = data
    elif isinstance(data, dict):
        host_list = data.get('hosts', data.get('data', data.get('ips', [])))
    else:
        return 0, 0, 1

    for h in host_list:
        if isinstance(h, str):          # plain IP string in list
            h = {'ip': h.strip()}
        ip = str(h.get('ip', h.get('address', h.get('host', '')))).strip()
        if not ip:
            errors += 1; continue
        try:
            if db_one('SELECT id FROM hosts WHERE ip=?', (ip,)):
                skipped += 1; continue
            db_exec(
                'INSERT INTO hosts(ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                (ip,
                 h.get('name', ''),
                 h.get('group_name', h.get('group', 'Default')),
                 h.get('tags', ''),
                 h.get('description', ''),
                 h.get('location', ''),
                 h.get('alert_email', ''),
                 int(h.get('ping_interval', 30)),
                 int(h.get('packet_count', 4)),
                 int(h.get('timeout_ms', 1000)),
                 h.get('port_checks', ''),
                 h.get('notes', '')))
            new = db_one('SELECT * FROM hosts WHERE ip=?', (ip,))
            if new: start_monitor(dict(new))
            added += 1
        except Exception as e:
            log.error(f'Import {ip}: {e}'); errors += 1
    return added, skipped, errors

def scan_subnet(subnet):
    results=[]; lock=threading.Lock()
    def scan_ip(ip):
        r=ping(str(ip),1,1000)
        if r['status']=='online':
            with lock: results.append({'ip':str(ip),'latency_ms':r.get('latency'),'hostname':resolve(str(ip)),'ttl':r.get('ttl')})
    threads=[]
    try:
        for ip in list(ipaddress.ip_network(subnet,strict=False).hosts())[:254]:
            t=threading.Thread(target=scan_ip,args=(ip,),daemon=True); t.start(); threads.append(t)
        for t in threads: t.join(timeout=6)
    except Exception as e: log.error(f'Scan: {e}')
    return sorted(results,key=lambda x:int(x['ip'].split('.')[-1]))

def run_trace(ip):
    sname=platform.system().lower()
    try:
        cmd=(['tracert','-d','-h','20','-w','500',ip] if sname=='windows' else ['traceroute','-n','-m','20','-w','2',ip])
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
        return r.stdout or r.stderr or 'No output'
    except subprocess.TimeoutExpired: return 'Timed out'
    except Exception as e: return f'Error: {e}'

# ── HTTP HANDLER ─────────────────────────────────────────────────
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass

    def cors(self):
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type,Authorization')

    def json(self, data, code=200):
        b=json.dumps(data,default=str).encode()
        self.send_response(code)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',len(b))
        self.cors(); self.end_headers(); self.wfile.write(b)

    def file_dl(self, data, mime, fname):
        if isinstance(data,str): data=data.encode()
        self.send_response(200)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Disposition',f'attachment; filename="{fname}"')
        self.send_header('Content-Length',len(data))
        self.cors(); self.end_headers(); self.wfile.write(data)

    def html(self, path):
        try:
            with open(path,'rb') as f: d=f.read()
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',len(d))
            # Always serve the latest file from disk — never let the browser
            # cache a stale copy of the SPA shell after an update.
            self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('Pragma','no-cache')
            self.end_headers(); self.wfile.write(d)
        except FileNotFoundError:
            self.send_response(404); self.end_headers()

    def body(self):
        n=int(self.headers.get('Content-Length',0))
        return json.loads(self.rfile.read(n)) if n else {}

    def do_OPTIONS(self):
        self.send_response(200); self.cors(); self.end_headers()

    def do_GET(self):
        path=urlparse(self.path).path
        qs=parse_qs(urlparse(self.path).query)
        def qp(k,d=''): return qs.get(k,[d])[0]

        if path in ('/','/index.html','/login'):
            self.html('static/index.html'); return
        if path=='/api/version':
            self.json({'version':VERSION,'uptime':round(time.time()-_t0)}); return
        if path=='/api/auth/check':
            sess=check_session(get_token(self))
            self.json({'authenticated':bool(sess),'username':sess['username'] if sess else None,'role':sess['role'] if sess else None}); return
        if path=='/api/auth/renew':
            token=get_token(self); sess=check_session(token)
            if sess: renew_session(token)
            self.json({'ok':bool(sess)}); return

        sess=auth(self)
        if not sess: return
        is_admin=sess['role']=='admin'

        try:
            # DASHBOARD
            if path=='/api/dashboard':
                total=db_one('SELECT COUNT(*) FROM hosts')[0]
                sts=[r[0] for r in db_all("SELECT (SELECT status FROM ping_results WHERE host_id=h.id ORDER BY timestamp DESC LIMIT 1) FROM hosts h")]
                online=sts.count('online'); offline=sts.count('offline')
                unack=db_one('SELECT COUNT(*) FROM alerts WHERE acknowledged=0')[0]
                avg_lat=db_one("SELECT ROUND(AVG(latency_ms),2) FROM ping_results WHERE timestamp>datetime('now','-1 hour') AND status='online'")[0]
                avg_loss=db_one("SELECT ROUND(AVG(packet_loss),2) FROM ping_results WHERE timestamp>datetime('now','-1 hour')")[0]
                degraded=db_one("SELECT COUNT(DISTINCT host_id) FROM ping_results WHERE timestamp>datetime('now','-5 minutes') AND packet_loss>5")[0]
                self.json({'total':total,'online':online,'offline':offline,'unknown':total-online-offline,
                    'unack_alerts':unack,'avg_latency_1h':avg_lat,'avg_loss_1h':avg_loss,'degraded':degraded}); return

            # HOSTS
            if path=='/api/hosts':
                hosts=[dict(h) for h in db_all('SELECT * FROM hosts ORDER BY group_name,name')]
                for h in hosts:
                    last=db_one('SELECT status,latency_ms,packet_loss,jitter_ms,ttl,timestamp FROM ping_results WHERE host_id=? ORDER BY timestamp DESC LIMIT 1',(h['id'],))
                    if last: h.update({'status':last['status'],'latency':last['latency_ms'],'loss':last['packet_loss'],'jitter':last['jitter_ms'],'ttl':last['ttl'],'last_check':last['timestamp']})
                    else: h.update({'status':'unknown','latency':None,'loss':None,'jitter':None,'ttl':None,'last_check':None})
                    up=db_one("SELECT CAST(SUM(CASE WHEN status='online' THEN 1 ELSE 0 END) AS REAL)/MAX(COUNT(*),1)*100 FROM ping_results WHERE host_id=? AND timestamp>datetime('now','-24 hours')",(h['id'],))[0]
                    h['uptime_24h']=round(up or 0,2)
                    h['in_maintenance']=in_maintenance(h['id'])
                self.json(hosts); return

            if path.startswith('/api/host/') and '/history' not in path and '/stats' not in path and '/ports' not in path and '/latest' not in path:
                hid=int(path.split('/')[-1])
                h=dict(db_one('SELECT * FROM hosts WHERE id=?',(hid,)))
                last=db_one('SELECT status,latency_ms,packet_loss,jitter_ms,ttl,timestamp FROM ping_results WHERE host_id=? ORDER BY timestamp DESC LIMIT 1',(hid,))
                if last: h.update({'status':last['status'],'latency':last['latency_ms'],'loss':last['packet_loss'],'jitter':last['jitter_ms'],'ttl':last['ttl'],'last_check':last['timestamp']})
                h['in_maintenance']=in_maintenance(hid)
                self.json(h); return

            if '/history' in path and path.startswith('/api/host/'):
                hid=int(path.split('/')[3])
                from_p=qp('from',''); to_p=qp('to','')
                if from_p and to_p:
                    # Custom date/time range (PRTG-style "From / To" picker).
                    # Accepts datetime-local strings like "2026-06-20T14:30".
                    since=from_p; until=to_p
                    where='host_id=? AND timestamp>=? AND timestamp<=?'
                    rparams=(hid,since,until)
                    try:
                        span_hours=(datetime.fromisoformat(to_p)-datetime.fromisoformat(from_p)).total_seconds()/3600
                    except Exception:
                        span_hours=0
                else:
                    hours=int(qp('hours','24'))
                    since=utc_since_str(hours=hours)
                    where='host_id=? AND timestamp>?'
                    rparams=(hid,since)
                    span_hours=hours
                # For long ranges (multi-week/3-month views), downsample to keep the
                # chart fast: bucket rows and average within each bucket instead of
                # shipping every raw ping. 'offline' wins the bucket if any ping failed.
                if span_hours > 72:
                    target_points = 600
                    total = db_one(f'SELECT COUNT(*) FROM ping_results WHERE {where}',rparams)[0]
                    if total > target_points:
                        rows = db_all(f'''
                            WITH r AS (
                              SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl,
                                     NTILE({target_points}) OVER (ORDER BY timestamp) AS bucket
                              FROM ping_results WHERE {where}
                            )
                            SELECT MAX(timestamp) timestamp,
                                   CASE WHEN SUM(CASE WHEN status='offline' THEN 1 ELSE 0 END)>0 THEN 'offline' ELSE 'online' END status,
                                   ROUND(AVG(latency_ms),2) latency_ms, ROUND(AVG(packet_loss),2) packet_loss,
                                   ROUND(AVG(jitter_ms),2) jitter_ms, ROUND(AVG(ttl),0) ttl
                            FROM r GROUP BY bucket ORDER BY bucket''',rparams)
                        self.json([dict(r) for r in rows]); return
                self.json([dict(r) for r in db_all(f'SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl FROM ping_results WHERE {where} ORDER BY timestamp ASC',rparams)]); return

            if '/latest' in path:
                hid=int(path.split('/')[3])
                n=int(qp('n','120'))
                since_ts=qp('since','')
                if since_ts:
                    rows=db_all('SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl FROM ping_results WHERE host_id=? AND timestamp>? ORDER BY timestamp ASC',(hid,since_ts))
                else:
                    rows=list(reversed(db_all('SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl FROM ping_results WHERE host_id=? ORDER BY timestamp DESC LIMIT ?',(hid,n))))
                self.json([dict(r) for r in rows]); return

            if '/stats' in path:
                hid=int(path.split('/')[3]); hours=int(qp('hours','24'))
                self.json(get_stats(hid,hours)); return

            if '/ports' in path:
                hid=int(path.split('/')[3])
                self.json([dict(r) for r in db_all('SELECT port,status,latency_ms,timestamp FROM port_results WHERE host_id=? ORDER BY timestamp DESC LIMIT 50',(hid,))]); return

            # ALERTS
            if path=='/api/alerts':
                limit=int(qp('limit','100')); unack=qp('unack','0')=='1'
                wh='WHERE a.acknowledged=0' if unack else ''
                self.json([dict(r) for r in db_all(f'SELECT a.*,h.name host_name,h.ip FROM alerts a LEFT JOIN hosts h ON a.host_id=h.id {wh} ORDER BY a.timestamp DESC LIMIT ?',(limit,))]); return
            if path=='/api/alerts/count':
                self.json({'count':db_one('SELECT COUNT(*) FROM alerts WHERE acknowledged=0')[0]}); return
            if path=='/api/alerts/stats':
                self.json({'last_24h':db_one("SELECT COUNT(*) FROM alerts WHERE timestamp>datetime('now','-24 hours')")[0],'last_7d':db_one("SELECT COUNT(*) FROM alerts WHERE timestamp>datetime('now','-7 days')")[0],'critical_unacked':db_one("SELECT COUNT(*) FROM alerts WHERE acknowledged=0 AND severity='critical'")[0]}); return

            # ALERT RULES
            if path=='/api/alert_rules':
                self.json([dict(r) for r in db_all('SELECT r.*,h.name host_name FROM alert_rules r LEFT JOIN hosts h ON r.host_id=h.id ORDER BY r.id')]); return

            # SETTINGS
            if path=='/api/settings':
                self.json({r['key']:r['value'] for r in db_all('SELECT key,value FROM settings')}); return

            # REPORT
            if path=='/api/report/uptime': self.json(get_report(30)); return
            if path=='/api/report/weekly':
                html = get_weekly_report_html()
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
                self.send_header('Content-Length', len(html.encode()))
                self.cors(); self.end_headers()
                self.wfile.write(html.encode()); return
            if path=='/api/report/monthly':
                html = get_monthly_report_html()
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
                self.send_header('Content-Length', len(html.encode()))
                self.cors(); self.end_headers()
                self.wfile.write(html.encode()); return
            if path=='/api/report/export':
                rows=get_report(30); out=io.StringIO()
                w=csv.DictWriter(out,fieldnames=['name','ip','group','location','uptime_1d','uptime_7d','uptime_30d','avg_latency','min_latency','max_latency','avg_loss','avg_jitter','incidents','downtime_mins','current_status','current_latency'],extrasaction='ignore')
                w.writeheader(); w.writerows(rows)
                fname=f'abayonet_report_{datetime.now().strftime("%Y%m%d")}.csv'
                self.file_dl(out.getvalue(),'text/csv',fname); return
            if path=='/api/report/weekly/csv':
                rows=get_report(7); out=io.StringIO()
                w=csv.DictWriter(out,fieldnames=['name','ip','group','location','uptime_1d','uptime_7d','avg_latency','min_latency','max_latency','avg_loss','incidents','downtime_mins','current_status'],extrasaction='ignore')
                w.writeheader(); w.writerows(rows)
                fname=f'abayonet_weekly_{datetime.now().strftime("%Y%m%d")}.csv'
                self.file_dl(out.getvalue(),'text/csv',fname); return
            if path=='/api/report/monthly/csv':
                rows=get_report(30); out=io.StringIO()
                w=csv.DictWriter(out,fieldnames=['name','ip','group','location','uptime_1d','uptime_7d','uptime_30d','avg_latency','min_latency','max_latency','avg_loss','incidents','downtime_mins','current_status'],extrasaction='ignore')
                w.writeheader(); w.writerows(rows)
                fname=f'abayonet_monthly_{datetime.now().strftime("%Y%m%d")}.csv'
                self.file_dl(out.getvalue(),'text/csv',fname); return

            # HOST EXPORT
            if path=='/api/hosts/export/json':
                fname=f'abayonet_hosts_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                self.file_dl(export_json(),'application/json',fname); return
            if path=='/api/hosts/export/csv':
                fname=f'abayonet_hosts_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
                self.file_dl(export_csv_hosts(),'text/csv',fname); return

            # MULTI-HOST HISTORY (for analysis page)
            if path=='/api/history/multi':
                ids_raw=qp('ids',''); hours=int(qp('hours','24'))
                ids=[int(x) for x in ids_raw.split(',') if x.strip().isdigit()]
                if not ids: self.json([]); return
                since=utc_since_str(hours=hours)
                out={}
                for hid in ids:
                    h=db_one('SELECT name,ip FROM hosts WHERE id=?',(hid,))
                    if not h: continue
                    rows=db_all('SELECT timestamp,status,latency_ms,packet_loss,jitter_ms FROM ping_results WHERE host_id=? AND timestamp>? ORDER BY timestamp ASC',(hid,since))
                    out[hid]={'name':h['name'],'ip':h['ip'],'data':[dict(r) for r in rows]}
                self.json(out); return

            # TRACEROUTE
            if path.startswith('/api/traceroute/'):
                self.json({'output':run_trace(path.split('/')[-1])}); return

            # MAINTENANCE
            if path=='/api/maintenance':
                self.json([dict(r) for r in db_all('SELECT m.*,h.name host_name,h.ip FROM maintenance m LEFT JOIN hosts h ON m.host_id=h.id ORDER BY m.start_time DESC')]); return

            # GROUPS / TAGS
            if path=='/api/groups':
                self.json([r[0] for r in db_all('SELECT DISTINCT group_name FROM hosts ORDER BY group_name')]); return
            if path=='/api/tags':
                tags=set()
                for r in db_all('SELECT tags FROM hosts'):
                    for t in (r[0] or '').split(','):
                        if t.strip(): tags.add(t.strip())
                self.json(sorted(tags)); return

            # USERS (admin)
            if path=='/api/users':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                self.json([dict(r) for r in db_all('SELECT id,username,role,full_name,email,created_at,last_login,active FROM users ORDER BY id')]); return
            if path=='/api/users/me':
                u=db_one('SELECT id,username,role,full_name,email,created_at,last_login FROM users WHERE username=?',(sess['username'],))
                self.json(dict(u) if u else {}); return

            self.json({'error':'Not found'},404)
        except Exception as e:
            log.error(f'GET {path}: {e}'); self.json({'error':str(e)},500)

    def do_POST(self):
        path=urlparse(self.path).path

        # PUBLIC: Login
        if path=='/api/auth/login':
            try:
                b=self.body(); ip=self.client_address[0]
                u=db_one('SELECT * FROM users WHERE username=? AND active=1',(b.get('username','').strip(),))
                if not u or u['password']!=hashpw(b.get('password','')):
                    log.warning(f'Failed login: {b.get("username")} from {ip}')
                    self.json({'error':'Invalid username or password'},401); return
                token=make_session(u['id'],u['username'],u['role'],ip)
                log.info(f'Login: {u["username"]} ({u["role"]}) from {ip}')
                self.json({'success':True,'token':token,'username':u['username'],'role':u['role'],'full_name':u['full_name']})
            except Exception as e: self.json({'error':str(e)},500)
            return

        # PUBLIC: Logout
        if path=='/api/auth/logout':
            token=get_token(self)
            if token: db_exec('DELETE FROM sessions WHERE token=?',(token,))
            self.json({'success':True}); return

        sess=auth(self)
        if not sess: return
        b=self.body(); is_admin=sess['role']=='admin'

        try:
            # ADD HOST
            if path=='/api/hosts':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                ip=b.get('ip','').strip()
                if not ip: self.json({'error':'IP required'},400); return
                name=b.get('name','').strip() or resolve(ip) or ip
                db_exec('INSERT INTO hosts(ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                    (ip,name,b.get('group','Default'),b.get('tags',''),b.get('description',''),b.get('location',''),
                     b.get('alert_email',''),max(10,int(b.get('interval',30))),min(20,max(1,int(b.get('packet_count',4)))),
                     int(b.get('timeout_ms',1000)),b.get('port_checks',''),b.get('notes','')))
                h=dict(db_one('SELECT * FROM hosts WHERE ip=?',(ip,)))
                start_monitor(h); self.json({'success':True,'host':h}); return

            # UPDATE HOST
            if path.startswith('/api/hosts/') and '/toggle' not in path and '/bulk' not in path and path != '/api/hosts/import':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                hid=int(path.split('/')[-1])
                db_exec('UPDATE hosts SET name=?,group_name=?,tags=?,description=?,location=?,alert_email=?,ping_interval=?,packet_count=?,timeout_ms=?,port_checks=?,notes=? WHERE id=?',
                    (b.get('name',''),b.get('group','Default'),b.get('tags',''),b.get('description',''),b.get('location',''),
                     b.get('alert_email',''),max(10,int(b.get('interval',30))),min(20,max(1,int(b.get('packet_count',4)))),
                     int(b.get('timeout_ms',1000)),b.get('port_checks',''),b.get('notes',''),hid))
                self.json({'success':True}); return

            # TOGGLE HOST
            if '/toggle' in path and path.startswith('/api/hosts/'):
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                hid=int(path.split('/')[-2])
                db_exec('UPDATE hosts SET enabled=? WHERE id=?',(b.get('enabled',1),hid))
                self.json({'success':True}); return

            # BULK DELETE
            if path=='/api/hosts/bulk_delete':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                for hid in b.get('ids',[]): db_exec('DELETE FROM hosts WHERE id=?',(hid,))
                self.json({'success':True}); return

            # IMPORT HOSTS
            if path=='/api/hosts/import':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                if 'abayonet_export' not in b:
                    self.json({'error':'Invalid file — must be AbayoNet JSON export'},400); return
                added,skipped,errors=import_json(b)
                self.json({'success':True,'added':added,'skipped':skipped,'errors':errors}); return

            # PING NOW
            if path.startswith('/api/ping/'):
                self.json(ping(path.split('/')[-1],4)); return

            # SCAN
            if path=='/api/scan':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                self.json(scan_subnet(b.get('subnet','192.168.1.0/24'))); return

            # ACK ALERTS
            if path.startswith('/api/alerts/') and path.endswith('/ack'):
                aid=int(path.split('/')[-2])
                db_exec("UPDATE alerts SET acknowledged=1,ack_by=?,ack_at=? WHERE id=?",(sess['username'],datetime.now().isoformat(),aid))
                self.json({'success':True}); return
            if path=='/api/alerts/ack_all':
                db_exec("UPDATE alerts SET acknowledged=1,ack_by=?,ack_at=?",(sess['username'],datetime.now().isoformat()))
                self.json({'success':True}); return

            # ALERT RULES
            if path=='/api/alert_rules':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                db_exec('INSERT INTO alert_rules(name,host_id,condition,threshold,duration_mins,notify_email,notify_webhook,cooldown_mins,enabled) VALUES(?,?,?,?,?,?,?,?,1)',
                    (b.get('name','Rule'),int(b.get('host_id',0)),b.get('condition','offline'),
                     float(b.get('threshold',0)),int(b.get('duration_mins',0)),
                     b.get('notify_email',''),b.get('notify_webhook',''),max(1,int(b.get('cooldown_mins',5)))))
                self.json({'success':True}); return
            if path.startswith('/api/alert_rules/') and '/toggle' in path:
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                rid=int(path.split('/')[-2])
                db_exec('UPDATE alert_rules SET enabled=? WHERE id=?',(int(b.get('enabled',1)),rid))
                self.json({'success':True}); return

            # SETTINGS
            if path=='/api/settings':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                for k,v in b.items(): db_exec('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',(k,str(v)))
                self.json({'success':True}); return

            # MAINTENANCE
            if path=='/api/maintenance':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                db_exec('INSERT INTO maintenance(host_id,name,start_time,end_time) VALUES(?,?,?,?)',
                    (b.get('host_id'),b.get('name','Maintenance'),b.get('start_time'),b.get('end_time')))
                self.json({'success':True}); return

            # CREATE USER (admin)
            if path=='/api/users':
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                uname=b.get('username','').strip()
                if not uname: self.json({'error':'Username required'},400); return
                pwd=b.get('password','')
                if len(pwd)<6: self.json({'error':'Password must be at least 6 characters'},400); return
                role=b.get('role','readonly')
                if role not in ('admin','readonly'): self.json({'error':'Role must be admin or readonly'},400); return
                if db_one('SELECT id FROM users WHERE username=?',(uname,)):
                    self.json({'error':'Username already exists'},409); return
                db_exec('INSERT INTO users(username,password,role,full_name,email) VALUES(?,?,?,?,?)',
                    (uname,hashpw(pwd),role,b.get('full_name',''),b.get('email','')))
                log.info(f'User created: {uname} ({role}) by {sess["username"]}')
                self.json({'success':True}); return

            # TOGGLE USER (admin)
            if path.startswith('/api/users/') and path.endswith('/toggle'):
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                uid=int(path.split('/')[-2])
                db_exec('UPDATE users SET active=? WHERE id=?',(int(b.get('active',1)),uid))
                self.json({'success':True}); return

            # RESET PASSWORD (admin)
            if path.startswith('/api/users/') and path.endswith('/reset_password'):
                if not is_admin:
                    self.json({'error':'Admin only'},403); return
                uid=int(path.split('/')[-2])
                pwd=b.get('password','')
                if len(pwd)<6: self.json({'error':'Password too short'},400); return
                db_exec('UPDATE users SET password=? WHERE id=?',(hashpw(pwd),uid))
                db_exec('DELETE FROM sessions WHERE user_id=?',(uid,))
                self.json({'success':True}); return

            # CHANGE OWN PASSWORD
            if path=='/api/users/change_password':
                old=b.get('old_password',''); new=b.get('new_password','')
                if len(new)<6: self.json({'error':'Password too short'},400); return
                u=db_one('SELECT * FROM users WHERE username=?',(sess['username'],))
                if not u or u['password']!=hashpw(old):
                    self.json({'error':'Current password incorrect'},401); return
                db_exec('UPDATE users SET password=? WHERE username=?',(hashpw(new),sess['username']))
                self.json({'success':True}); return

            self.json({'error':'Not found'},404)
        except Exception as e:
            log.error(f'POST {path}: {e}'); self.json({'error':str(e)},500)

    def do_DELETE(self):
        path=urlparse(self.path).path
        # Alerts can be cleared by any logged-in user (same as acknowledging) —
        # admin is only required for destructive host/user/rule operations below.
        sess=auth(self)
        if not sess: return
        is_admin=sess['role']=='admin'
        try:
            if path=='/api/alerts':
                qs=parse_qs(urlparse(self.path).query)
                only_ack=qs.get('acknowledged',[''])[0]=='1'
                if only_ack:
                    n=db_exec('DELETE FROM alerts WHERE acknowledged=1').rowcount
                else:
                    n=db_exec('DELETE FROM alerts').rowcount
                self.json({'success':True,'deleted':n}); return
            if path.startswith('/api/alerts/'):
                aid=int(path.split('/')[-1])
                n=db_exec('DELETE FROM alerts WHERE id=?',(aid,)).rowcount
                self.json({'success':True,'deleted':n}); return

            if not is_admin:
                self.json({'error':'Admin access required'},403); return
            if path.startswith('/api/hosts/'):
                db_exec('DELETE FROM hosts WHERE id=?',(int(path.split('/')[-1]),)); self.json({'success':True}); return
            if path.startswith('/api/alert_rules/'):
                db_exec('DELETE FROM alert_rules WHERE id=?',(int(path.split('/')[-1]),)); self.json({'success':True}); return
            if path.startswith('/api/maintenance/'):
                db_exec('DELETE FROM maintenance WHERE id=?',(int(path.split('/')[-1]),)); self.json({'success':True}); return
            if path.startswith('/api/users/'):
                uid=int(path.split('/')[-1])
                if uid==1: self.json({'error':'Cannot delete primary admin'},403); return
                db_exec('DELETE FROM users WHERE id=?',(uid,)); self.json({'success':True}); return
            self.json({'error':'Not found'},404)
        except Exception as e:
            self.json({'error':str(e)},500)

_t0=time.time()

def get_local_ip():
    """Get the server's primary LAN IP address for display purposes."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '0.0.0.0'

def main():
    log.info(f'=== AbayoNet Enterprise v{VERSION} ===')
    init_db(); start_all()
    threading.Thread(target=cleanup_loop,daemon=True).start()
    PORT=8780
    for p in [8780,8781,8782,9100]:
        try: server=ThreadingHTTPServer(('0.0.0.0',p),H); PORT=p; break
        except OSError: continue
    local_ip = get_local_ip()
    log.info(f'Dashboard → http://127.0.0.1:{PORT}  (local)')
    log.info(f'Network   → http://{local_ip}:{PORT}  (LAN / remote — share this IP with others)')
    log.info(f'All network interfaces are now listening on port {PORT}')
    def _open():
        time.sleep(1.8); webbrowser.open(f'http://127.0.0.1:{PORT}')
    threading.Thread(target=_open,daemon=True).start()
    try: server.serve_forever()
    except KeyboardInterrupt:
        global _running; _running=False; log.info('AbayoNet stopped.')

if __name__=='__main__': main()
