#!/usr/bin/env python3
"""
AbayoNet Enterprise Network Monitor v4.0
Fixes: Database lock (per-thread connection pool)
New:   Login page, Admin/ReadOnly users, User management, Host import/export
"""
import os, sys, threading, time, json, subprocess, platform, queue
import socket, re, smtplib, logging, csv, io, ipaddress, hashlib, secrets
import webbrowser
import decimal
# NOTE: MySQL support (pymysql) is imported further down, once _BASE_DIR
# and the logger are set up, since read_db_config() needs both.
from datetime import datetime, timedelta
from http.server import HTTPServer, ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ── Absolute base directory — works correctly whether run directly,
#    as a Windows Service, or via systemd (cwd varies in all cases) ──
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_DATA_DIR = os.path.join(_BASE_DIR, 'data')
os.makedirs(_DATA_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(
            os.path.join(_DATA_DIR, 'abayonet.log'), encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger('AbayoNet')
VERSION = '10.0'

def _json_fallback(o):
    """json.dumps(..., default=...) hook.
    MySQL DECIMAL-typed query results (e.g. anything involving `/` on
    integer operands, like the uptime-percentage query — MySQL's `/`
    on ints returns DECIMAL, unlike SQLite which returned a plain
    float) come back from PyMySQL as Python decimal.Decimal, which
    json.dumps() can't serialize natively. The previous fallback
    (default=str) silently turned these into JSON STRINGS instead of
    numbers — e.g. `"85.30"` instead of `85.3` — which the frontend
    then crashed on wherever it called .toFixed() on that field
    (h.uptime_24h.toFixed is not a function), since a JS string has no
    such method. Converting Decimal to a real float here fixes it at
    the source for every current and future endpoint, instead of
    patching each individual query that happens to produce one.
    """
    if isinstance(o, decimal.Decimal):
        return float(o)
    return str(o)

# ═══════════════════════════════════════════════════════════════
# DATABASE LAYER — MySQL (was SQLite in earlier versions)
#
# Each thread keeps ONE persistent MySQL connection (threading.local),
# same pattern as before, but now backed by PyMySQL against a real
# MySQL/MariaDB server so the app can run against a proper managed
# database (replication, backups, remote access, no single-writer
# file-lock ceiling).
#
# Connection settings come from abayonet.cfg (section [database]) or
# environment variables (ABAYONET_DB_HOST/PORT/USER/PASSWORD/NAME),
# so the installer can point this at any MySQL server without editing
# code. See read_db_config() below for defaults.
# ═══════════════════════════════════════════════════════════════
import pymysql
import pymysql.cursors
import pymysql.err

class Row(dict):
    """dict that ALSO supports positional access (row[0]), matching the
    sqlite3.Row behaviour this codebase was written against in a few
    places (e.g. db_one(...)[0] for a lone COUNT(*)/AVG(...) column)."""
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return dict.__getitem__(self, key)

class RowDictCursor(pymysql.cursors.DictCursor):
    dict_type = Row

def read_db_config():
    cfg_path = os.path.join(_BASE_DIR, 'abayonet.cfg')
    conf = {
        'host':     os.environ.get('ABAYONET_DB_HOST', 'localhost'),
        'port':     int(os.environ.get('ABAYONET_DB_PORT', '3306')),
        'user':     os.environ.get('ABAYONET_DB_USER', 'abayonet'),
        'password': os.environ.get('ABAYONET_DB_PASSWORD', ''),
        'database': os.environ.get('ABAYONET_DB_NAME', 'abayonet'),
    }
    try:
        if os.path.exists(cfg_path):
            import configparser
            c = configparser.ConfigParser()
            c.read(cfg_path)
            if c.has_section('database'):
                conf['host']     = c.get('database', 'host', fallback=conf['host'])
                conf['port']     = c.getint('database', 'port', fallback=conf['port'])
                conf['user']     = c.get('database', 'user', fallback=conf['user'])
                conf['password'] = c.get('database', 'password', fallback=conf['password'])
                conf['database'] = c.get('database', 'name', fallback=conf['database'])
    except Exception as e:
        log.warning(f'Could not read [database] section of abayonet.cfg, using defaults/env vars: {e}')
    return conf

_DB_CONF = read_db_config()
_tls = threading.local()

def _translate(sql):
    """Adapt the app's SQLite-flavoured SQL text to MySQL syntax at the
    point of execution, so the hundreds of call sites elsewhere in this
    file don't all need touching by hand:
      - '?' positional placeholders -> '%s' (PyMySQL/MySQL paramstyle)
      - 'INSERT OR IGNORE INTO'     -> 'INSERT IGNORE INTO'
      - 'INSERT OR REPLACE INTO'    -> 'REPLACE INTO'
    """
    sql = sql.replace('INSERT OR IGNORE INTO', 'INSERT IGNORE INTO')
    sql = sql.replace('INSERT OR REPLACE INTO', 'REPLACE INTO')
    sql = sql.replace('?', '%s')
    return sql

class _ConnWrapper:
    """Thin shim over a PyMySQL connection that mimics the handful of
    sqlite3.Connection methods this codebase calls directly
    (conn.execute / conn.executemany / conn.commit), so the monitor
    loop, rollup job, and report-cache builder didn't need rewriting
    statement-by-statement."""
    def __init__(self, raw):
        self.raw = raw
    def execute(self, sql, params=()):
        cur = self.raw.cursor()
        cur.execute(_translate(sql), params)
        return cur
    def executemany(self, sql, seq_of_params):
        cur = self.raw.cursor()
        cur.executemany(_translate(sql), seq_of_params)
        return cur
    def cursor(self):
        return self.raw.cursor()
    def commit(self):
        self.raw.commit()
    def close(self):
        self.raw.close()
    def ping(self, reconnect=True):
        # pymysql>=1.1 deprecated the reconnect= kwarg on ping(); do it
        # manually so this works across pymysql versions either way.
        try:
            self.raw.ping(reconnect=False)
        except Exception:
            if reconnect:
                self.raw.connect()
            else:
                raise

def get_db():
    c = getattr(_tls, 'conn', None)
    if c is not None:
        try:
            c.ping(reconnect=True)  # cheap liveness check; auto-reconnects dead connections
            return c
        except Exception:
            try: c.close()
            except Exception: pass
            _tls.conn = None
    raw = pymysql.connect(
        host=_DB_CONF['host'], port=_DB_CONF['port'],
        user=_DB_CONF['user'], password=_DB_CONF['password'],
        database=_DB_CONF['database'], charset='utf8mb4',
        cursorclass=RowDictCursor,
        # IMPORTANT: autocommit=True. With this False, every SELECT
        # (db_one/db_all) started an implicit transaction that was never
        # committed — those functions have no commit() call, only
        # db_exec() (writes) does. With ~90 monitor threads each doing
        # far more reads than writes, that left each thread's connection
        # sitting in a long-open, uncommitted transaction most of the
        # time. That's a classic cause of exactly the kind of MySQL
        # lock-wait-timeout storm seen in production here — dozens of
        # long-open transactions all contending for the same rows.
        # Every DB call in this app is already a single, self-contained
        # statement (nothing spans multiple db_xxx() calls inside one
        # transaction), so autocommit is the correct mode, not a
        # workaround — each call commits itself the instant it finishes.
        autocommit=True, connect_timeout=10,
    )
    wrapped = _ConnWrapper(raw)
    _tls.conn = wrapped
    return wrapped

def close_thread_db():
    c = getattr(_tls, 'conn', None)
    if c:
        try: c.close()
        except: pass
        _tls.conn = None

_RETRYABLE = (1205, 1213)  # 1205 Lock wait timeout exceeded, 1213 Deadlock found
_RETRYABLE_DB_ERRORS = (pymysql.err.OperationalError, pymysql.err.InternalError, pymysql.err.InterfaceError)
# NOTE: pymysql.err.InternalError (e.g. "Packet sequence number wrong" —
# a corrupted/desynced connection) is a SIBLING of OperationalError in
# PyMySQL's exception hierarchy, not a subclass. Catching only
# OperationalError let that specific error class slip straight through
# uncaught, crashing the request instead of discarding the broken
# connection and retrying on a fresh one. InterfaceError (connection
# already closed) has the same problem. All DB call wrappers below
# catch this same wider tuple for that reason.

def db_exec(sql, params=()):
    for attempt in range(8):
        try:
            conn = get_db()
            cur = conn.execute(sql, params)
            conn.commit()
            return cur
        except _RETRYABLE_DB_ERRORS as e:
            code = e.args[0] if e.args else None
            if code in _RETRYABLE or 'lock wait timeout' in str(e).lower() or 'deadlock' in str(e).lower():
                if attempt < 7:
                    wait = min(0.5 * (2 ** attempt), 10)
                    log.warning(f'DB lock retry {attempt+1}/8 (waiting {wait:.1f}s): {e}')
                    time.sleep(wait)
                else:
                    log.error(f'DB write FAILED after 8 retries: {sql[:80]}')
                    raise
            else:
                # e.g. connection lost mid-transaction, or a desynced
                # connection (packet sequence error) — drop the cached
                # connection so the next call reconnects on a fresh one
                # instead of reusing a broken one, then retry.
                close_thread_db()
                if attempt < 7:
                    time.sleep(0.5)
                else:
                    raise

def db_one(sql, params=()):
    for attempt in range(3):
        try:
            return get_db().execute(sql, params).fetchone()
        except _RETRYABLE_DB_ERRORS as e:
            close_thread_db()
            if attempt < 2:
                time.sleep(0.4 * (attempt + 1))
            else:
                log.error(f'db_one FAILED after 3 attempts: {sql[:80]} — {e}')
                raise

def db_all(sql, params=()):
    for attempt in range(3):
        try:
            return get_db().execute(sql, params).fetchall()
        except _RETRYABLE_DB_ERRORS as e:
            close_thread_db()
            if attempt < 2:
                time.sleep(0.4 * (attempt + 1))
            else:
                log.error(f'db_all FAILED after 3 attempts: {sql[:80]} — {e}')
                raise

# ── TIMESTAMP HELPERS ────────────────────────────────────────────
# All timestamp columns that the app queries with range comparisons
# (ping_results/alerts/port_results/hourly/daily) are native MySQL
# DATETIME columns. MySQL compares DATETIME values chronologically
# regardless of formatting, so the SQLite string-lexicographic pitfall
# this used to warn about no longer applies — but we keep writing the
# same 'YYYY-MM-DD HH:MM:SS' format since that's what MySQL DATETIME
# accepts on INSERT and it keeps values consistent with the few
# columns (sessions/users/report_cache) that still store ISO-8601
# text with a 'T' separator.
def utc_now_str():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def utc_since_str(hours=0, days=0):
    return (datetime.now() - timedelta(hours=hours, days=days)).strftime('%Y-%m-%d %H:%M:%S')

def cfg(key, default=''):
    try:
        r = db_one('SELECT `value` FROM settings WHERE `key`=?', (key,))
        return r['value'] if r else default
    except:
        return default

# ── DATABASE INIT ────────────────────────────────────────────────
_SCHEMA_STATEMENTS = [
    """CREATE TABLE IF NOT EXISTS hosts (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        ip              VARCHAR(45) UNIQUE NOT NULL,
        name            VARCHAR(255) DEFAULT '',
        group_name      VARCHAR(255) DEFAULT 'Default',
        tags            VARCHAR(500) DEFAULT '',
        description     TEXT,
        location        VARCHAR(255) DEFAULT '',
        alert_email     VARCHAR(255) DEFAULT '',
        ping_interval   INT DEFAULT 30,
        packet_count    INT DEFAULT 4,
        timeout_ms      INT DEFAULT 1000,
        port_checks     VARCHAR(500) DEFAULT '',
        snmp_community  VARCHAR(100) DEFAULT 'public',
        snmp_enabled    TINYINT DEFAULT 0,
        snmp_port       INT DEFAULT 161,
        enabled         TINYINT DEFAULT 1,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes           TEXT,
        pause_reason    VARCHAR(500) DEFAULT NULL,
        paused_at       DATETIME DEFAULT NULL,
        paused_by       VARCHAR(100) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS ping_results (
        id          BIGINT AUTO_INCREMENT PRIMARY KEY,
        host_id     INT NOT NULL,
        timestamp   DATETIME DEFAULT CURRENT_TIMESTAMP,
        status      VARCHAR(20) NOT NULL,
        latency_ms  FLOAT,
        packet_loss FLOAT,
        jitter_ms   FLOAT,
        ttl         INT,
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    "CREATE INDEX idx_ping_host_ts ON ping_results(host_id, timestamp)",
    "CREATE INDEX idx_ping_ts ON ping_results(timestamp)",
    "CREATE INDEX idx_ping_status ON ping_results(host_id, status, timestamp)",
    "CREATE INDEX idx_ping_cover ON ping_results(host_id, timestamp, status, latency_ms, packet_loss, jitter_ms)",

    """CREATE TABLE IF NOT EXISTS interfaces (
        id           INT AUTO_INCREMENT PRIMARY KEY,
        host_id      INT NOT NULL,
        if_index     INT NOT NULL,
        if_name      VARCHAR(255) DEFAULT '',
        if_speed_bps BIGINT DEFAULT 0,
        monitored    TINYINT DEFAULT 1,
        last_seen    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_host_if (host_id, if_index),
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS bandwidth_results (
        id        BIGINT AUTO_INCREMENT PRIMARY KEY,
        host_id   INT NOT NULL,
        if_index  INT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        in_bps    BIGINT,
        out_bps   BIGINT,
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    "CREATE INDEX idx_bw_host_if_ts ON bandwidth_results(host_id, if_index, timestamp)",

    """CREATE TABLE IF NOT EXISTS ping_hourly (
        id          BIGINT AUTO_INCREMENT PRIMARY KEY,
        host_id     INT NOT NULL,
        hour_ts     DATETIME NOT NULL,
        total       INT DEFAULT 0,
        online      INT DEFAULT 0,
        avg_latency FLOAT, min_latency FLOAT, max_latency FLOAT,
        avg_loss    FLOAT, avg_jitter  FLOAT,
        UNIQUE(host_id, hour_ts),
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    "CREATE INDEX idx_hourly_host_ts ON ping_hourly(host_id, hour_ts)",

    """CREATE TABLE IF NOT EXISTS ping_daily (
        id          BIGINT AUTO_INCREMENT PRIMARY KEY,
        host_id     INT NOT NULL,
        day_ts      DATE NOT NULL,
        total       INT DEFAULT 0,
        online      INT DEFAULT 0,
        avg_latency FLOAT, min_latency FLOAT, max_latency FLOAT,
        avg_loss    FLOAT, avg_jitter  FLOAT,
        UNIQUE(host_id, day_ts),
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    "CREATE INDEX idx_daily_host_ts ON ping_daily(host_id, day_ts)",

    """CREATE TABLE IF NOT EXISTS host_status (
        host_id     INT PRIMARY KEY,
        status      VARCHAR(20) NOT NULL DEFAULT 'unknown',
        latency_ms  FLOAT, packet_loss FLOAT, jitter_ms FLOAT, ttl INT,
        updated_at  VARCHAR(40) NOT NULL DEFAULT '',
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS report_cache (
        host_id       INT PRIMARY KEY,
        cached_at     VARCHAR(40) NOT NULL,
        uptime_1d     FLOAT DEFAULT 0, uptime_7d FLOAT DEFAULT 0, uptime_30d FLOAT DEFAULT 0,
        avg_latency   FLOAT, min_latency FLOAT, max_latency FLOAT,
        avg_loss      FLOAT, avg_jitter  FLOAT,
        incidents     INT DEFAULT 0,
        downtime_mins FLOAT DEFAULT 0,
        cur_status    VARCHAR(20) DEFAULT 'unknown',
        cur_latency   FLOAT,
        last_check    VARCHAR(40),
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS port_results (
        id          BIGINT AUTO_INCREMENT PRIMARY KEY,
        host_id     INT NOT NULL,
        timestamp   DATETIME DEFAULT CURRENT_TIMESTAMP,
        port        INT NOT NULL,
        status      VARCHAR(20) NOT NULL,
        latency_ms  FLOAT,
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS alerts (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        host_id         INT NOT NULL,
        type            VARCHAR(50) NOT NULL,
        message         TEXT NOT NULL,
        severity        VARCHAR(20) DEFAULT 'warning',
        timestamp       DATETIME DEFAULT CURRENT_TIMESTAMP,
        acknowledged    TINYINT DEFAULT 0,
        ack_by          VARCHAR(100) DEFAULT '',
        ack_at          VARCHAR(40) DEFAULT '',
        FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    "CREATE INDEX idx_alerts_ts ON alerts(timestamp)",

    """CREATE TABLE IF NOT EXISTS alert_rules (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        name            VARCHAR(255) NOT NULL,
        host_id         INT DEFAULT 0,
        `condition`     VARCHAR(50) NOT NULL,
        threshold       FLOAT DEFAULT 0,
        duration_mins   INT DEFAULT 0,
        notify_email    VARCHAR(255) DEFAULT '',
        notify_webhook  VARCHAR(255) DEFAULT '',
        enabled         TINYINT DEFAULT 1,
        cooldown_mins   INT DEFAULT 5,
        last_triggered  VARCHAR(40),
        trigger_count   INT DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS maintenance (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        host_id     INT,
        name        VARCHAR(255) NOT NULL,
        start_time  VARCHAR(40) NOT NULL,
        end_time    VARCHAR(40) NOT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS settings (
        `key`   VARCHAR(100) PRIMARY KEY,
        `value` TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS users (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        username    VARCHAR(100) UNIQUE NOT NULL,
        password    VARCHAR(255) NOT NULL,
        role        VARCHAR(20) DEFAULT 'readonly',
        full_name   VARCHAR(255) DEFAULT '',
        email       VARCHAR(255) DEFAULT '',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login  VARCHAR(40) DEFAULT '',
        active      TINYINT DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",

    """CREATE TABLE IF NOT EXISTS sessions (
        token       VARCHAR(100) PRIMARY KEY,
        user_id     INT NOT NULL,
        username    VARCHAR(100) NOT NULL,
        role        VARCHAR(20) NOT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at  VARCHAR(40) NOT NULL,
        ip          VARCHAR(45) DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
]

def _create_index_if_missing(c, stmt):
    """MySQL has no 'CREATE INDEX IF NOT EXISTS' (older/most versions), so
    swallow the 'duplicate key name' error (1061) on repeat runs instead."""
    try:
        c.execute(stmt)
    except pymysql.err.OperationalError as e:
        if e.args and e.args[0] == 1061:
            pass  # index already exists — fine
        else:
            raise

def _add_column_if_missing(c, table, coldef):
    """Same problem as above but for columns: MySQL has no reliable
    'ADD COLUMN IF NOT EXISTS' across versions, so swallow the 'duplicate
    column name' error (1060) on repeat runs. Needed because CREATE TABLE
    IF NOT EXISTS in _SCHEMA_STATEMENTS only helps fresh installs — it
    does nothing for a table that already exists on an already-deployed
    database, which is why new columns need this ALTER TABLE fallback."""
    try:
        c.execute(f'ALTER TABLE {table} ADD COLUMN {coldef}')
    except pymysql.err.OperationalError as e:
        if e.args and e.args[0] == 1060:
            pass  # column already exists — fine
        else:
            raise

def init_db():
    # On boot (or after a MySQL restart), systemd's `After=mysql.service`
    # only guarantees MySQL's own start job was ISSUED before this one —
    # not that MySQL has actually finished initializing (InnoDB crash
    # recovery / buffer pool loading can take real time) and is ready to
    # accept connections yet. Without a retry here, a plain connection
    # attempt at the wrong moment crashes the whole process, and systemd's
    # Restart=on-failure quietly retries every 5s — which *looks* like the
    # app "just takes a while to come up" but is actually a noisy crash
    # loop hidden by `systemctl status` only showing its last few lines.
    # Retrying here instead is faster and produces a clean, honest log.
    raw = None
    for attempt in range(30):  # up to ~60s of graceful waiting
        try:
            raw = pymysql.connect(
                host=_DB_CONF['host'], port=_DB_CONF['port'],
                user=_DB_CONF['user'], password=_DB_CONF['password'],
                database=_DB_CONF['database'], charset='utf8mb4',
                cursorclass=RowDictCursor, autocommit=True,
                connect_timeout=5,
            )
            break
        except Exception as e:
            if attempt == 0:
                log.warning(f'Waiting for MySQL at {_DB_CONF["host"]}:{_DB_CONF["port"]} to become available...')
            if attempt < 29:
                time.sleep(2)
            else:
                log.error(f'Could not connect to MySQL after 60s: {e}')
                raise
    if raw is None:
        raise RuntimeError('Could not establish initial MySQL connection')

    c = raw.cursor()
    for stmt in _SCHEMA_STATEMENTS:
        if stmt.strip().upper().startswith('CREATE INDEX'):
            _create_index_if_missing(c, stmt)
        else:
            c.execute(stmt)

    # Migration: add pause-reason columns to hosts if this DB was created
    # before this feature existed (CREATE TABLE IF NOT EXISTS above only
    # takes effect for a brand-new install, not an existing hosts table).
    _add_column_if_missing(c, 'hosts', 'pause_reason VARCHAR(500) DEFAULT NULL')
    _add_column_if_missing(c, 'hosts', 'paused_at DATETIME DEFAULT NULL')
    _add_column_if_missing(c, 'hosts', 'paused_by VARCHAR(100) DEFAULT NULL')
    _add_column_if_missing(c, 'hosts', 'snmp_enabled TINYINT DEFAULT 0')
    _add_column_if_missing(c, 'hosts', 'snmp_port INT DEFAULT 161')
    _add_column_if_missing(c, 'interfaces', 'monitored TINYINT DEFAULT 1')

    raw.commit()

    defaults = [
        ('smtp_host',''),('smtp_port','587'),('smtp_user',''),('smtp_pass',''),
        ('smtp_from',''),('smtp_tls','1'),('alert_cooldown','300'),
        ('data_retention_days','30'),('theme','dark'),('refresh_interval','10'),
        ('webhook_url',''),('company_name','AbayoNet Enterprise'),
    ]
    for k,v in defaults:
        c.execute('INSERT IGNORE INTO settings(`key`,`value`) VALUES(%s,%s)',(k,v))

    c.execute('SELECT COUNT(*) c FROM alert_rules')
    if c.fetchone()['c'] == 0:
        rules = [
            ('Host Offline',0,'offline',0,0,'','',1,5),
            ('High Latency >200ms',0,'latency_gt',200,0,'','',1,5),
            ('Packet Loss >10%',0,'loss_gt',10,0,'','',1,5),
        ]
        for r in rules:
            c.execute('INSERT INTO alert_rules(name,host_id,`condition`,threshold,duration_mins,notify_email,notify_webhook,enabled,cooldown_mins) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)',r)

    c.execute('SELECT COUNT(*) c FROM users')
    if c.fetchone()['c'] == 0:
        c.execute("INSERT INTO users(username,password,role,full_name,email) VALUES('admin',%s,'admin','Administrator','admin@abayonet.local')",(hashpw('admin123'),))
        log.info('='*55)
        log.info('DEFAULT ADMIN CREATED')
        log.info('  Username: admin')
        log.info('  Password: admin123')
        log.info('  CHANGE THIS PASSWORD after first login!')
        log.info('='*55)

    c.execute('SELECT COUNT(*) c FROM hosts')
    if c.fetchone()['c'] == 0:
        sample = [
            ('8.8.8.8','Google DNS','External DNS','dns,google','Primary Google DNS'),
            ('1.1.1.1','Cloudflare DNS','External DNS','dns,cloudflare','Cloudflare primary'),
            ('8.8.4.4','Google DNS 2','External DNS','dns,google','Secondary Google DNS'),
        ]
        for s in sample:
            c.execute('INSERT IGNORE INTO hosts(ip,name,group_name,tags,description) VALUES(%s,%s,%s,%s,%s)',s)

    raw.commit()
    raw.close()
    log.info(f'AbayoNet v{VERSION} database ready (MySQL: {_DB_CONF["user"]}@{_DB_CONF["host"]}:{_DB_CONF["port"]}/{_DB_CONF["database"]})')

# ── AUTH ─────────────────────────────────────────────────────────
def hashpw(p):
    return hashlib.sha256(('AbayoNet_salt_v4_'+p).encode()).hexdigest()

def make_session(uid, uname, role, ip=''):
    token = secrets.token_urlsafe(48)
    exp = (datetime.now()+timedelta(days=30)).isoformat()
    db_exec('INSERT INTO sessions(token,user_id,username,role,expires_at,ip) VALUES(?,?,?,?,?,?)',(token,uid,uname,role,exp,ip))
    db_exec('UPDATE users SET last_login=? WHERE id=?',(datetime.now().isoformat(),uid))
    return token

def renew_session(token):
    """Slide the expiry window forward on each heartbeat — keeps active sessions alive indefinitely."""
    exp = (datetime.now()+timedelta(days=30)).isoformat()
    db_exec('UPDATE sessions SET expires_at=? WHERE token=?',(exp,token))

def check_session(token):
    if not token: return None
    try:
        r = db_one('SELECT username,role,expires_at FROM sessions WHERE token=?',(token,))
        if not r: return None
        if datetime.fromisoformat(r["expires_at"]) < datetime.now():
            db_exec('DELETE FROM sessions WHERE token=?',(token,))
            return None
        return {'username':r['username'],'role':r['role']}
    except Exception as e:
        # IMPORTANT: this used to be a bare `except: return None`, which
        # silently treated ANY error — a momentary DB hiccup, a bug,
        # anything — as "this session is invalid", logging the user out.
        # With the dashboard polling every ~1s, even a rare transient
        # blip was near-certain to eventually be hit and force a logout
        # on an otherwise-valid, active session. Now it's logged (so a
        # real recurring problem is actually visible in the logs instead
        # of just looking like random logouts) and the caller is told
        # this was a verification failure, not a confirmed invalid
        # session — see auth(), which does not force a logout for this.
        log.error(f'check_session: could not verify token due to an error (NOT treating as logged-out): {e}')
        return 'ERR'

def get_token(handler):
    for part in handler.headers.get('Cookie','').split(';'):
        p = part.strip()
        if p.startswith('abn_token='):
            return p.split('=',1)[1].strip()
    a = handler.headers.get('Authorization','')
    if a.startswith('Bearer '): return a[7:].strip()
    return None

def auth(handler, admin=False):
    sess = check_session(get_token(handler))
    if sess == 'ERR':
        # Verification failed due to a transient error (e.g. a brief DB
        # hiccup), NOT because the session is actually invalid/expired.
        # Deliberately not a 401 and no login_required flag, so the
        # frontend does not force the user back to the login screen for
        # what is likely to resolve itself on the next request.
        handler.json({'error':'Temporarily unable to verify session — please retry','retry':True}, 503)
        return None
    if not sess:
        handler.json({'error':'Unauthorized','login_required':True},401)
        return None
    if admin and sess['role']!='admin':
        handler.json({'error':'Admin access required'},403)
        return None
    return sess

# ── PING ENGINE ──────────────────────────────────────────────────
def ping(ip, count=2, timeout_ms=800):
    """
    Send ICMP ping. Defaults reduced to 2 packets × 800ms = max ~2s per call
    (was 4 packets × 1000ms = up to ~12s). Monitor threads pass their own
    count/timeout from host settings, but Ping Now always gets count=2.
    """
    sname = platform.system().lower()
    ts = max(1, timeout_ms // 1000)
    try:
        if sname == 'windows':
            cmd = ['ping', '-n', str(count), '-w', str(timeout_ms), ip]
        else:
            cmd = ['ping', '-c', str(count), '-W', str(ts), ip]
        # Timeout = per-packet-timeout × count + 4s headroom (was +8s)
        hard_timeout = (timeout_ms / 1000) * count + 4
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=hard_timeout)
        return parse_ping(r.stdout + r.stderr, sname, count)
    except subprocess.TimeoutExpired:
        return offline()
    except Exception:
        return offline()

def parse_ping(out, sname, count):
    lats = []
    ttl = None
    loss = 100.0
    if sname == 'windows':
        for m in re.finditer(r'time[=<](\d+)ms',out,re.I): lats.append(float(m.group(1)))
        m=re.search(r'TTL=(\d+)',out,re.I); ttl=int(m.group(1)) if m else None
        m=re.search(r'\((\d+)%\s*loss\)',out,re.I); loss=float(m.group(1)) if m else 100.0
    else:
        for m in re.finditer(r'time=(\d+\.?\d*)\s*ms',out): lats.append(float(m.group(1)))
        m=re.search(r'ttl=(\d+)',out,re.I); ttl=int(m.group(1)) if m else None
        m=re.search(r'(\d+)%\s*packet loss',out); loss=float(m.group(1)) if m else 100.0
    if not lats: return offline()
    avg = sum(lats)/len(lats)
    loss = max(0.0,(count-len(lats))/count*100)
    jitter = sum(abs(l-avg) for l in lats)/len(lats) if len(lats)>1 else 0.0
    return {'status':'online' if loss<100 else 'offline',
            'latency':round(avg,2),'loss':round(loss,1),
            'jitter':round(jitter,2),'ttl':ttl,
            'min_ms':round(min(lats),2),'max_ms':round(max(lats),2)}

def offline():
    return {'status':'offline','latency':None,'loss':100.0,'jitter':None,'ttl':None,'min_ms':None,'max_ms':None}

def check_port(ip, port, timeout=2):
    try:
        t0=time.time()
        with socket.create_connection((ip,port),timeout=timeout):
            return {'port':port,'status':'open','latency_ms':round((time.time()-t0)*1000,2)}
    except:
        return {'port':port,'status':'closed','latency_ms':None}

def resolve(ip):
    try: return socket.gethostbyaddr(ip)[0]
    except: return ''

# ── SNMP BANDWIDTH ENGINE ────────────────────────────────────────
# Requires the net-snmp command-line tools on this server:
#   sudo apt install snmp
# We shell out to snmpwalk (same approach as ping() above) rather than
# adding a Python SNMP library dependency, keeping this app's only
# Python dependency at PyMySQL.
IF_NAME    = '1.3.6.1.2.1.31.1.1.1.1'   # ifXTable ifName (preferred — cleaner names)
IF_DESCR   = '1.3.6.1.2.1.2.2.1.2'      # ifTable ifDescr (fallback for older devices)
IF_HISPEED = '1.3.6.1.2.1.31.1.1.1.15'  # ifHighSpeed, in Mbps
IF_HC_IN   = '1.3.6.1.2.1.31.1.1.1.6'   # ifHCInOctets  (64-bit counter)
IF_HC_OUT  = '1.3.6.1.2.1.31.1.1.1.10'  # ifHCOutOctets (64-bit counter)

def _snmp_walk(ip, community, port, oid, timeout=6):
    """Run snmpwalk and return {if_index: value_string}. Returns {} (not an
    exception) on any failure — a device that's down or has the wrong
    community string should just skip a poll cycle, not crash the loop."""
    cmd = ['snmpwalk', '-v2c', '-c', community, '-Oqn', '-t', '2', '-r', '1',
           f'{ip}:{port}', oid]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception as e:
        log.warning(f'snmpwalk {ip}:{port} {oid}: {e}')
        return {}
    out = {}
    for line in r.stdout.splitlines():
        line = line.strip()
        if not line or ' ' not in line:
            continue
        left, _, val = line.partition(' ')
        idx = left.rsplit('.', 1)[-1]
        if idx.isdigit():
            out[int(idx)] = val.strip().strip('"')
    return out

def discover_interfaces(host):
    """SNMP-walk a host's interfaces and upsert them into the interfaces
    table. Called on a timer (bandwidth_poll_loop) and once immediately
    when SNMP is first enabled on a host, so the interface picker in the
    UI doesn't sit empty for up to 10 minutes after setup."""
    ip = host['ip']
    community = host.get('snmp_community') or 'public'
    port = host.get('snmp_port') or 161
    names = _snmp_walk(ip, community, port, IF_NAME)
    if not names:
        names = _snmp_walk(ip, community, port, IF_DESCR)
    if not names:
        log.warning(f'SNMP discovery failed for {host.get("name") or ip} ({ip}) '
                    f'— no response, or wrong community string/port')
        return 0
    speeds = _snmp_walk(ip, community, port, IF_HISPEED)
    for idx, name in names.items():
        try:
            speed_bps = int(float(speeds.get(idx, '0'))) * 1_000_000  # Mbps -> bps
        except ValueError:
            speed_bps = 0
        db_exec(
            'INSERT INTO interfaces(host_id,if_index,if_name,if_speed_bps,last_seen) VALUES(?,?,?,?,?) '
            'ON DUPLICATE KEY UPDATE if_name=VALUES(if_name),if_speed_bps=VALUES(if_speed_bps),last_seen=VALUES(last_seen)',
            (host['id'], idx, name, speed_bps, utc_now_str())
        )
    return len(names)

# (host_id, if_index) -> (epoch_seconds, in_octets, out_octets) from the
# previous poll — a bps figure needs two samples, so the first poll after
# (re)start just seeds this and produces no row yet.
_bw_last = {}

def poll_bandwidth_once():
    hosts = db_all('SELECT * FROM hosts WHERE enabled=1 AND snmp_enabled=1')
    for h in hosts:
        h = dict(h)
        ip = h['ip']
        community = h.get('snmp_community') or 'public'
        port = h.get('snmp_port') or 161
        ifaces = db_all('SELECT if_index FROM interfaces WHERE host_id=? AND monitored=1', (h['id'],))
        if not ifaces:
            continue
        in_vals  = _snmp_walk(ip, community, port, IF_HC_IN)
        out_vals = _snmp_walk(ip, community, port, IF_HC_OUT)
        now = time.time()
        for row in ifaces:
            idx = row['if_index']
            if idx not in in_vals or idx not in out_vals:
                continue
            try:
                in_oct, out_oct = int(in_vals[idx]), int(out_vals[idx])
            except ValueError:
                continue
            key = (h['id'], idx)
            prev = _bw_last.get(key)
            _bw_last[key] = (now, in_oct, out_oct)
            if not prev:
                continue  # first sample for this interface — need a delta
            dt = now - prev[0]
            if dt <= 0:
                continue
            d_in, d_out = in_oct - prev[1], out_oct - prev[2]
            if d_in < 0 or d_out < 0:
                # Counter reset (device rebooted) or wrap — skip this sample
                # rather than record a nonsensical negative-derived spike.
                continue
            in_bps  = int((d_in * 8) / dt)
            out_bps = int((d_out * 8) / dt)
            db_exec('INSERT INTO bandwidth_results(host_id,if_index,in_bps,out_bps) VALUES(?,?,?,?)',
                     (h['id'], idx, in_bps, out_bps))

def bandwidth_poll_loop():
    """Background loop: rediscover interfaces every 10 min (cheap, catches
    new/renamed interfaces), poll bandwidth every 60s."""
    last_discovery = 0
    while True:
        try:
            hosts = [dict(h) for h in db_all('SELECT * FROM hosts WHERE enabled=1 AND snmp_enabled=1')]
            if time.time() - last_discovery > 600:
                for h in hosts:
                    discover_interfaces(h)
                last_discovery = time.time()
            poll_bandwidth_once()
        except Exception as e:
            log.error(f'Bandwidth poll error: {e}')
        time.sleep(60)

# ── ALERT ENGINE ─────────────────────────────────────────────────
# _astate: {(host_id, rule_id): datetime of last fire}  — in-memory fast check
# _hstate: {host_id: last known status} — for edge-triggered recovery alerts
_astate = {}
_hstate = {}
_email_queue = None   # initialised in main()

def _prune_astate():
    """Keep _astate from growing forever — remove entries older than 24h."""
    cutoff = datetime.now() - timedelta(hours=24)
    stale = [k for k,v in _astate.items() if v < cutoff]
    for k in stale:
        del _astate[k]

def fire_alerts(host_id, hname, ip, result):
    try:
        rules = db_all(
            'SELECT * FROM alert_rules WHERE (host_id=? OR host_id=0) AND enabled=1',
            (host_id,))
        now    = datetime.now()
        status = result['status']
        prev   = _hstate.get(host_id)
        _hstate[host_id] = status   # update remembered state

        for rule in rules:
            rule = dict(rule)
            rid  = rule['id']
            cond = rule['condition']
            thresh   = rule['threshold']
            cooldown = rule['cooldown_mins'] * 60

            triggered = False; msg = ''; sev = 'warning'

            if cond == 'offline' and status == 'offline':
                triggered = True; sev = 'critical'
                msg = f'🔴 {hname} ({ip}) is OFFLINE'

            elif cond == 'online' and status == 'online' and prev == 'offline':
                # Edge-triggered: only fire ONCE on recovery, not every ping
                triggered = True; sev = 'info'
                msg = f'🟢 {hname} ({ip}) is back ONLINE'

            elif cond == 'latency_gt' and result.get('latency') and result['latency'] > thresh:
                triggered = True
                msg = f'⚡ High latency on {hname} ({ip}): {result["latency"]:.1f}ms > {thresh}ms'

            elif cond == 'loss_gt' and result['loss'] > thresh:
                triggered = True
                msg = f'📦 Packet loss on {hname} ({ip}): {result["loss"]:.1f}% > {thresh}%'

            elif cond == 'jitter_gt' and result.get('jitter') and result['jitter'] > thresh:
                triggered = True
                msg = f'〰 Jitter on {hname} ({ip}): {result["jitter"]:.1f}ms > {thresh}ms'

            if not triggered:
                continue

            # Cooldown check — in-memory first (fast), then also persist to DB
            key  = (host_id, rid)
            last = _astate.get(key)

            # Also check DB last_triggered for crash-restart cooldown persistence
            if not last:
                db_last = rule.get('last_triggered')
                if db_last:
                    try:
                        last = datetime.fromisoformat(db_last)
                        _astate[key] = last   # warm the cache
                    except Exception:
                        pass

            if last and (now - last).total_seconds() < cooldown:
                continue   # still within cooldown — suppress duplicate alert

            _astate[key] = now

            db_exec(
                'INSERT INTO alerts(host_id,type,message,severity,timestamp) VALUES(?,?,?,?,?)',
                (host_id, cond, msg, sev, now.strftime('%Y-%m-%d %H:%M:%S')))
            db_exec(
                'UPDATE alert_rules SET last_triggered=?,trigger_count=trigger_count+1 WHERE id=?',
                (now.isoformat(), rid))
            log.warning(f'ALERT [{sev}]: {msg}')

            em = rule.get('notify_email', '')
            if em and _email_queue:
                try:
                    _email_queue.put_nowait((em, sev, hname, msg))
                except Exception:
                    pass   # queue full — skip this email rather than crash

        # Prune stale _astate entries periodically (roughly every 200 calls)
        if len(_astate) > 500:
            _prune_astate()

    except Exception as e:
        log.error(f'Alert error host={host_id}: {e}')

def _send_email(to, sev, host, msg):
    try:
        h=cfg('smtp_host'); port=int(cfg('smtp_port','587'))
        u=cfg('smtp_user'); p=cfg('smtp_pass'); frm=cfg('smtp_from') or u
        if not h or not u: return
        mm=MIMEMultipart(); mm['From']=frm; mm['To']=to
        mm['Subject']=f'[AbayoNet] {sev.upper()}: {host}'
        mm.attach(MIMEText(msg,'plain'))
        s=smtplib.SMTP(h,port,timeout=10)
        if cfg('smtp_tls','1')=='1': s.starttls()
        s.login(u,p); s.send_message(mm); s.quit()
        log.info(f'Email sent to {to}: {host}')
    except Exception as e:
        log.error(f'Email error: {e}')

def _email_worker(q):
    """Single daemon thread drains the email queue — no unbounded thread creation."""
    while True:
        try:
            item = q.get(timeout=5)
            if item is None:
                break
            _send_email(*item)
        except Exception:
            pass  # queue.Empty timeout or send error — keep running

def in_maintenance(host_id):
    now=datetime.now().isoformat()
    try:
        r=db_one('SELECT id FROM maintenance WHERE (host_id=? OR host_id IS NULL) AND start_time<=? AND end_time>=?',(host_id,now,now))
        return r is not None
    except: return False

# ── MONITOR LOOPS ────────────────────────────────────────────────
_running = True
_hthreads = {}
_hstop = {}  # host_id -> threading.Event; signals that host's monitor thread to stop

def monitor_host(host_id, ip, name, interval, pcount, timeout_ms, ports_str, stop_ev):
    log.info(f'Monitor started: {name} ({ip}) every {interval}s')
    consecutive_errors = 0
    while _running and not stop_ev.is_set():
        try:
            result = ping(ip, pcount, timeout_ms)
            _ts = utc_now_str()
            db_exec(
                'INSERT INTO ping_results(host_id,timestamp,status,latency_ms,packet_loss,jitter_ms,ttl) '
                'VALUES(?,?,?,?,?,?,?)',
                (host_id, _ts, result['status'], result.get('latency'),
                 result['loss'], result.get('jitter'), result.get('ttl')))
            # O(1) current-status — no more MAX(id) or ORDER BY DESC queries
            db_exec(
                'INSERT OR REPLACE INTO host_status'
                '(host_id,status,latency_ms,packet_loss,jitter_ms,ttl,updated_at) '
                'VALUES(?,?,?,?,?,?,?)',
                (host_id, result['status'], result.get('latency'),
                 result['loss'], result.get('jitter'), result.get('ttl'), _ts))
            if not in_maintenance(host_id):
                fire_alerts(host_id, name, ip, result)
            if ports_str:
                for port in [int(p.strip()) for p in ports_str.split(',') if p.strip().isdigit()]:
                    pr = check_port(ip, port)
                    db_exec(
                        'INSERT INTO port_results(host_id,timestamp,port,status,latency_ms) VALUES(?,?,?,?,?)',
                        (host_id, utc_now_str(), port, pr['status'], pr.get('latency_ms')))
            consecutive_errors = 0
        except Exception as e:
            consecutive_errors += 1
            log.error(f'Monitor error {ip} (#{consecutive_errors}): {e}')
            if consecutive_errors >= 5:
                if stop_ev.wait(min(interval * consecutive_errors, 300)):
                    break
        if stop_ev.wait(interval):
            break
    log.info(f'Monitor stopped: {name} ({ip})')
    close_thread_db()

def start_monitor(h):
    hid = h['id']
    existing = _hthreads.get(hid)
    if existing and existing.is_alive():
        log.warning(f'Monitor already running for host {hid} ({h["ip"]}) — skipping duplicate')
        return
    stop_ev = threading.Event()
    _hstop[hid] = stop_ev
    t = threading.Thread(
        target=monitor_host,
        args=(hid, h['ip'], h['name'] or h['ip'], h['ping_interval'],
              h['packet_count'], h.get('timeout_ms', 1000), h.get('port_checks', ''), stop_ev),
        daemon=True, name=f'mon-{h["ip"]}'
    )
    t.start()
    _hthreads[hid] = t

def stop_monitor(hid):
    """Signal a host's monitor thread to stop and wait briefly for it to exit.
    Must be called BEFORE deleting a host (or on disable/IP-edit) so a stale
    thread doesn't keep pinging the old target or inserting ping_results
    rows for a host_id that no longer exists (which trips the FK constraint
    and spams the log)."""
    ev = _hstop.pop(hid, None)
    if ev:
        ev.set()
    t = _hthreads.pop(hid, None)
    if t and t.is_alive():
        t.join(timeout=5)

def restart_monitor(hid):
    """Stop the current monitor thread (if any) for this host and start a
    fresh one from the latest DB row — used after editing a host so IP,
    interval, timeout, and port-check changes take effect immediately
    instead of only after the next process restart."""
    stop_monitor(hid)
    h = db_one('SELECT * FROM hosts WHERE id=?', (hid,))
    if h and h['enabled']:
        start_monitor(dict(h))

def start_all():
    hosts = db_all('SELECT * FROM hosts WHERE enabled=1')
    for h in hosts: start_monitor(dict(h))
    log.info(f'Monitoring {len(hosts)} hosts')
    # Warm report cache immediately in background — so first page load is instant
    # even if the 5-minute refresh cycle hasn't fired yet
    def _warm():
        global _report_cache, _report_cache_ts
        result = _build_report_cache()
        with _report_cache_lock:
            if result:
                _report_cache    = result
                _report_cache_ts = datetime.now()
        log.info(f'Report cache warmed: {len(result)} hosts ready')
    threading.Thread(target=_warm, daemon=True, name='cache-warmup').start()
    # Background 5-minute refresh cycle
    threading.Thread(target=_refresh_report_cache_bg,
                     daemon=True, name='report-cache').start()
    # Watchdog — restarts dead/stalled monitor threads every 60s
    threading.Thread(target=_monitor_watchdog, daemon=True, name='watchdog').start()
    log.info('Cache warmup, report-cache refresh, and watchdog started')

def _monitor_watchdog():
    """
    Safety net: every 2 minutes, check each host's last successful ping.
    If a host hasn't reported in 3x its expected interval (or its monitor
    thread has died), restart that host's monitor thread. This prevents
    a single stalled thread (e.g. from a long DB lock) from silently
    killing monitoring for that host forever.
    """
    while _running:
        time.sleep(60)
        try:
            hosts = db_all('SELECT * FROM hosts WHERE enabled=1')
            for h in hosts:
                h = dict(h)
                hid = h['id']
                t = _hthreads.get(hid)
                thread_dead = (t is None) or (not t.is_alive())

                last = db_one(
                    'SELECT timestamp FROM ping_results WHERE host_id=? '
                    'ORDER BY id DESC LIMIT 1', (hid,))
                stalled = False
                if last and last['timestamp']:
                    try:
                        last_ts = datetime.fromisoformat(last['timestamp'])
                        gap_secs = (datetime.now() - last_ts).total_seconds()
                        expected = max(h['ping_interval'] * 3, 90)
                        stalled = gap_secs > expected
                    except Exception:
                        pass

                if thread_dead or stalled:
                    reason = 'thread dead' if thread_dead else f'stalled ({int(gap_secs)}s since last ping)'
                    log.warning(f'Watchdog: restarting monitor for {h["name"]} ({h["ip"]}) — {reason}')
                    _hthreads.pop(hid, None)  # clear stale entry so start_monitor doesn't skip it
                    start_monitor(h)
        except Exception as e:
            log.error(f'Watchdog error: {e}')
        finally:
            close_thread_db()

def rollup_pings():
    """
    Tiered data retention — permanent solution to data growth:
    - Raw pings:     last 7 days   (full resolution for live graphs)
    - Hourly rollup: 7 - 30 days   (1 row/hour/host for weekly analysis)
    - Daily rollup:  30 - 180 days (1 row/day/host for monthly/6-month reports)

    With 87 hosts at 30s interval:
    OLD (30-day raw): 160K rows/day × 30 = 4.8M rows = ~580MB
    NEW (7-day raw):  160K rows/day × 7  = 1.1M rows + 87×24×23 hourly = tiny
    """
    try:
        cutoff_raw   = utc_since_str(days=7)    # raw pings older than 7 days → roll up
        cutoff_hour  = utc_since_str(days=30)   # hourly rows older than 30 days → roll to daily
        cutoff_keep  = utc_since_str(days=180)  # delete anything older than 180 days

        # Get hosts that have old raw data to process
        host_ids = [r['host_id'] for r in db_all(
            'SELECT DISTINCT host_id FROM ping_results WHERE timestamp<? AND timestamp>=?',
            (cutoff_raw, cutoff_keep))]

        total_archived = 0
        for hid in host_ids:
            try:
                db = get_db()
                # Raw → Hourly (7 to 30 days old)
                db.execute("""
                    INSERT OR IGNORE INTO ping_hourly
                        (host_id,hour_ts,total,online,avg_latency,min_latency,max_latency,avg_loss,avg_jitter)
                    SELECT host_id,
                        DATE_FORMAT(timestamp,'%Y-%m-%d %H:00:00') AS hour_ts,
                        COUNT(*),
                        SUM(CASE WHEN status='online' THEN 1 ELSE 0 END),
                        AVG(latency_ms),MIN(latency_ms),MAX(latency_ms),
                        AVG(packet_loss),AVG(jitter_ms)
                    FROM ping_results
                    WHERE host_id=? AND timestamp<? AND timestamp>=?
                    GROUP BY host_id,hour_ts""", (hid, cutoff_raw, cutoff_keep))

                # Hourly → Daily (>30 days old)
                db.execute("""
                    INSERT OR IGNORE INTO ping_daily
                        (host_id,day_ts,total,online,avg_latency,min_latency,max_latency,avg_loss,avg_jitter)
                    SELECT host_id,
                        DATE_FORMAT(hour_ts,'%Y-%m-%d') AS day_ts,
                        SUM(total),SUM(online),
                        AVG(avg_latency),MIN(min_latency),MAX(max_latency),
                        AVG(avg_loss),AVG(avg_jitter)
                    FROM ping_hourly
                    WHERE host_id=? AND hour_ts<? AND hour_ts>=?
                    GROUP BY host_id,day_ts""", (hid, cutoff_hour, cutoff_keep))

                db.commit()

                # Delete old raw pings for this host
                r = db.execute(
                    'DELETE FROM ping_results WHERE host_id=? AND timestamp<? AND timestamp>=?',
                    (hid, cutoff_raw, cutoff_keep))
                db.commit()
                total_archived += r.rowcount

                time.sleep(0.02)   # brief yield — lets monitor threads get a turn

            except Exception as e:
                log.error(f'Rollup error host {hid}: {e}')
                continue

        # Purge old hourly rows (>30 days) and old daily rows (>180 days)
        db = get_db()
        db.execute('DELETE FROM ping_hourly WHERE hour_ts<?', (cutoff_hour,))
        db.execute('DELETE FROM ping_daily  WHERE day_ts<?',  (cutoff_keep,))
        db.execute('DELETE FROM port_results WHERE timestamp<?', (cutoff_raw,))
        db.commit()

        if total_archived:
            log.info(f'Rollup: {total_archived} raw pings → hourly summaries '
                     f'across {len(host_ids)} hosts (7d raw / 30d hourly / 180d daily)')

    except Exception as e:
        log.error(f'Rollup error: {e}')
    finally:
        close_thread_db()

def run_cleanup(forced=False):
    """Rollup + purge + compact DB. Runs hourly. Each step is independently
    fault-tolerant so one slow/failed step never blocks the others or crashes the loop."""
    try:
        rollup_pings()
    except Exception as e:
        log.error(f'Cleanup: rollup step failed: {e}')

    try:
        cutoff6m = utc_since_str(days=180)
        r3 = db_exec(
            'DELETE FROM alerts WHERE timestamp<? AND acknowledged=1', (cutoff6m,)).rowcount
        db_exec('DELETE FROM sessions WHERE expires_at<?', (datetime.now().isoformat(),))
        if forced or r3:
            log.info(f'Cleanup: {r3} old alerts purged.')
    except Exception as e:
        log.error(f'Cleanup: purge step failed: {e}')

    # No manual vacuum step needed on MySQL/InnoDB — space from deleted
    # rollup rows is reused automatically by InnoDB. (SQLite needed
    # PRAGMA incremental_vacuum here; that has no MySQL equivalent.)
    close_thread_db()

def cleanup_loop():
    # Run first cleanup in background so server startup isn't delayed by a big rollup
    threading.Thread(target=run_cleanup, kwargs={'forced': True}, daemon=True, name='cleanup-initial').start()
    _hour = 0
    while True:
        time.sleep(3600)
        _hour += 1
        # Each hourly cleanup runs in its own thread — if one run takes long,
        # it doesn't delay the next scheduling tick or block monitor threads
        threading.Thread(target=run_cleanup, daemon=True, name=f'cleanup-{_hour}').start()
        if _hour % 24 == 0:
            def _optimize_batch():
                # MySQL/InnoDB equivalent of the old SQLite vacuum pass —
                # OPTIMIZE TABLE reclaims space and rebuilds indexes for the
                # tables that see the heaviest churn (raw pings get rolled
                # up/deleted constantly). Run daily, off-peak-ish (whenever
                # the 24th hourly cleanup lands), one table at a time.
                try:
                    for tbl in ('ping_results', 'ping_hourly', 'ping_daily', 'port_results', 'alerts'):
                        db_exec(f'OPTIMIZE TABLE {tbl}')
                        time.sleep(0.2)
                    log.info('24h OPTIMIZE TABLE batch complete')
                except Exception as e:
                    log.error(f'Optimize error: {e}')
                finally:
                    close_thread_db()
            threading.Thread(target=_optimize_batch, daemon=True, name='optimize-24h').start()

# ── STATS ────────────────────────────────────────────────────────
def get_stats(host_id, hours):
    since=utc_since_str(hours=hours)
    r=db_one('SELECT COUNT(*) t,SUM(CASE WHEN status="online" THEN 1 ELSE 0 END) u,AVG(latency_ms) al,MIN(latency_ms) mn,MAX(latency_ms) mx,AVG(packet_loss) ap,AVG(jitter_ms) aj FROM ping_results WHERE host_id=? AND timestamp>?',(host_id,since))
    r=dict(r); total=r['t'] or 0; online=r['u'] or 0
    uptime=round(online/total*100,3) if total else 0.0
    lats=[row[0] for row in db_all('SELECT latency_ms FROM ping_results WHERE host_id=? AND status="online" AND timestamp>? AND latency_ms IS NOT NULL ORDER BY latency_ms',(host_id,since))]
    p95=lats[int(len(lats)*0.95)] if lats else None
    p99=lats[int(len(lats)*0.99)] if lats else None
    return {'total_checks':total,'online_count':online,'uptime_pct':uptime,
            'avg_latency':round(r['al'],2) if r['al'] else None,
            'min_latency':round(r['mn'],2) if r['mn'] else None,
            'max_latency':round(r['mx'],2) if r['mx'] else None,
            'avg_loss':round(r['ap'],2) if r['ap'] else None,
            'avg_jitter':round(r['aj'],2) if r['aj'] else None,
            'p95_latency':round(p95,2) if p95 else None,
            'p99_latency':round(p99,2) if p99 else None}

# ── REPORT CACHE ─────────────────────────────────────────────────
# Cache is rebuilt in a background thread every 5 minutes.
# API calls return instantly from cache — no live DB scan on page load.
_report_cache      = []          # list of dicts, one per host
_report_cache_ts   = None        # datetime of last successful build
_report_cache_lock = threading.Lock()
_CACHE_TTL_SECS    = 300         # rebuild every 5 minutes

def _build_report_cache():
    """
    Full report computation — runs in background thread every 5 minutes.
    Performance design:
    - Uses ONE mega-query across ALL hosts (not per-host loops)
    - 1d/7d uptime from raw ping_results (7-day retention window)
    - 30d uptime from ping_daily rollup (no raw scan needed)
    - Current status from host_status table (O(1), always fresh)
    - All writes batched into ONE transaction (87 hosts = 1 commit, not 87)
    """
    try:
        hosts = db_all('SELECT * FROM hosts ORDER BY group_name, name')
        if not hosts:
            return []

        since_1d = utc_since_str(days=1)
        since_7d = utc_since_str(days=7)

        # Mega-query on raw ping_results — only 7 days of data max now
        rows = db_all("""
            SELECT
                host_id,
                COUNT(*)                                                      AS total,
                SUM(CASE WHEN status="online" THEN 1 ELSE 0 END)             AS online_all,
                SUM(CASE WHEN status="online" AND timestamp>? THEN 1 ELSE 0 END) AS online_1d,
                SUM(CASE WHEN timestamp>? THEN 1 ELSE 0 END)                 AS total_1d,
                SUM(CASE WHEN status="offline" THEN 1 ELSE 0 END)            AS offline_cnt,
                AVG(CASE WHEN status="online" THEN latency_ms END)           AS avg_lat,
                MIN(CASE WHEN status="online" THEN latency_ms END)           AS min_lat,
                MAX(CASE WHEN status="online" THEN latency_ms END)           AS max_lat,
                AVG(packet_loss)                                              AS avg_loss,
                AVG(jitter_ms)                                                AS avg_jit
            FROM ping_results
            WHERE timestamp > ?
            GROUP BY host_id
        """, (since_1d, since_1d, since_7d))
        stats_map = {r['host_id']: dict(r) for r in rows}

        # 30-day uptime from ping_daily rollup — tiny table, very fast
        since_30d = utc_since_str(days=30)
        daily_rows = db_all(
            'SELECT host_id, SUM(total) t, SUM(online) u '
            'FROM ping_daily WHERE day_ts>? GROUP BY host_id', (since_30d,))
        daily_map = {r['host_id']: (r['u'] or 0, r['t'] or 1) for r in daily_rows}

        # Current status from host_status — O(1), no ping_results scan at all
        status_map = {r['host_id']: dict(r) for r in db_all('SELECT * FROM host_status')}

        # Incident count — alerts table is small
        inc_map = {r['host_id']: r['c'] for r in db_all(
            'SELECT host_id, COUNT(*) c FROM alerts '
            'WHERE type="offline" AND timestamp>? GROUP BY host_id', (since_7d,))}

        out = []
        cache_rows = []
        now_str = datetime.now().isoformat()

        for h in hosts:
            hid = h['id']; h = dict(h)
            s   = stats_map.get(hid, {})
            hs  = status_map.get(hid, {})
            inc = inc_map.get(hid, 0)
            dwn = s.get('offline_cnt', 0) or 0

            up1  = round((s.get('online_1d') or 0) / max(s.get('total_1d') or 1, 1) * 100, 3)
            up7  = round((s.get('online_all') or 0) / max(s.get('total') or 1, 1) * 100, 3)
            d_u, d_t = daily_map.get(hid, (0, 1))
            r_u = s.get('online_all', 0) or 0
            r_t = s.get('total', 0) or 0
            up30 = round((r_u + d_u) / max(r_t + d_t, 1) * 100, 3)

            row = {
                'host_id':        hid,
                'name':           h['name'],
                'ip':             h['ip'],
                'group':          h['group_name'],
                'location':       h.get('location', ''),
                'uptime_1d':      up1,
                'uptime_7d':      up7,
                'uptime_30d':     up30,
                'incidents':      inc,
                'downtime_mins':  round(dwn * h['ping_interval'] / 60, 1),
                'avg_latency':    round(s['avg_lat'], 2) if s.get('avg_lat') else None,
                'min_latency':    round(s['min_lat'], 2) if s.get('min_lat') else None,
                'max_latency':    round(s['max_lat'], 2) if s.get('max_lat') else None,
                'avg_loss':       round(s['avg_loss'], 2) if s.get('avg_loss') else None,
                'avg_jitter':     round(s['avg_jit'], 2) if s.get('avg_jit') else None,
                'current_status':  hs.get('status', 'unknown'),
                'current_latency': round(hs['latency_ms'], 2) if hs.get('latency_ms') else None,
                'last_check':     hs.get('updated_at'),
            }
            out.append(row)
            cache_rows.append((
                hid, now_str, up1, up7, up30,
                row['avg_latency'], row['min_latency'], row['max_latency'],
                row['avg_loss'], row['avg_jitter'],
                inc, row['downtime_mins'],
                row['current_status'], row['current_latency'], row['last_check']
            ))

        # One batched transaction — 87 hosts = 1 commit, not 87
        if cache_rows:
            try:
                conn = get_db()
                conn.executemany("""INSERT OR REPLACE INTO report_cache
                    (host_id,cached_at,uptime_1d,uptime_7d,uptime_30d,
                     avg_latency,min_latency,max_latency,avg_loss,avg_jitter,
                     incidents,downtime_mins,cur_status,cur_latency,last_check)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", cache_rows)
                conn.commit()
            except Exception as e:
                log.error(f'Report cache batch write error: {e}')

        return out

    except Exception as e:
        log.error(f'Report cache build error: {e}')
        return []
    finally:
        close_thread_db()
def _refresh_report_cache_bg():
    """Background thread: rebuild cache every 5 minutes."""
    global _report_cache, _report_cache_ts
    while _running:
        result = _build_report_cache()
        with _report_cache_lock:
            if result:
                _report_cache    = result
                _report_cache_ts = datetime.now()
        time.sleep(_CACHE_TTL_SECS)

def get_report(days=30):
    """Return report from in-memory cache — instant response."""
    global _report_cache, _report_cache_ts
    with _report_cache_lock:
        cached = list(_report_cache)

    if cached:
        return cached

    # Cache empty (first startup) — try DB cache table
    hosts = db_all('SELECT * FROM hosts ORDER BY group_name, name')
    if not hosts:
        return []

    host_map = {h['id']: dict(h) for h in hosts}
    rows = db_all('SELECT * FROM report_cache')
    if rows:
        out = []
        for r in rows:
            h = host_map.get(r['host_id'], {})
            if not h: continue
            out.append({
                'host_id':       r['host_id'],
                'name':          h['name'],     'ip': h['ip'],
                'group':         h['group_name'], 'location': h.get('location',''),
                'uptime_1d':     r['uptime_1d'],
                'uptime_7d':     r['uptime_7d'],
                'uptime_30d':    r['uptime_30d'],
                'incidents':     r['incidents'],
                'downtime_mins': r['downtime_mins'],
                'avg_latency':   r['avg_latency'],
                'min_latency':   r['min_latency'],
                'max_latency':   r['max_latency'],
                'avg_loss':      r['avg_loss'],
                'avg_jitter':    r['avg_jitter'],
                'current_status':  r['cur_status'],
                'current_latency': r['cur_latency'],
                'last_check':    r['last_check'],
            })
        # Warm the in-memory cache from DB so next call is instant
        with _report_cache_lock:
            _report_cache    = out
            _report_cache_ts = datetime.now()
        return out

    # Truly first run — build synchronously this one time
    log.info('First report build — computing now (subsequent loads will be instant)...')
    result = _build_report_cache()
    with _report_cache_lock:
        _report_cache    = result
        _report_cache_ts = datetime.now()
    return result

def get_period_report_html(period_days=7, period_label='Weekly', uptime_key='uptime_7d'):
    """Generate a self-contained HTML report (weekly or monthly) suitable for printing or saving as PDF."""
    company = cfg('company_name', 'AbayoNet Enterprise')
    report  = get_report(period_days)
    now_str = datetime.now().strftime('%A, %d %B %Y  %H:%M')
    period_start = (datetime.now()-timedelta(days=period_days)).strftime('%d %b %Y')
    period_end   = datetime.now().strftime('%d %b %Y')
    total   = len(report)
    online  = sum(1 for h in report if h['current_status']=='online')
    avg_up  = round(sum(h[uptime_key] for h in report)/total,2) if total else 0
    total_inc = sum(h['incidents'] for h in report)

    rows = ''
    for h in report:
        up = h[uptime_key]
        up_color = '#16a34a' if up>=99 else '#d97706' if up>=95 else '#dc2626'
        st_color = '#16a34a' if h['current_status']=='online' else '#dc2626' if h['current_status']=='offline' else '#6b7280'
        rows += f"""
        <tr>
          <td><strong>{h['name']}</strong></td>
          <td style="font-family:monospace;font-size:11px;">{h['ip']}</td>
          <td>{h['group']}</td>
          <td>{h['location'] or '—'}</td>
          <td style="color:{st_color};font-weight:700;text-transform:uppercase;">{h['current_status']}</td>
          <td style="color:{up_color};font-weight:700;">{up:.3f}%</td>
          <td>{h['uptime_1d']:.3f}%</td>
          <td style="font-family:monospace;">{h['avg_latency'] if h['avg_latency'] else '—'} ms</td>
          <td style="font-family:monospace;">{h['min_latency'] if h['min_latency'] else '—'} ms</td>
          <td style="font-family:monospace;">{h['max_latency'] if h['max_latency'] else '—'} ms</td>
          <td style="font-family:monospace;">{h['avg_loss'] if h['avg_loss'] else '0.0'}%</td>
          <td style="{'color:#dc2626;font-weight:700;' if h['incidents']>0 else ''}">{h['incidents']}</td>
          <td style="font-family:monospace;">{h['downtime_mins']} min</td>
        </tr>"""

    # Recent alerts for the past 7 days
    alert_rows = ''
    since_period = utc_since_str(days=period_days)
    alerts = db_all("""
        SELECT a.timestamp, a.type, a.message, a.severity, h.name host_name
        FROM alerts a LEFT JOIN hosts h ON a.host_id=h.id
        WHERE a.timestamp > ?
        ORDER BY a.timestamp DESC LIMIT 100""", (since_period,))
    for a in alerts:
        sev_color = '#dc2626' if a['severity']=='critical' else '#d97706' if a['severity']=='warning' else '#2563eb'
        alert_rows += f"""
        <tr>
          <td style="font-family:monospace;font-size:11px;white-space:nowrap;">{a['timestamp']}</td>
          <td>{a['host_name'] or '—'}</td>
          <td style="color:{sev_color};font-weight:700;text-transform:uppercase;">{a['severity']}</td>
          <td>{a['message']}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{period_label} NOC Report — {company}</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{font-family:'Segoe UI',Arial,sans-serif;font-size:12px;color:#1e293b;background:#f8fafc;}}
  .page{{max-width:1200px;margin:0 auto;padding:28px 24px;}}
  .header{{background:linear-gradient(135deg,#0f172a,#1e3a5f);color:#fff;border-radius:10px;padding:24px 28px;margin-bottom:20px;}}
  .header h1{{font-size:22px;font-weight:700;letter-spacing:1px;margin-bottom:4px;}}
  .header .sub{{color:#94a3b8;font-size:12px;}}
  .header .period{{color:#38bdf8;font-size:13px;font-weight:600;margin-top:6px;}}
  .kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}}
  .kpi{{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:14px 16px;text-align:center;box-shadow:0 1px 3px #0001;}}
  .kpi .val{{font-size:26px;font-weight:700;margin-bottom:2px;}}
  .kpi .lbl{{font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;}}
  .section{{background:#fff;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:20px;overflow:hidden;box-shadow:0 1px 3px #0001;}}
  .section-title{{background:#f1f5f9;padding:10px 16px;font-weight:700;font-size:12px;color:#334155;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid #e2e8f0;}}
  table{{width:100%;border-collapse:collapse;font-size:11px;}}
  th{{background:#f8fafc;padding:8px 10px;text-align:left;font-weight:600;color:#475569;border-bottom:2px solid #e2e8f0;white-space:nowrap;}}
  td{{padding:7px 10px;border-bottom:1px solid #f1f5f9;vertical-align:middle;}}
  tr:last-child td{{border-bottom:none;}}
  tr:hover td{{background:#f8fafc;}}
  .footer{{text-align:center;color:#94a3b8;font-size:10px;margin-top:16px;}}
  @media print{{
    body{{background:#fff;}}
    .page{{max-width:100%;padding:10px;}}
    .print-btn{{display:none!important;}}
  }}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
      <div>
        <h1>📡 {period_label.upper()} NOC UPTIME REPORT</h1>
        <div class="sub">{company} · Generated: {now_str}</div>
        <div class="period">Report Period: {period_start} → {period_end} ({period_days} days)</div>
      </div>
      <button class="print-btn" onclick="window.print()" style="background:#38bdf8;color:#0f172a;border:none;padding:9px 18px;border-radius:6px;font-weight:700;cursor:pointer;font-size:12px;">🖨 Print / Save PDF</button>
    </div>
  </div>

  <div class="kpis">
    <div class="kpi"><div class="val" style="color:#0f172a;">{total}</div><div class="lbl">Total Hosts</div></div>
    <div class="kpi"><div class="val" style="color:#16a34a;">{online}</div><div class="lbl">Currently Online</div></div>
    <div class="kpi"><div class="val" style="color:{'#16a34a' if avg_up>=99 else '#d97706' if avg_up>=95 else '#dc2626'};">{avg_up:.2f}%</div><div class="lbl">Avg Uptime ({period_days}d)</div></div>
    <div class="kpi"><div class="val" style="color:{'#dc2626' if total_inc>0 else '#16a34a'};">{total_inc}</div><div class="lbl">Total Incidents ({period_days}d)</div></div>
  </div>

  <div class="section">
    <div class="section-title">📋 Host Uptime Summary</div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr>
        <th>Host</th><th>IP Address</th><th>Group</th><th>Location</th>
        <th>Status</th><th>Uptime {period_days}d</th><th>Uptime 24h</th>
        <th>Avg Lat</th><th>Min Lat</th><th>Max Lat</th>
        <th>Pkt Loss</th><th>Incidents</th><th>Downtime</th>
      </tr></thead>
      <tbody>{rows}</tbody>
    </table>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🔔 Alert Log (Last {period_days} Days — up to 100 events)</div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr><th>Timestamp</th><th>Host</th><th>Severity</th><th>Message</th></tr></thead>
      <tbody>{alert_rows if alert_rows else f'<tr><td colspan="4" style="text-align:center;padding:16px;color:#94a3b8;">No alerts in the last {period_days} days ✓</td></tr>'}</tbody>
    </table>
    </div>
  </div>

  <div class="footer">
    AbayoNet Enterprise NOC Monitor · Report generated {now_str} · {total} hosts monitored
  </div>
</div>
</body>
</html>"""

def get_weekly_report_html():
    return get_period_report_html(7, 'Weekly', 'uptime_7d')

def get_monthly_report_html():
    return get_period_report_html(30, 'Monthly', 'uptime_30d')

# ── HOST IMPORT / EXPORT ─────────────────────────────────────────
def export_json():
    hosts=db_all('SELECT ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes FROM hosts ORDER BY group_name,name')
    return json.dumps({'abayonet_export':True,'version':VERSION,'exported_at':datetime.now().isoformat(),'host_count':len(hosts),'hosts':[dict(h) for h in hosts]},indent=2,default=_json_fallback)

def export_csv_hosts():
    hosts=db_all('SELECT ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes FROM hosts ORDER BY group_name,name')
    out=io.StringIO()
    w=csv.DictWriter(out,fieldnames=['ip','name','group_name','tags','description','location','alert_email','ping_interval','packet_count','timeout_ms','port_checks','notes'])
    w.writeheader()
    for h in hosts: w.writerow(dict(h))
    return out.getvalue()

def import_json(data):
    added = skipped = errors = 0
    # Accept: AbayoNet export {"abayonet_export":true,"hosts":[...]}
    # OR plain list [{ip:...}]  OR {"ips":[...]}  OR plain IP strings
    if isinstance(data, list):
        host_list = data
    elif isinstance(data, dict):
        host_list = data.get('hosts', data.get('data', data.get('ips', [])))
    else:
        return 0, 0, 1

    for h in host_list:
        if isinstance(h, str):          # plain IP string in list
            h = {'ip': h.strip()}
        ip = str(h.get('ip', h.get('address', h.get('host', '')))).strip()
        if not ip:
            errors += 1; continue
        try:
            if db_one('SELECT id FROM hosts WHERE ip=?', (ip,)):
                skipped += 1; continue
            db_exec(
                'INSERT INTO hosts(ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                (ip,
                 h.get('name', ''),
                 h.get('group_name', h.get('group', 'Default')),
                 h.get('tags', ''),
                 h.get('description', ''),
                 h.get('location', ''),
                 h.get('alert_email', ''),
                 int(h.get('ping_interval', 30)),
                 int(h.get('packet_count', 4)),
                 int(h.get('timeout_ms', 1000)),
                 h.get('port_checks', ''),
                 h.get('notes', '')))
            new = db_one('SELECT * FROM hosts WHERE ip=?', (ip,))
            if new: start_monitor(dict(new))
            added += 1
        except Exception as e:
            log.error(f'Import {ip}: {e}'); errors += 1
    return added, skipped, errors

def scan_subnet(subnet):
    results=[]; lock=threading.Lock()
    def scan_ip(ip):
        r=ping(str(ip),1,1000)
        if r['status']=='online':
            with lock: results.append({'ip':str(ip),'latency_ms':r.get('latency'),'hostname':resolve(str(ip)),'ttl':r.get('ttl')})
    threads=[]
    try:
        for ip in list(ipaddress.ip_network(subnet,strict=False).hosts())[:254]:
            t=threading.Thread(target=scan_ip,args=(ip,),daemon=True); t.start(); threads.append(t)
        for t in threads: t.join(timeout=6)
    except Exception as e: log.error(f'Scan: {e}')
    return sorted(results,key=lambda x:int(x['ip'].split('.')[-1]))

def run_trace(ip):
    sname = platform.system().lower()
    try:
        if sname == 'windows':
            # -d: no DNS, -h 15: max 15 hops, -w 300: 300ms per hop timeout
            cmd = ['tracert', '-d', '-h', '15', '-w', '300', ip]
            timeout = 25
        else:
            cmd = ['traceroute', '-n', '-m', '15', '-w', '1', ip]
            timeout = 25
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout or r.stderr or 'No output'
    except subprocess.TimeoutExpired:
        return 'Timed out after 25s'
    except Exception as e:
        return f'Error: {e}'

# ── HTTP HANDLER ─────────────────────────────────────────────────
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass

    def cors(self):
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type,Authorization')

    def json(self, data, code=200):
        try:
            b = json.dumps(data, default=_json_fallback).encode()
            self.send_response(code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', len(b))
            self.cors(); self.end_headers(); self.wfile.write(b)
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            pass  # client disconnected before response sent — ignore

    def file_dl(self, data, mime, fname):
        try:
            if isinstance(data, str): data = data.encode()
            self.send_response(200)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Disposition', f'attachment; filename="{fname}"')
            self.send_header('Content-Length', len(data))
            self.cors(); self.end_headers(); self.wfile.write(data)
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            pass

    def html(self, path):
        try:
            abs_path = os.path.join(_BASE_DIR, path)
            with open(abs_path, 'rb') as f:
                d = f.read()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', len(d))
            self.send_header('Cache-Control',
                             'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.end_headers()
            self.wfile.write(d)
        except FileNotFoundError:
            msg = (
                f'<html><body style="font-family:sans-serif;padding:40px;'
                f'background:#0a1220;color:#ff6666;">'
                f'<h2>AbayoNet: File Not Found</h2>'
                f'<p>Expected: <code>{os.path.join(_BASE_DIR, path)}</code></p>'
                f'<p>Make sure <strong>index.html</strong> is inside a '
                f'<strong>static\\</strong> subfolder next to abayonet.py</p>'
                f'<pre>AbayoNet\\\n'
                f'&#9500;&#9472;&#9472; abayonet.py\n'
                f'&#9500;&#9472;&#9472; abayonet_service.py\n'
                f'&#9500;&#9472;&#9472; START_ABAYONET.bat\n'
                f'&#9492;&#9472;&#9472; static\\\n'
                f'    &#9492;&#9472;&#9472; index.html  &#8592; must be here</pre>'
                f'</body></html>'
            ).encode()
            self.send_response(404)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', len(msg))
            self.end_headers()
            self.wfile.write(msg)

    def body(self):
        try:
            n = int(self.headers.get('Content-Length') or 0)
            if n > 0:
                raw = self.rfile.read(n)
            else:
                # No Content-Length header — read all available bytes
                chunks = []
                while True:
                    chunk = self.rfile.read(8192)
                    if not chunk:
                        break
                    chunks.append(chunk)
                raw = b''.join(chunks)
            return json.loads(raw.decode('utf-8')) if raw and raw.strip() else {}
        except Exception as e:
            log.error(f'POST body parse error: {e}')
            return {}

    def do_OPTIONS(self):
        self.send_response(200); self.cors(); self.end_headers()

    def do_GET(self):
        path=urlparse(self.path).path
        qs=parse_qs(urlparse(self.path).query)
        def qp(k,d=''): return qs.get(k,[d])[0]

        if path in ('/','/index.html','/login'):
            self.html('static/index.html'); return
        if path=='/api/version':
            self.json({'version':VERSION,'uptime':round(time.time()-_t0)}); return
        if path=='/api/auth/check':
            sess=check_session(get_token(self))
            if sess=='ERR':
                # Could not verify due to a transient error — tell the
                # client "unknown", not "not authenticated", so a brief
                # DB hiccup at page-load time doesn't wipe a valid saved
                # token. See auth() for the same principle applied to
                # every other authenticated endpoint.
                self.json({'authenticated':None,'retry':True}); return
            self.json({'authenticated':bool(sess),'username':sess['username'] if sess else None,'role':sess['role'] if sess else None}); return
        if path=='/api/auth/renew':
            token=get_token(self); sess=check_session(token)
            if sess and sess!='ERR': renew_session(token)
            self.json({'ok': bool(sess) and sess!='ERR'}); return

        sess=auth(self)
        if not sess: return
        is_admin=sess['role']=='admin'

        try:
            # DASHBOARD
            if path=='/api/dashboard':
                total   = db_one('SELECT COUNT(*) FROM hosts')[0]
                online  = db_one("SELECT COUNT(*) FROM host_status WHERE status='online'")[0]
                offline = db_one("SELECT COUNT(*) FROM host_status WHERE status='offline'")[0]
                unack   = db_one('SELECT COUNT(*) FROM alerts WHERE acknowledged=0')[0]
                since_1h = utc_since_str(hours=1)
                avg_lat  = db_one("SELECT ROUND(AVG(latency_ms),2) FROM ping_results WHERE timestamp>? AND status='online'",(since_1h,))[0]
                avg_loss = db_one("SELECT ROUND(AVG(packet_loss),2) FROM ping_results WHERE timestamp>?",(since_1h,))[0]
                degraded = db_one("SELECT COUNT(*) FROM host_status WHERE packet_loss>5")[0]
                self.json({'total':total,'online':online,'offline':offline,
                    'unknown':max(0,total-online-offline),
                    'unack_alerts':unack,'avg_latency_1h':avg_lat,
                    'avg_loss_1h':avg_loss,'degraded':degraded}); return

            # DASHBOARD CHART — single query for top-6 hosts with most recent data
            if path=='/api/dashboard/chart':
                since_1h = utc_since_str(hours=1)
                active = db_all(
                    "SELECT p.host_id, h.name, h.ip "
                    "FROM ping_results p JOIN hosts h ON h.id=p.host_id "
                    "WHERE p.timestamp > ? "
                    "GROUP BY p.host_id, h.name, h.ip ORDER BY MAX(p.timestamp) DESC LIMIT 6", (since_1h,))
                if not active:
                    self.json([]); return
                ids = [r['host_id'] for r in active]
                placeholders = ','.join('?' * len(ids))
                rows = db_all(
                    f"SELECT host_id, timestamp, latency_ms, packet_loss, status "
                    f"FROM ping_results WHERE host_id IN ({placeholders}) "
                    f"AND timestamp > ? "
                    f"ORDER BY host_id, timestamp ASC", ids + [since_1h])
                host_data = {}
                for a in active:
                    host_data[a['host_id']] = {'name': a['name'], 'ip': a['ip'], 'points': []}
                for r in rows:
                    if r['host_id'] in host_data:
                        host_data[r['host_id']]['points'].append({
                            'ts': r['timestamp'],
                            'lat': r['latency_ms'],
                            'loss': r['packet_loss'],
                            'status': r['status']
                        })
                self.json(list(host_data.values())); return

            # HOSTS — uses host_status table for O(1) per-host status (no ping_results scan)
            if path=='/api/hosts':
                since_24h = utc_since_str(hours=24)
                hosts = [dict(h) for h in db_all('SELECT * FROM hosts ORDER BY group_name,name')]
                # ONE join query for all current statuses — no per-host loop
                status_map = {r['host_id']: dict(r) for r in db_all(
                    'SELECT * FROM host_status')}
                # ONE bulk uptime query using cover index
                # NOTE: no CAST needed here — unlike SQLite, MySQL's `/` operator
                # already produces a decimal result for integer operands, so the
                # old CAST(... AS REAL) (not a valid MySQL type; would error) is
                # dropped rather than translated.
                uptime_rows = db_all(
                    "SELECT host_id, "
                    "SUM(CASE WHEN status='online' THEN 1 ELSE 0 END)"
                    "/GREATEST(COUNT(*),1)*100 AS up "
                    "FROM ping_results WHERE timestamp>? GROUP BY host_id", (since_24h,))
                uptime_map = {r['host_id']: round(r['up'] or 0, 2) for r in uptime_rows}
                for h in hosts:
                    hid = h['id']
                    s = status_map.get(hid, {})
                    h.update({
                        'status':     s.get('status', 'unknown'),
                        'latency':    s.get('latency_ms'),
                        'loss':       s.get('packet_loss'),
                        'jitter':     s.get('jitter_ms'),
                        'ttl':        s.get('ttl'),
                        'last_check': s.get('updated_at'),
                        'uptime_24h': uptime_map.get(hid, 0.0),
                        'in_maintenance': in_maintenance(hid),
                    })
                self.json(hosts); return

            if path.startswith('/api/host/') and '/history' not in path and '/stats' not in path and '/ports' not in path and '/latest' not in path and '/interfaces' not in path and '/bandwidth' not in path:
                hid = int(path.split('/')[-1])
                h = dict(db_one('SELECT * FROM hosts WHERE id=?', (hid,)))
                s = db_one('SELECT * FROM host_status WHERE host_id=?', (hid,))
                if s: h.update({'status':s['status'],'latency':s['latency_ms'],'loss':s['packet_loss'],
                                'jitter':s['jitter_ms'],'ttl':s['ttl'],'last_check':s['updated_at']})
                h['in_maintenance'] = in_maintenance(hid)
                self.json(h); return

            if '/history' in path:
                hid=int(path.split('/')[3])
                from_p=qp('from',''); to_p=qp('to','')
                if from_p and to_p:
                    since=from_p; until=to_p
                    try:
                        span_hours=(datetime.fromisoformat(to_p)-datetime.fromisoformat(from_p)).total_seconds()/3600
                    except Exception:
                        span_hours=24
                else:
                    hours=int(qp('hours','24'))
                    since=utc_since_str(hours=hours)
                    until=None
                    span_hours=hours

                # For short windows (<=7 days), use a Python-computed cutoff —
                # SQLite's localtime modifier is unreliable on some Windows builds
                if span_hours <= 168 and not from_p:
                    since_window = utc_since_str(hours=span_hours)
                    rows = db_all(
                        "SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl "
                        "FROM ping_results WHERE host_id=? "
                        "AND timestamp > ? "
                        "ORDER BY timestamp ASC", (hid, since_window))
                    if len(rows) > 800:
                        step = max(1, len(rows)//800)
                        rows = rows[::step]
                    self.json([dict(r) for r in rows]); return

                # Decide data source based on age of requested window:
                cutoff_raw  = utc_since_str(days=30)
                cutoff_keep = utc_since_str(days=180)

                if since >= cutoff_raw:
                    # Recent window — raw data
                    if until:
                        rows = db_all(
                            'SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl '
                            'FROM ping_results WHERE host_id=? AND timestamp>=? AND timestamp<=? '
                            'ORDER BY timestamp ASC', (hid,since,until))
                    else:
                        rows = db_all(
                            'SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl '
                            'FROM ping_results WHERE host_id=? AND timestamp>? '
                            'ORDER BY timestamp ASC', (hid,since))
                    if len(rows) > 800:
                        step = max(1, len(rows)//800)
                        rows = rows[::step]
                    self.json([dict(r) for r in rows]); return

                elif since >= cutoff_keep:
                    # Historical window — use hourly rollup
                    if until:
                        rows = db_all(
                            'SELECT hour_ts timestamp,'
                            '  CASE WHEN online=total THEN "online" ELSE "offline" END status,'
                            '  ROUND(avg_latency,2) latency_ms, ROUND(avg_loss,2) packet_loss,'
                            '  ROUND(avg_jitter,2) jitter_ms, NULL ttl '
                            'FROM ping_hourly WHERE host_id=? AND hour_ts>=? AND hour_ts<=? '
                            'ORDER BY hour_ts ASC', (hid,since,until))
                    else:
                        rows = db_all(
                            'SELECT hour_ts timestamp,'
                            '  CASE WHEN online=total THEN "online" ELSE "offline" END status,'
                            '  ROUND(avg_latency,2) latency_ms, ROUND(avg_loss,2) packet_loss,'
                            '  ROUND(avg_jitter,2) jitter_ms, NULL ttl '
                            'FROM ping_hourly WHERE host_id=? AND hour_ts>? '
                            'ORDER BY hour_ts ASC', (hid,since))
                    self.json([dict(r) for r in rows]); return

                else:
                    # Very old window — use daily rollup
                    if until:
                        rows = db_all(
                            'SELECT day_ts timestamp,'
                            '  CASE WHEN online=total THEN "online" ELSE "offline" END status,'
                            '  ROUND(avg_latency,2) latency_ms, ROUND(avg_loss,2) packet_loss,'
                            '  ROUND(avg_jitter,2) jitter_ms, NULL ttl '
                            'FROM ping_daily WHERE host_id=? AND day_ts>=? AND day_ts<=? '
                            'ORDER BY day_ts ASC', (hid,since,until))
                    else:
                        rows = db_all(
                            'SELECT day_ts timestamp,'
                            '  CASE WHEN online=total THEN "online" ELSE "offline" END status,'
                            '  ROUND(avg_latency,2) latency_ms, ROUND(avg_loss,2) packet_loss,'
                            '  ROUND(avg_jitter,2) jitter_ms, NULL ttl '
                            'FROM ping_daily WHERE host_id=? AND day_ts>? '
                            'ORDER BY day_ts ASC', (hid,since))
                    self.json([dict(r) for r in rows]); return

            if '/latest' in path:
                hid=int(path.split('/')[3])
                n=int(qp('n','120'))
                since_ts=qp('since','')
                if since_ts:
                    rows=db_all('SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl FROM ping_results WHERE host_id=? AND timestamp>? ORDER BY timestamp ASC',(hid,since_ts))
                else:
                    rows=list(reversed(db_all('SELECT timestamp,status,latency_ms,packet_loss,jitter_ms,ttl FROM ping_results WHERE host_id=? ORDER BY timestamp DESC LIMIT ?',(hid,n))))
                self.json([dict(r) for r in rows]); return

            if '/stats' in path:
                hid=int(path.split('/')[3]); hours=int(qp('hours','24'))
                self.json(get_stats(hid,hours)); return

            if '/ports' in path:
                hid=int(path.split('/')[3])
                self.json([dict(r) for r in db_all('SELECT port,status,latency_ms,timestamp FROM port_results WHERE host_id=? ORDER BY timestamp DESC LIMIT 50',(hid,))]); return

            if '/interfaces' in path:
                hid=int(path.split('/')[3])
                self.json([dict(r) for r in db_all(
                    'SELECT if_index,if_name,if_speed_bps,monitored,last_seen FROM interfaces WHERE host_id=? ORDER BY if_index',
                    (hid,))]); return

            if '/bandwidth' in path:
                hid=int(path.split('/')[3])
                if_index=qp('if_index','')
                hours=int(qp('hours','24'))
                since=utc_since_str(hours=hours)
                if not if_index:
                    self.json({'error':'if_index is required'},400); return
                rows=db_all(
                    'SELECT timestamp,in_bps,out_bps FROM bandwidth_results '
                    'WHERE host_id=? AND if_index=? AND timestamp>? ORDER BY timestamp ASC',
                    (hid,int(if_index),since))
                if len(rows) > 800:
                    step=max(1,len(rows)//800)
                    rows=rows[::step]
                self.json([dict(r) for r in rows]); return

            # ALERTS
            if path=='/api/alerts':
                limit=int(qp('limit','100')); unack=qp('unack','0')=='1'
                wh='WHERE a.acknowledged=0' if unack else ''
                self.json([dict(r) for r in db_all(f'SELECT a.*,h.name host_name,h.ip FROM alerts a LEFT JOIN hosts h ON a.host_id=h.id {wh} ORDER BY a.timestamp DESC LIMIT ?',(limit,))]); return
            if path=='/api/alerts/count':
                self.json({'count':db_one('SELECT COUNT(*) FROM alerts WHERE acknowledged=0')[0]}); return
            if path=='/api/alerts/stats':
                since_24h_a = utc_since_str(hours=24); since_7d_a = utc_since_str(days=7)
                self.json({'last_24h':db_one("SELECT COUNT(*) FROM alerts WHERE timestamp>?",(since_24h_a,))[0],'last_7d':db_one("SELECT COUNT(*) FROM alerts WHERE timestamp>?",(since_7d_a,))[0],'critical_unacked':db_one("SELECT COUNT(*) FROM alerts WHERE acknowledged=0 AND severity='critical'")[0]}); return

            # ALERT RULES
            if path=='/api/alert_rules':
                self.json([dict(r) for r in db_all('SELECT r.*,h.name host_name FROM alert_rules r LEFT JOIN hosts h ON r.host_id=h.id ORDER BY r.id')]); return

            # SETTINGS
            if path=='/api/settings':
                self.json({r['key']:r['value'] for r in db_all('SELECT `key`,`value` FROM settings')}); return

            # REPORT
            if path=='/api/report/uptime':
                self.json(get_report(30)); return
            if path=='/api/report/cache-age':
                age = None
                with _report_cache_lock:
                    ts  = _report_cache_ts
                    cnt = len(_report_cache)
                if ts:
                    age = round((datetime.now() - ts).total_seconds())
                self.json({'cached_at': ts.isoformat() if ts else None,
                           'age_secs': age, 'host_count': cnt,
                           'next_refresh_secs': max(0, _CACHE_TTL_SECS - (age or _CACHE_TTL_SECS))}); return
            if path=='/api/report/weekly':
                html = get_weekly_report_html()
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
                self.send_header('Content-Length', len(html.encode()))
                self.cors(); self.end_headers()
                self.wfile.write(html.encode()); return
            if path=='/api/report/monthly':
                html = get_monthly_report_html()
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
                self.send_header('Content-Length', len(html.encode()))
                self.cors(); self.end_headers()
                self.wfile.write(html.encode()); return
            if path=='/api/report/export':
                rows=get_report(30); out=io.StringIO()
                w=csv.DictWriter(out,fieldnames=['name','ip','group','location','uptime_1d','uptime_7d','uptime_30d','avg_latency','min_latency','max_latency','avg_loss','avg_jitter','incidents','downtime_mins','current_status','current_latency'],extrasaction='ignore')
                w.writeheader(); w.writerows(rows)
                fname=f'abayonet_report_{datetime.now().strftime("%Y%m%d")}.csv'
                self.file_dl(out.getvalue(),'text/csv',fname); return
            if path=='/api/report/weekly/csv':
                rows=get_report(7); out=io.StringIO()
                w=csv.DictWriter(out,fieldnames=['name','ip','group','location','uptime_1d','uptime_7d','avg_latency','min_latency','max_latency','avg_loss','incidents','downtime_mins','current_status'],extrasaction='ignore')
                w.writeheader(); w.writerows(rows)
                fname=f'abayonet_weekly_{datetime.now().strftime("%Y%m%d")}.csv'
                self.file_dl(out.getvalue(),'text/csv',fname); return
            if path=='/api/report/monthly/csv':
                rows=get_report(30); out=io.StringIO()
                w=csv.DictWriter(out,fieldnames=['name','ip','group','location','uptime_1d','uptime_7d','uptime_30d','avg_latency','min_latency','max_latency','avg_loss','incidents','downtime_mins','current_status'],extrasaction='ignore')
                w.writeheader(); w.writerows(rows)
                fname=f'abayonet_monthly_{datetime.now().strftime("%Y%m%d")}.csv'
                self.file_dl(out.getvalue(),'text/csv',fname); return

            # HOST EXPORT
            if path=='/api/hosts/export/json':
                fname=f'abayonet_hosts_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                self.file_dl(export_json(),'application/json',fname); return
            if path=='/api/hosts/export/csv':
                fname=f'abayonet_hosts_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
                self.file_dl(export_csv_hosts(),'text/csv',fname); return

            # MULTI-HOST HISTORY (for analysis page)
            if path=='/api/history/multi':
                ids_raw=qp('ids',''); hours=int(qp('hours','24'))
                ids=[int(x) for x in ids_raw.split(',') if x.strip().isdigit()]
                if not ids: self.json([]); return
                since=utc_since_str(hours=hours)
                out={}
                for hid in ids:
                    h=db_one('SELECT name,ip FROM hosts WHERE id=?',(hid,))
                    if not h: continue
                    rows=db_all('SELECT timestamp,status,latency_ms,packet_loss,jitter_ms FROM ping_results WHERE host_id=? AND timestamp>? ORDER BY timestamp ASC',(hid,since))
                    out[hid]={'name':h['name'],'ip':h['ip'],'data':[dict(r) for r in rows]}
                self.json(out); return

            # TRACEROUTE
            if path.startswith('/api/traceroute/'):
                self.json({'output':run_trace(path.split('/')[-1])}); return

            # MAINTENANCE
            if path=='/api/maintenance':
                self.json([dict(r) for r in db_all('SELECT m.*,h.name host_name,h.ip FROM maintenance m LEFT JOIN hosts h ON m.host_id=h.id ORDER BY m.start_time DESC')]); return

            # GROUPS / TAGS
            if path=='/api/groups':
                self.json([r[0] for r in db_all('SELECT DISTINCT group_name FROM hosts ORDER BY group_name')]); return
            if path=='/api/tags':
                tags=set()
                for r in db_all('SELECT tags FROM hosts'):
                    for t in (r[0] or '').split(','):
                        if t.strip(): tags.add(t.strip())
                self.json(sorted(tags)); return

            # USERS (admin)
            if path=='/api/users':
                if not is_admin: self.json({'error':'Admin only'},403); return
                self.json([dict(r) for r in db_all('SELECT id,username,role,full_name,email,created_at,last_login,active FROM users ORDER BY id')]); return
            if path=='/api/users/me':
                u=db_one('SELECT id,username,role,full_name,email,created_at,last_login FROM users WHERE username=?',(sess['username'],))
                self.json(dict(u) if u else {}); return

            self.json({'error':'Not found'},404)
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            pass  # client disconnected — normal, not an error
        except Exception as e:
            log.error(f'GET {path}: {e}')
            try: self.json({'error': 'Internal server error — please try again'}, 500)
            except Exception: pass

    def do_POST(self):
        path=urlparse(self.path).path

        # PUBLIC: Login
        if path=='/api/auth/login':
            try:
                b=self.body(); ip=self.client_address[0]
                u=db_one('SELECT * FROM users WHERE username=? AND active=1',(b.get('username','').strip(),))
                if not u or u['password']!=hashpw(b.get('password','')):
                    log.warning(f'Failed login: {b.get("username")} from {ip}')
                    self.json({'error':'Invalid username or password'},401); return
                token=make_session(u['id'],u['username'],u['role'],ip)
                log.info(f'Login: {u["username"]} ({u["role"]}) from {ip}')
                self.json({'success':True,'token':token,'username':u['username'],'role':u['role'],'full_name':u['full_name']})
            except Exception as e:
                # Log the real error server-side, but never hand raw
                # exception text (e.g. internal DB error strings) back to
                # an unauthenticated client on the login screen.
                log.error(f'Login error: {e}')
                self.json({'error':'Login failed — please try again'},500)
            return

        # PUBLIC: Logout
        if path=='/api/auth/logout':
            token=get_token(self)
            if token: db_exec('DELETE FROM sessions WHERE token=?',(token,))
            self.json({'success':True}); return

        sess=auth(self)
        if not sess: return
        b=self.body(); is_admin=sess['role']=='admin'

        try:
            # ADD HOST
            if path=='/api/hosts':
                if not is_admin: self.json({'error':'Admin only'},403); return
                ip=b.get('ip','').strip()
                if not ip: self.json({'error':'IP required'},400); return
                name=b.get('name','').strip() or resolve(ip) or ip
                snmp_enabled=1 if b.get('snmp_enabled') else 0
                db_exec('INSERT INTO hosts(ip,name,group_name,tags,description,location,alert_email,ping_interval,packet_count,timeout_ms,port_checks,notes,snmp_enabled,snmp_community,snmp_port) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    (ip,name,b.get('group','Default'),b.get('tags',''),b.get('description',''),b.get('location',''),
                     b.get('alert_email',''),max(10,int(b.get('interval',30))),min(20,max(1,int(b.get('packet_count',4)))),
                     int(b.get('timeout_ms',1000)),b.get('port_checks',''),b.get('notes',''),
                     snmp_enabled,b.get('snmp_community','public') or 'public',int(b.get('snmp_port',161) or 161)))
                h=dict(db_one('SELECT * FROM hosts WHERE ip=?',(ip,)))
                start_monitor(h)
                if snmp_enabled:
                    # Discover interfaces now in the background rather than
                    # making the add-host request wait on an SNMP round-trip
                    # to a possibly slow/unreachable device.
                    threading.Thread(target=discover_interfaces, args=(h,), daemon=True).start()
                self.json({'success':True,'host':h}); return

            # TOGGLE HOST
            if '/toggle' in path and path.startswith('/api/hosts/'):
                if not is_admin: self.json({'error':'Admin only'},403); return
                hid=int(path.split('/')[-2])
                enabled=int(b.get('enabled',1))
                if enabled:
                    # Resuming — clear any prior pause reason/who/when so a
                    # stale reason doesn't linger and resurface next pause.
                    db_exec('UPDATE hosts SET enabled=?,pause_reason=NULL,paused_at=NULL,paused_by=NULL WHERE id=?',(enabled,hid))
                else:
                    reason=(b.get('reason') or '').strip()[:500]
                    db_exec('UPDATE hosts SET enabled=?,pause_reason=?,paused_at=?,paused_by=? WHERE id=?',
                            (enabled, reason or None, utc_now_str(), sess['username'], hid))
                # Actually start/stop the live monitor thread to match the new
                # enabled state — previously this only updated the DB flag, so
                # a "disabled" host kept being pinged until the app restarted.
                if enabled:
                    h=db_one('SELECT * FROM hosts WHERE id=?',(hid,))
                    if h: start_monitor(dict(h))
                else:
                    stop_monitor(hid)
                self.json({'success':True}); return

            # BULK DELETE
            if path=='/api/hosts/bulk_delete':
                if not is_admin: self.json({'error':'Admin only'},403); return
                for hid in b.get('ids',[]):
                    stop_monitor(hid)
                    db_exec('DELETE FROM hosts WHERE id=?',(hid,))
                self.json({'success':True}); return

            # IMPORT HOSTS
            if path=='/api/hosts/import':
                if not is_admin: self.json({'error':'Admin only'},403); return
                if not b:
                    self.json({'error':'Empty request body — no data received. Try again.'},400); return
                added,skipped,errors=import_json(b)
                if added==0 and skipped==0 and errors==0:
                    self.json({'error':'No hosts found in file. Check file format.'},400); return
                self.json({'success':True,'added':added,'skipped':skipped,'errors':errors}); return

            # UPDATE HOST (must come after the more specific /api/hosts/* routes above,
            # since this is a catch-all that treats the last path segment as a numeric host id)
            if path.startswith('/api/hosts/') and '/toggle' not in path and '/bulk' not in path and path!='/api/hosts/import':
                if not is_admin: self.json({'error':'Admin only'},403); return
                hid=int(path.split('/')[-1])
                # BUG FIX: `ip` was missing from this UPDATE entirely, so editing
                # a host's IP address never persisted to the database no matter
                # what the form submitted.
                new_ip=b.get('ip','').strip()
                if not new_ip: self.json({'error':'IP required'},400); return
                snmp_enabled=1 if b.get('snmp_enabled') else 0
                try:
                    db_exec('UPDATE hosts SET ip=?,name=?,group_name=?,tags=?,description=?,location=?,alert_email=?,ping_interval=?,packet_count=?,timeout_ms=?,port_checks=?,notes=?,snmp_enabled=?,snmp_community=?,snmp_port=? WHERE id=?',
                        (new_ip,b.get('name',''),b.get('group','Default'),b.get('tags',''),b.get('description',''),b.get('location',''),
                         b.get('alert_email',''),max(10,int(b.get('interval',30))),min(20,max(1,int(b.get('packet_count',4)))),
                         int(b.get('timeout_ms',1000)),b.get('port_checks',''),b.get('notes',''),
                         snmp_enabled,b.get('snmp_community','public') or 'public',int(b.get('snmp_port',161) or 161),hid))
                except pymysql.err.IntegrityError:
                    # `ip` has a UNIQUE constraint — give a clear message instead
                    # of a raw 500 error when the new IP collides with another host.
                    self.json({'error': f'Another host is already using IP {new_ip}'},400); return
                # BUG FIX: the monitor thread for this host was started once at
                # boot with a snapshot of ip/interval/timeout/ports and never
                # re-read the DB, so even successful edits silently had no
                # effect until the whole app was restarted. Restart it now so
                # changes (especially a new IP) apply immediately.
                restart_monitor(hid)
                if snmp_enabled:
                    h=dict(db_one('SELECT * FROM hosts WHERE id=?',(hid,)))
                    threading.Thread(target=discover_interfaces, args=(h,), daemon=True).start()
                self.json({'success':True}); return

            # FORCE-REFRESH REPORT CACHE
            if path=='/api/report/refresh':
                def _do_refresh():
                    global _report_cache, _report_cache_ts
                    result = _build_report_cache()
                    with _report_cache_lock:
                        if result:
                            _report_cache    = result
                            _report_cache_ts = datetime.now()
                threading.Thread(target=_do_refresh, daemon=True, name='report-refresh').start()
                self.json({'ok': True, 'message': 'Cache refresh started in background'}); return

            # PING NOW
            if path.startswith('/api/ping/'):
                self.json(ping(path.split('/')[-1],4)); return

            # REDISCOVER SNMP INTERFACES (on-demand, e.g. after enabling
            # SNMP or changing the community string)
            if path.startswith('/api/host/') and path.endswith('/interfaces/discover'):
                if not is_admin: self.json({'error':'Admin only'},403); return
                hid=int(path.split('/')[3])
                h=db_one('SELECT * FROM hosts WHERE id=?',(hid,))
                if not h: self.json({'error':'Host not found'},404); return
                h=dict(h)
                if not h.get('snmp_enabled'):
                    self.json({'error':'SNMP is not enabled for this host'},400); return
                n=discover_interfaces(h)
                if n==0:
                    self.json({'error':'No response from device — check the community string, port, and that SNMP is reachable from this server'},400); return
                self.json({'success':True,'found':n}); return

            # TOGGLE WHETHER A SPECIFIC INTERFACE IS MONITORED — lets a user
            # exclude interfaces they don't care about (e.g. loopback, an
            # unused port) from polling and from the bandwidth chart, without
            # it reappearing on the next SNMP rediscovery pass (discovery
            # only touches if_name/if_speed_bps/last_seen, never this flag).
            if path.startswith('/api/host/') and '/interfaces/' in path and path.endswith('/toggle'):
                if not is_admin: self.json({'error':'Admin only'},403); return
                parts=path.split('/')
                hid=int(parts[3]); if_index=int(parts[5])
                monitored=1 if b.get('monitored') else 0
                db_exec('UPDATE interfaces SET monitored=? WHERE host_id=? AND if_index=?',(monitored,hid,if_index))
                self.json({'success':True}); return

            # SCAN
            if path=='/api/scan':
                if not is_admin: self.json({'error':'Admin only'},403); return
                self.json(scan_subnet(b.get('subnet','192.168.1.0/24'))); return

            # ACK ALERTS
            if path.startswith('/api/alerts/') and path.endswith('/ack'):
                aid=int(path.split('/')[-2])
                db_exec("UPDATE alerts SET acknowledged=1,ack_by=?,ack_at=? WHERE id=?",(sess['username'],datetime.now().isoformat(),aid))
                self.json({'success':True}); return
            if path=='/api/alerts/ack_all':
                db_exec("UPDATE alerts SET acknowledged=1,ack_by=?,ack_at=?",(sess['username'],datetime.now().isoformat()))
                self.json({'success':True}); return

            # ALERT RULES
            if path=='/api/alert_rules':
                if not is_admin: self.json({'error':'Admin only'},403); return
                db_exec('INSERT INTO alert_rules(name,host_id,`condition`,threshold,duration_mins,notify_email,notify_webhook,cooldown_mins,enabled) VALUES(?,?,?,?,?,?,?,?,1)',
                    (b.get('name','Rule'),int(b.get('host_id',0)),b.get('condition','offline'),
                     float(b.get('threshold',0)),int(b.get('duration_mins',0)),
                     b.get('notify_email',''),b.get('notify_webhook',''),max(1,int(b.get('cooldown_mins',5)))))
                self.json({'success':True}); return
            if path.startswith('/api/alert_rules/') and '/toggle' in path:
                if not is_admin: self.json({'error':'Admin only'},403); return
                rid=int(path.split('/')[-2])
                db_exec('UPDATE alert_rules SET enabled=? WHERE id=?',(int(b.get('enabled',1)),rid))
                self.json({'success':True}); return

            # SETTINGS
            if path=='/api/settings':
                if not is_admin: self.json({'error':'Admin only'},403); return
                for k,v in b.items(): db_exec('INSERT OR REPLACE INTO settings(`key`,`value`) VALUES(?,?)',(k,str(v)))
                self.json({'success':True}); return

            # MAINTENANCE
            if path=='/api/maintenance':
                if not is_admin: self.json({'error':'Admin only'},403); return
                db_exec('INSERT INTO maintenance(host_id,name,start_time,end_time) VALUES(?,?,?,?)',
                    (b.get('host_id'),b.get('name','Maintenance'),b.get('start_time'),b.get('end_time')))
                self.json({'success':True}); return

            # CREATE USER (admin)
            if path=='/api/users':
                if not is_admin: self.json({'error':'Admin only'},403); return
                uname=b.get('username','').strip()
                if not uname: self.json({'error':'Username required'},400); return
                pwd=b.get('password','')
                if len(pwd)<6: self.json({'error':'Password must be at least 6 characters'},400); return
                role=b.get('role','readonly')
                if role not in ('admin','readonly'): self.json({'error':'Role must be admin or readonly'},400); return
                if db_one('SELECT id FROM users WHERE username=?',(uname,)):
                    self.json({'error':'Username already exists'},409); return
                db_exec('INSERT INTO users(username,password,role,full_name,email) VALUES(?,?,?,?,?)',
                    (uname,hashpw(pwd),role,b.get('full_name',''),b.get('email','')))
                log.info(f'User created: {uname} ({role}) by {sess["username"]}')
                self.json({'success':True}); return

            # TOGGLE USER (admin)
            if path.startswith('/api/users/') and path.endswith('/toggle'):
                if not is_admin: self.json({'error':'Admin only'},403); return
                uid=int(path.split('/')[-2])
                db_exec('UPDATE users SET active=? WHERE id=?',(int(b.get('active',1)),uid))
                self.json({'success':True}); return

            # RESET PASSWORD (admin)
            if path.startswith('/api/users/') and path.endswith('/reset_password'):
                if not is_admin: self.json({'error':'Admin only'},403); return
                uid=int(path.split('/')[-2])
                pwd=b.get('password','')
                if len(pwd)<6: self.json({'error':'Password too short'},400); return
                db_exec('UPDATE users SET password=? WHERE id=?',(hashpw(pwd),uid))
                db_exec('DELETE FROM sessions WHERE user_id=?',(uid,))
                self.json({'success':True}); return

            # CHANGE OWN PASSWORD
            if path=='/api/users/change_password':
                old=b.get('old_password',''); new=b.get('new_password','')
                if len(new)<6: self.json({'error':'Password too short'},400); return
                u=db_one('SELECT * FROM users WHERE username=?',(sess['username'],))
                if not u or u['password']!=hashpw(old):
                    self.json({'error':'Current password incorrect'},401); return
                db_exec('UPDATE users SET password=? WHERE username=?',(hashpw(new),sess['username']))
                self.json({'success':True}); return

            self.json({'error':'Not found'},404)
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            pass  # client disconnected — normal, not an error
        except Exception as e:
            log.error(f'POST {path}: {e}')
            try: self.json({'error': 'Internal server error — please try again'}, 500)
            except Exception: pass

    def do_DELETE(self):
        path=urlparse(self.path).path
        # Alerts can be cleared by any logged-in user (same as acknowledging) —
        # admin is only required for destructive host/user/rule operations below.
        sess=auth(self)
        if not sess: return
        is_admin=sess['role']=='admin'
        try:
            if path=='/api/alerts':
                qs=parse_qs(urlparse(self.path).query)
                only_ack=qs.get('acknowledged',[''])[0]=='1'
                if only_ack:
                    n=db_exec('DELETE FROM alerts WHERE acknowledged=1').rowcount
                else:
                    n=db_exec('DELETE FROM alerts').rowcount
                self.json({'success':True,'deleted':n}); return
            if path.startswith('/api/alerts/'):
                aid=int(path.split('/')[-1])
                n=db_exec('DELETE FROM alerts WHERE id=?',(aid,)).rowcount
                self.json({'success':True,'deleted':n}); return

            if not is_admin: self.json({'error':'Admin access required'},403); return
            if path.startswith('/api/hosts/'):
                db_exec('DELETE FROM hosts WHERE id=?',(int(path.split('/')[-1]),)); self.json({'success':True}); return
            if path.startswith('/api/alert_rules/'):
                db_exec('DELETE FROM alert_rules WHERE id=?',(int(path.split('/')[-1]),)); self.json({'success':True}); return
            if path.startswith('/api/maintenance/'):
                db_exec('DELETE FROM maintenance WHERE id=?',(int(path.split('/')[-1]),)); self.json({'success':True}); return
            if path.startswith('/api/users/'):
                uid=int(path.split('/')[-1])
                if uid==1: self.json({'error':'Cannot delete primary admin'},403); return
                db_exec('DELETE FROM users WHERE id=?',(uid,)); self.json({'success':True}); return
            self.json({'error':'Not found'},404)
        except Exception as e:
            log.error(f'DELETE {path}: {e}')
            self.json({'error':'Internal server error — please try again'},500)

_t0=time.time()

def get_local_ip():
    """Get the server's primary LAN IP address for display purposes."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '0.0.0.0'

def read_config_port():
    """Read port from abayonet.cfg if it exists (set by installer)."""
    cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'abayonet.cfg')
    try:
        if os.path.exists(cfg_path):
            import configparser
            c = configparser.ConfigParser()
            c.read(cfg_path)
            p = int(c.get('server', 'port', fallback='8780'))
            if 1024 <= p <= 65535:
                return p
    except Exception:
        pass
    return 8780

def reset_admin():
    """Reset admin password to admin123 — called via --reset-admin flag."""
    init_db()
    new_pw = hashpw('admin123')
    db_exec("UPDATE users SET password=? WHERE username='admin'", (new_pw,))
    print('✅ Admin password reset to: admin123')
    print('   Log in and change it immediately in User Management.')
    close_thread_db()

def main():
    global _email_queue

    # Handle CLI flags
    if '--reset-admin' in sys.argv:
        reset_admin(); return
    if '--version' in sys.argv:
        print(f'AbayoNet Enterprise v{VERSION}'); return

    log.info(f'=== AbayoNet Enterprise v{VERSION} ===')
    init_db(); start_all()

    # Email worker
    _email_queue = queue.Queue(maxsize=100)
    threading.Thread(target=_email_worker, args=(_email_queue,), daemon=True, name='email-worker').start()

    threading.Thread(target=cleanup_loop, daemon=True).start()
    threading.Thread(target=bandwidth_poll_loop, daemon=True, name='bandwidth-poll').start()

    # Port: CLI arg > config file > default 8780
    base_port = 8780
    for arg in sys.argv[1:]:
        if arg.startswith('--port='):
            try: base_port = int(arg.split('=')[1])
            except ValueError: pass
    base_port = read_config_port() if base_port == 8780 else base_port

    PORT = base_port
    for p in [base_port, base_port+1, base_port+2, 9100]:
        try:
            server = ThreadingHTTPServer(('0.0.0.0', p), H)
            server.timeout = 30
            server.socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            PORT = p; break
        except OSError:
            continue

    # Record the port we actually bound so the launcher / service scripts
    # (and anyone debugging) can find it even if it wasn't the default —
    # this file is the source of truth for "what port is AbayoNet really on".
    try:
        with open(os.path.join(_DATA_DIR, 'current_port.txt'), 'w') as f:
            f.write(str(PORT))
    except Exception as e:
        log.warning(f'Could not write current_port.txt: {e}')

    if PORT != base_port:
        log.warning(f'*** Port {base_port} was already in use by another process — '
                     f'AbayoNet fell back to port {PORT} instead. '
                     f'If a dashboard tab or shortcut points at :{base_port}, '
                     f'it will show "connection refused". Use :{PORT} instead, '
                     f'or find and close whatever is already using {base_port} '
                     f'(Windows: netstat -ano | findstr :{base_port}) and restart AbayoNet. ***')

    local_ip = get_local_ip()
    log.info(f'Dashboard → http://127.0.0.1:{PORT}  (local)')
    log.info(f'Network   → http://{local_ip}:{PORT}  (LAN / remote)')
    log.info(f'Listening on all interfaces, port {PORT}')

    # Only open browser when run directly (not as service)
    if '--no-browser' not in sys.argv and '--service' not in sys.argv:
        def _open():
            time.sleep(1.8); webbrowser.open(f'http://127.0.0.1:{PORT}')
        threading.Thread(target=_open, daemon=True).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        global _running
        _running = False
        if _email_queue: _email_queue.put(None)
        log.info('AbayoNet stopped.')

if __name__ == '__main__': main()
