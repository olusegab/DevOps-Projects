# 🌹 MyLover — International Dating App

A production-ready full-stack dating application with real-time chat, audio/video calling, AI features, premium subscriptions, and a full admin dashboard.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
cd mylover
npm install          # root packages (shared)
cd server && npm install   # server packages
cd ../client && npm install --legacy-peer-deps

# 2. Set up environment
cp server/.env.example server/.env
# Edit server/.env with your settings

# 3. Start everything
bash start.sh
```

**Default Admin Login:**
- URL: `http://localhost:3000/admin`
- Email: `admin@mylover.app`
- Password: `Admin@MyLover2024!`

---

## 🏗️ Architecture

```
mylover/
├── server/                 # Node.js + Express + Socket.io backend
│   ├── index.js            # Main server entry point
│   ├── db.js               # Database initialisation & schema
│   ├── db_sqlite_shim.js   # SQLite wrapper (sql.js based)
│   ├── middleware/
│   │   └── auth.js         # JWT authentication middleware
│   ├── routes/
│   │   ├── auth.js         # Register, login, trial status
│   │   ├── users.js        # Profile, discovery with distance calc
│   │   ├── matches.js      # Matches, likes received
│   │   ├── chat.js         # Conversations, messages, AI coach
│   │   ├── subscriptions.js# Plans, payment, cancel
│   │   ├── admin.js        # Full admin dashboard API
│   │   └── upload.js       # Photo upload handling
│   ├── uploads/            # User uploaded photos (auto-created)
│   └── data/               # SQLite database (auto-created)
│       └── mylover.db
│
└── client/                 # React 18 frontend
    └── src/
        ├── App.js           # Router setup
        ├── index.css        # Global design system
        ├── context/
        │   ├── AuthContext.js   # Global auth state
        │   └── SocketContext.js # Real-time socket connection
        ├── utils/
        │   ├── api.js       # All API calls
        │   └── geo.js       # Geolocation & distance helpers
        ├── hooks/
        │   └── useToast.js  # Toast notifications
        ├── components/
        │   └── AppShell.js  # Top/bottom navigation
        └── pages/
            ├── LandingPage.js    # Public homepage
            ├── LoginPage.js
            ├── RegisterPage.js
            ├── SetupProfilePage.js  # 4-step onboarding
            ├── DiscoverPage.js   # Swipe cards with distance
            ├── MatchesPage.js    # Matches + likes received
            ├── ChatPage.js       # Real-time chat + calls + AI
            ├── ProfilePage.js    # Edit profile
            ├── SubscribePage.js  # Premium plans (multi-currency)
            └── AdminPage.js      # Full admin dashboard
```

---

## ✨ Features

### User Features
| Feature | Free (60-day trial) | Premium |
|---------|---------------------|---------|
| Profile & photos | ✅ | ✅ |
| Swipe discovery | ✅ | ✅ |
| Distance display | ✅ | ✅ |
| Geo & country filter | Basic | Advanced |
| Like / Super Like | ✅ (1 super/day) | ✅ (5 super/day) |
| Chat after match | 5 msg/day | Unlimited |
| See who liked you | ❌ | ✅ |
| Read receipts | ❌ | ✅ |
| Voice calls | ❌ | ✅ |
| Video calls | ❌ | ✅ |
| AI Dating Coach | 100 credits | Unlimited |
| AI Icebreakers | 100 credits | Unlimited |
| Profile boost | ❌ | 1/week |

### Admin Features
- **Dashboard:** Real-time stats — users, messages, matches, subscriptions, countries
- **User Management:** View all users, ban/unban, verify, grant premium
- **Message Monitor:** Read all conversations, search content, flag messages
- **AI Scan:** One-click AI scan flags scams, harassment, explicit content
- **Reports:** Review user reports with action workflow
- **Subscriptions:** Full payment history and plan breakdown
- **Audit Logs:** Every admin action is logged

### Technical Features
- **Real-time:** Socket.io for messages, typing, likes, match notifications
- **WebRTC:** Peer-to-peer audio and video calls (STUN via Google)
- **Distance:** Haversine formula — shows exact metres/km between users
- **Gender-based discovery:** Women see men by default, men see women
- **AI:** Claude Sonnet 4.6 — dating coach + content moderation
- **Auth:** JWT (30-day tokens) with bcrypt password hashing

---

## 📍 How Location Works

1. On first visit to Discover, the app asks for browser location permission
2. Location (lat/lng) is saved to the user's profile
3. Every profile card shows distance: `345 m away`, `2.3 km away`, `127 km away`
4. Users can filter by max distance in km
5. Profiles are sorted nearest-first when location is available
6. Location is never shared with other users directly — only distance

---

## 💳 Payment Integration

Currently uses **manual payment reference** flow. To integrate real payments:

### Paystack (Nigeria — Recommended)
```bash
npm install paystack
```
```javascript
// In server/routes/subscriptions.js
const paystack = require('paystack')(process.env.PAYSTACK_SECRET_KEY);
const verify = await paystack.transaction.verify(reference);
if (verify.data.status === 'success') { /* activate subscription */ }
```

### Stripe (International)
```bash
npm install stripe
```
```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const session = await stripe.checkout.sessions.create({ ... });
```

### Flutterwave (Pan-Africa)
```bash
npm install flutterwave-node-v3
```

---

## 🌍 Deployment

### Option 1: VPS (Recommended — DigitalOcean, Linode, Hetzner)

```bash
# On your server
git clone your-repo mylover
cd mylover
npm install
cd server && npm install

# Build React app
cd ../client && npm run build

# Set production env
cd ../server
cp .env.example .env
nano .env  # Set JWT_SECRET, CLIENT_URL, etc.

# Install PM2 for process management
npm install -g pm2
pm2 start index.js --name mylover-server
pm2 save && pm2 startup
```

### Option 2: Railway / Render (Easy)
1. Push to GitHub
2. Connect repo to Railway or Render
3. Set environment variables in dashboard
4. Deploy — auto-detects Node.js

### Option 3: Heroku
```bash
# Add Procfile to server/
echo "web: node index.js" > server/Procfile
heroku create mylover-app
git push heroku main
```

### nginx Reverse Proxy (Production)
```nginx
server {
    listen 80;
    server_name mylover.app www.mylover.app;

    location /api { proxy_pass http://localhost:5000; proxy_http_version 1.1; }
    location /uploads { proxy_pass http://localhost:5000; }
    location /socket.io { proxy_pass http://localhost:5000; proxy_http_version 1.1; proxy_set_header Upgrade $http_upgrade; proxy_set_header Connection "upgrade"; }
    location / { root /var/www/mylover/client/build; try_files $uri /index.html; }
}
```

---

## 🔒 Production Database Upgrade

The current `sql.js` SQLite works perfectly for development and low-medium traffic. For production scale:

```bash
npm install pg  # PostgreSQL
```

Replace `db_sqlite_shim.js` with a `pg` Pool connection. All queries use the same `db.prepare().get/all/run()` API — minimal changes needed.

---

## 📱 Mobile App (Future)

To add iOS/Android:
- **React Native** — reuse all API and socket logic, rebuild UI components
- **Capacitor** — wrap the React web app as a native app (easiest path)
- **Expo** — quick React Native setup with camera, push notifications

---

## 🧩 Adding Payment Gateways

See `server/routes/subscriptions.js` → `POST /subscribe` route. Replace the manual reference flow with:
1. Create payment intent on server
2. Return checkout URL/session to client  
3. Redirect user to payment page
4. Handle webhook callback to activate subscription

---

## 📞 Support

- Admin email: admin@mylover.app
- Change default admin password immediately after first login!
- For issues: check `server/data/` for the SQLite file and `server/uploads/` for photos

---

*Built with Node.js, Express, Socket.io, React 18, sql.js, and Claude AI* 🌹
