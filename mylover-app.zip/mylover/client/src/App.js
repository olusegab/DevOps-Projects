import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import './index.css';

// Pages
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DiscoverPage from './pages/DiscoverPage';
import MatchesPage from './pages/MatchesPage';
import ChatPage from './pages/ChatPage';
import ProfilePage from './pages/ProfilePage';
import SubscribePage from './pages/SubscribePage';
import AdminPage from './pages/AdminPage';
import SetupProfilePage from './pages/SetupProfilePage';

// Layout
import AppShell from './components/AppShell';

function PrivateRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  return user ? children : <Navigate to="/login" replace />;
}

function AdminRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (!user.is_admin) return <Navigate to="/discover" replace />;
  return children;
}

function PublicRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  return user ? <Navigate to="/discover" replace /> : children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<PublicRoute><LandingPage /></PublicRoute>} />
      <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><RegisterPage /></PublicRoute>} />

      <Route path="/setup" element={<PrivateRoute><SetupProfilePage /></PrivateRoute>} />

      <Route path="/discover" element={<PrivateRoute><AppShell><DiscoverPage /></AppShell></PrivateRoute>} />
      <Route path="/matches" element={<PrivateRoute><AppShell><MatchesPage /></AppShell></PrivateRoute>} />
      <Route path="/chat/:conversationId?" element={<PrivateRoute><AppShell><ChatPage /></AppShell></PrivateRoute>} />
      <Route path="/profile" element={<PrivateRoute><AppShell><ProfilePage /></AppShell></PrivateRoute>} />
      <Route path="/subscribe" element={<PrivateRoute><AppShell><SubscribePage /></AppShell></PrivateRoute>} />

      <Route path="/admin/*" element={<AdminRoute><AdminPage /></AdminRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SocketProvider>
          <AppRoutes />
        </SocketProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
