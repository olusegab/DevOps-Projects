// utils/api.js
const BASE = process.env.REACT_APP_API_URL || '';

function getToken() {
  return localStorage.getItem('ml_token');
}

async function request(method, path, body, isFormData = false) {
  const headers = {};
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  if (!isFormData) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${BASE}/api${path}`, {
    method,
    headers,
    body: body ? (isFormData ? body : JSON.stringify(body)) : undefined
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
  put: (path, body) => request('PUT', path, body),
  delete: (path, body) => request('DELETE', path, body),
  postForm: (path, formData) => request('POST', path, formData, true),

  // Auth
  register: (data) => api.post('/auth/register', data),
  login: (email, password) => api.post('/auth/login', { email, password }),
  getMe: () => api.get('/auth/me'),
  getTrialStatus: () => api.get('/auth/trial-status'),

  // Users
  updateProfile: (data) => api.put('/users/profile', data),
  discover: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return api.get(`/users/discover?${q}`);
  },
  getUser: (id) => api.get(`/users/${id}`),
  searchUsers: (q) => api.get(`/users/search?q=${encodeURIComponent(q)}`),
  blockUser: (id) => api.post(`/users/${id}/block`),
  reportUser: (id, data) => api.post(`/users/${id}/report`, data),

  // Matches
  getMatches: () => api.get('/matches'),
  getLikesReceived: () => api.get('/matches/likes-received'),

  // Chat
  getConversations: () => api.get('/chat/conversations'),
  getMessages: (convId, page = 1) => api.get(`/chat/conversations/${convId}/messages?page=${page}`),
  aiCoach: (message, history) => api.post('/chat/ai-coach', { message, conversationHistory: history }),
  aiIcebreaker: (targetUserId) => api.post('/chat/ai-icebreaker', { targetUserId }),

  // Subscriptions
  getPlans: (currency) => api.get(`/subscriptions/plans?currency=${currency || 'USD'}`),
  getCurrentSub: () => api.get('/subscriptions/current'),
  subscribe: (plan, currency, paymentRef) => api.post('/subscriptions/subscribe', { plan, currency, paymentRef }),
  cancelSub: () => api.post('/subscriptions/cancel'),

  // Upload
  uploadProfilePhoto: (file) => {
    const fd = new FormData();
    fd.append('photo', file);
    return api.postForm('/upload/profile-photo', fd);
  },
  uploadPhotos: (files) => {
    const fd = new FormData();
    files.forEach(f => fd.append('photos', f));
    return api.postForm('/upload/photos', fd);
  },

  // Admin
  admin: {
    getStats: () => api.get('/admin/stats'),
    getUsers: (params = {}) => { const q = new URLSearchParams(params).toString(); return api.get(`/admin/users?${q}`); },
    getUser: (id) => api.get(`/admin/users/${id}`),
    banUser: (id, reason) => api.post(`/admin/users/${id}/ban`, { reason }),
    unbanUser: (id) => api.post(`/admin/users/${id}/unban`),
    verifyUser: (id) => api.post(`/admin/users/${id}/verify`),
    grantPremium: (id, days) => api.post(`/admin/users/${id}/grant-premium`, { days }),
    getMessages: (params = {}) => { const q = new URLSearchParams(params).toString(); return api.get(`/admin/messages?${q}`); },
    flagMessage: (id, reason) => api.post(`/admin/messages/${id}/flag`, { reason }),
    unflagMessage: (id) => api.post(`/admin/messages/${id}/unflag`),
    aiScanMessages: (ids) => api.post('/admin/messages/ai-scan', { messageIds: ids }),
    getReports: (status) => api.get(`/admin/reports?status=${status || 'pending'}`),
    resolveReport: (id, data) => api.post(`/admin/reports/${id}/resolve`, data),
    getLogs: () => api.get('/admin/logs'),
    getSubscriptions: () => api.get('/admin/subscriptions'),
  }
};

export default api;
