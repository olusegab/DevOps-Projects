// utils/geo.js

/**
 * Haversine formula — returns distance in metres between two lat/lng points.
 */
export function distanceMetres(lat1, lng1, lat2, lng2) {
  const R = 6371000; // Earth radius in metres
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Format distance human-readable: metres up to 999m, then km.
 */
export function formatDistance(metres) {
  if (!metres && metres !== 0) return null;
  if (metres < 1000) return `${Math.round(metres)} m away`;
  const km = metres / 1000;
  return km < 100 ? `${km.toFixed(1)} km away` : `${Math.round(km)} km away`;
}

/**
 * Ask browser for current position. Returns { lat, lng } or throws.
 */
export function getCurrentPosition(options = {}) {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(err),
      { timeout: 10000, enableHighAccuracy: false, ...options }
    );
  });
}

/**
 * Persist location to server.
 */
export async function saveLocation(lat, lng) {
  const token = localStorage.getItem('ml_token');
  if (!token) return;
  try {
    await fetch('/api/users/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ lat, lng })
    });
  } catch (e) {
    // silent — location is best-effort
  }
}
