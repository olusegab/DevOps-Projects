import { useState, useCallback } from 'react';

export function useToast() {
  const [toast, setToast] = useState(null);

  const showToast = useCallback((message, type = 'default', duration = 3000) => {
    setToast({ message, type });
    setTimeout(() => setToast(null), duration);
  }, []);

  const ToastComponent = toast ? (
    <div className={`toast toast-${toast.type}`}>{toast.message}</div>
  ) : null;

  return { showToast, ToastComponent };
}
