import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';

const HeartIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
);
const SearchIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
);
const ChatIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>
);
const UserIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
);
const StarIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
);

export default function AppShell({ children }) {
  const { user, logout } = useAuth();
  const { connected } = useSocket();
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { path: '/discover', icon: <SearchIcon />, label: 'Discover' },
    { path: '/matches', icon: <HeartIcon />, label: 'Matches' },
    { path: '/chat', icon: <ChatIcon />, label: 'Messages' },
    { path: '/subscribe', icon: <StarIcon />, label: 'Premium' },
    { path: '/profile', icon: <UserIcon />, label: 'Profile' },
  ];

  const isActive = (path) => location.pathname.startsWith(path);

  const avatarLetter = user?.display_name?.[0]?.toUpperCase() || '?';
  const photoUrl = user?.profile_photo;

  return (
    <>
      {/* Desktop top navbar */}
      <nav className="navbar">
        <Link to="/discover" className="navbar-brand">My<span>Lover</span> 🌹</Link>

        <div className="navbar-nav">
          {navItems.map(item => (
            <Link key={item.path} to={item.path} className={`nav-item ${isActive(item.path) ? 'active' : ''}`}>
              {item.icon}
              {item.label}
            </Link>
          ))}
        </div>

        <div className="navbar-end">
          <span style={{ fontSize: '0.75rem', color: connected ? '#22c55e' : '#ef4444', fontWeight: 600 }}>
            {connected ? '● Live' : '○ Offline'}
          </span>
          {user?.is_admin && (
            <Link to="/admin" className="btn btn-secondary btn-sm">Admin</Link>
          )}
          <div className="relative">
            <div
              onClick={() => setMenuOpen(!menuOpen)}
              style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}
            >
              {photoUrl
                ? <img src={photoUrl} alt="" className="avatar avatar-sm" style={{ width: 36, height: 36 }} />
                : <div className="avatar avatar-sm">{avatarLetter}</div>
              }
            </div>
            {menuOpen && (
              <div style={{
                position: 'absolute', right: 0, top: '110%', background: 'white',
                border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)',
                boxShadow: 'var(--shadow-lg)', minWidth: 160, zIndex: 200, overflow: 'hidden'
              }}>
                <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{user?.display_name}</div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--gray)' }}>{user?.email}</div>
                </div>
                <button onClick={() => { navigate('/profile'); setMenuOpen(false); }}
                  style={{ display: 'block', width: '100%', padding: '11px 16px', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', fontSize: '0.9rem' }}>
                  My Profile
                </button>
                <button onClick={() => { navigate('/subscribe'); setMenuOpen(false); }}
                  style={{ display: 'block', width: '100%', padding: '11px 16px', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', fontSize: '0.9rem', color: 'var(--rose)' }}>
                  ⭐ Upgrade to Premium
                </button>
                <button onClick={logout}
                  style={{ display: 'block', width: '100%', padding: '11px 16px', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', fontSize: '0.9rem', color: '#dc2626' }}>
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main className="page-content">
        {children}
      </main>

      {/* Mobile bottom navigation */}
      <nav className="bottom-nav">
        {navItems.map(item => (
          <button key={item.path} className={`bottom-nav-item ${isActive(item.path) ? 'active' : ''}`}
            onClick={() => navigate(item.path)}>
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </>
  );
}
