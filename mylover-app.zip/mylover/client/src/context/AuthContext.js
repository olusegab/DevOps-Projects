import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [trialStatus, setTrialStatus] = useState(null);

  const loadUser = useCallback(async () => {
    const token = localStorage.getItem('ml_token');
    if (!token) { setLoading(false); return; }
    try {
      const { user } = await api.getMe();
      setUser(user);
      const trial = await api.getTrialStatus();
      setTrialStatus(trial);
    } catch {
      localStorage.removeItem('ml_token');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = async (email, password) => {
    const { token, user } = await api.login(email, password);
    localStorage.setItem('ml_token', token);
    setUser(user);
    const trial = await api.getTrialStatus();
    setTrialStatus(trial);
    return user;
  };

  const register = async (data) => {
    const { token, user } = await api.register(data);
    localStorage.setItem('ml_token', token);
    setUser(user);
    setTrialStatus({ isInFreeTrial: true, freeTrialDaysLeft: 60, isPremium: false });
    return user;
  };

  const logout = () => {
    localStorage.removeItem('ml_token');
    setUser(null);
    setTrialStatus(null);
    window.location.href = '/';
  };

  const refreshUser = async () => {
    const { user } = await api.getMe();
    setUser(user);
    return user;
  };

  const isPremium = trialStatus?.isPremium || trialStatus?.isInFreeTrial || user?.is_premium;

  return (
    <AuthContext.Provider value={{ user, loading, trialStatus, isPremium, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
