// LandingPage.js
import React from 'react';
import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #1a0a0f 0%, #2d1520 50%, #1a0a0f 100%)' }}>
      {/* Nav */}
      <nav style={{ padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.8rem', color: 'var(--rose)', fontWeight: 700 }}>
          MyLover <span style={{ color: 'var(--gold)' }}>🌹</span>
        </span>
        <div style={{ display: 'flex', gap: 12 }}>
          <Link to="/login" className="btn btn-ghost" style={{ color: 'white', borderColor: 'rgba(255,255,255,0.3)' }}>Sign In</Link>
          <Link to="/register" className="btn btn-primary">Join Free</Link>
        </div>
      </nav>

      {/* Hero */}
      <div style={{ textAlign: 'center', padding: '80px 20px 60px', maxWidth: 700, margin: '0 auto' }}>
        <div style={{ display: 'inline-block', background: 'rgba(233,30,99,0.15)', borderRadius: 50, padding: '8px 20px', marginBottom: 24, color: 'var(--rose-soft)', fontSize: '0.88rem', fontWeight: 600 }}>
          🌍 International Dating App
        </div>
        <h1 style={{ color: 'white', fontSize: 'clamp(2.2rem, 6vw, 3.5rem)', lineHeight: 1.15, marginBottom: 24, fontFamily: 'Playfair Display, serif' }}>
          Find Love<br /><span style={{ color: 'var(--rose)' }}>Across Borders</span>
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '1.1rem', lineHeight: 1.7, marginBottom: 40, maxWidth: 520, margin: '0 auto 40px' }}>
          Connect with real people worldwide. Smart matching, real-time chat, video calls, and AI-powered dating coach — all in one app.
        </p>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link to="/register" className="btn btn-primary btn-lg">Start for Free 💕</Link>
          <Link to="/login" className="btn btn-ghost btn-lg" style={{ color: 'white', borderColor: 'rgba(255,255,255,0.4)' }}>Sign In</Link>
        </div>
        <p style={{ color: 'rgba(255,255,255,0.4)', marginTop: 20, fontSize: '0.85rem' }}>
          ✨ Free for your first 60 days · No credit card required
        </p>
      </div>

      {/* Features */}
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '0 20px 80px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 24 }}>
        {[
          { icon: '🌍', title: 'Global Matching', desc: 'Meet people from 190+ countries. Filter by distance, country, age, and interests.' },
          { icon: '💬', title: 'Real-Time Chat', desc: 'Instant messaging, emoji, read receipts, and typing indicators.' },
          { icon: '📞', title: 'Voice & Video Calls', desc: 'Crystal-clear audio and video calls directly within the app — no third-party needed.' },
          { icon: '🤖', title: 'AI Dating Coach', desc: 'Get personalized advice, icebreakers, and message suggestions powered by AI.' },
          { icon: '📍', title: 'Location-Based', desc: 'See exactly how far away each person is — from metres to thousands of kilometres.' },
          { icon: '🔒', title: 'Safe & Monitored', desc: 'AI content moderation, reporting tools, and a dedicated admin team keep you safe.' },
        ].map(f => (
          <div key={f.title} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 'var(--radius)', padding: 28, backdropFilter: 'blur(10px)' }}>
            <div style={{ fontSize: '2.2rem', marginBottom: 12 }}>{f.icon}</div>
            <h3 style={{ color: 'white', marginBottom: 8 }}>{f.title}</h3>
            <p style={{ color: 'rgba(255,255,255,0.6)', lineHeight: 1.6, fontSize: '0.9rem' }}>{f.desc}</p>
          </div>
        ))}
      </div>

      {/* CTA */}
      <div style={{ background: 'rgba(233,30,99,0.1)', padding: '60px 20px', textAlign: 'center', borderTop: '1px solid rgba(233,30,99,0.2)' }}>
        <h2 style={{ color: 'white', marginBottom: 16, fontFamily: 'Playfair Display, serif' }}>Ready to Find Your Match?</h2>
        <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: 28 }}>Join thousands of members finding love every day.</p>
        <Link to="/register" className="btn btn-primary btn-lg">Create Free Account</Link>
      </div>

      <footer style={{ padding: '20px 40px', borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: '0.82rem' }}>© 2024 MyLover. All rights reserved.</span>
        <div style={{ display: 'flex', gap: 20, fontSize: '0.82rem' }}>
          {['Privacy', 'Terms', 'Safety', 'Help'].map(l => (
            <span key={l} style={{ color: 'rgba(255,255,255,0.4)', cursor: 'pointer' }}>{l}</span>
          ))}
        </div>
      </footer>
    </div>
  );
}
