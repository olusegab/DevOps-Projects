import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const COUNTRIES = ['Nigeria','United Kingdom','United States','Ghana','Kenya','South Africa','Canada','Australia','Germany','France','India','Brazil','UAE','South Africa','Egypt','Ethiopia','Tanzania','Uganda','Rwanda'];

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '', displayName: '', gender: '', dateOfBirth: '', country: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password.length < 8) { setError('Password must be at least 8 characters'); return; }
    setLoading(true);
    try {
      await register(form);
      navigate('/setup');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #1a0a0f, #2d1520)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 480 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <Link to="/" style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', color: 'var(--rose)', textDecoration: 'none', fontWeight: 700 }}>
            MyLover <span style={{ color: 'var(--gold)' }}>🌹</span>
          </Link>
          <p style={{ color: 'rgba(255,255,255,0.5)', marginTop: 8 }}>Find your perfect match</p>
        </div>
        <div className="card" style={{ padding: 32 }}>
          <h2 style={{ marginBottom: 4, textAlign: 'center' }}>Create Account</h2>
          <p style={{ textAlign: 'center', color: 'var(--gray)', fontSize: '0.88rem', marginBottom: 24 }}>Free for your first 60 days ✨</p>
          {error && <div style={{ background: '#fef2f2', color: '#dc2626', padding: '12px 16px', borderRadius: 'var(--radius-xs)', marginBottom: 20, fontSize: '0.88rem' }}>{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Display Name</label>
              <input type="text" className="form-input" placeholder="Your name" value={form.displayName} onChange={e => setForm(f => ({ ...f, displayName: e.target.value }))} required />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" className="form-input" placeholder="you@example.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className="form-input" placeholder="Min. 8 characters" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
            </div>
            <div className="grid-2">
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Gender</label>
                <select className="form-input form-select" value={form.gender} onChange={e => setForm(f => ({ ...f, gender: e.target.value }))} required>
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="non-binary">Non-binary</option>
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Date of Birth</label>
                <input type="date" className="form-input" value={form.dateOfBirth} onChange={e => setForm(f => ({ ...f, dateOfBirth: e.target.value }))} max={new Date(Date.now() - 18*365*24*60*60*1000).toISOString().split('T')[0]} required />
              </div>
            </div>
            <div className="form-group mt-4">
              <label className="form-label">Country</label>
              <select className="form-input form-select" value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))} required>
                <option value="">Select country</option>
                {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div style={{ background: 'var(--rose-light)', borderRadius: 'var(--radius-xs)', padding: '12px 16px', marginBottom: 20, fontSize: '0.82rem', color: 'var(--rose)' }}>
              ✅ By creating an account, you agree to our Terms of Service and are 18+ years old.
            </div>
            <button type="submit" className="btn btn-primary btn-block btn-lg" disabled={loading}>
              {loading ? <span className="spinner spinner-sm" /> : 'Create Free Account 💕'}
            </button>
          </form>
          <p style={{ textAlign: 'center', marginTop: 20, fontSize: '0.88rem', color: 'var(--gray)' }}>
            Already have an account? <Link to="/login">Sign In</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
