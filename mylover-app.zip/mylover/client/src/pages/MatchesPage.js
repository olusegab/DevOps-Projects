import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';

export default function MatchesPage() {
  const { isPremium, trialStatus } = useAuth();
  const { emit, on } = useSocket();
  const navigate = useNavigate();
  const [tab, setTab] = useState('matches');
  const [matches, setMatches] = useState([]);
  const [likes, setLikes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newMatch, setNewMatch] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const { matches: m } = await api.getMatches();
        setMatches(m);
        if (isPremium) {
          const { likes: l } = await api.getLikesReceived();
          setLikes(l);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [isPremium]);

  // Socket: new match
  useEffect(() => {
    if (!on) return;
    const unsub = on('its_a_match', ({ userId, conversationId, matchId }) => {
      setNewMatch({ userId, conversationId });
      setMatches(prev => [{ matchId, conversationId, matchedAt: new Date().toISOString(), user: { id: userId } }, ...prev]);
    });
    const unsubLike = on('new_like', ({ fromUserId, isSuper }) => {
      setLikes(prev => [{ from_user_id: fromUserId, is_super: isSuper, created_at: new Date().toISOString() }, ...prev]);
    });
    return () => { unsub(); unsubLike(); };
  }, [on]);

  const likeBack = (userId) => {
    emit('send_like', { targetUserId: userId, isSuper: false });
  };

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="container" style={{ maxWidth: 680, paddingTop: 16 }}>
      <h2 style={{ marginBottom: 16 }}>💕 Matches & Likes</h2>

      <div className="tabs" style={{ marginBottom: 24 }}>
        <button className={`tab ${tab === 'matches' ? 'active' : ''}`} onClick={() => setTab('matches')}>
          Matches ({matches.length})
        </button>
        <button className={`tab ${tab === 'likes' ? 'active' : ''}`} onClick={() => setTab('likes')}>
          Liked Me {isPremium ? `(${likes.length})` : '🔒'}
        </button>
      </div>

      {/* Matches Tab */}
      {tab === 'matches' && (
        <>
          {matches.length === 0 ? (
            <div className="card text-center" style={{ padding: 48 }}>
              <div style={{ fontSize: '3rem', marginBottom: 16 }}>💔</div>
              <h3>No matches yet</h3>
              <p style={{ marginTop: 8 }}>Start swiping to find your perfect match!</p>
              <button className="btn btn-primary mt-4" onClick={() => navigate('/discover')}>Start Discovering</button>
            </div>
          ) : (
            <div className="grid-3" style={{ gap: 16 }}>
              {matches.map(m => (
                <div key={m.matchId} className="card card-hover" style={{ padding: 0, overflow: 'hidden', cursor: 'pointer' }}
                  onClick={() => m.conversationId && navigate(`/chat/${m.conversationId}`)}>
                  {m.user?.photo
                    ? <img src={m.user.photo} alt="" style={{ width: '100%', aspectRatio: '1', objectFit: 'cover' }} />
                    : <div style={{ width: '100%', aspectRatio: '1', background: 'linear-gradient(135deg, var(--rose-light), var(--purple-light))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem' }}>💕</div>
                  }
                  <div style={{ padding: '12px 14px' }}>
                    <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>{m.user?.name || 'Match'}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--gray)', marginTop: 2 }}>
                      {m.lastMessage ? m.lastMessage : '✨ New match!'}
                    </div>
                    <button className="btn btn-primary btn-sm btn-block mt-2" style={{ fontSize: '0.8rem' }}>
                      💬 Chat
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* Likes Tab */}
      {tab === 'likes' && (
        <>
          {!isPremium && !trialStatus?.isInFreeTrial ? (
            <div className="premium-banner" style={{ textAlign: 'center', padding: 40 }}>
              <div style={{ fontSize: '3rem', marginBottom: 16 }}>⭐</div>
              <h3>See Who Liked You</h3>
              <p style={{ marginTop: 8, marginBottom: 24 }}>Upgrade to Premium to see all the people who already liked your profile.</p>
              <button className="btn btn-gold" onClick={() => navigate('/subscribe')}>Upgrade to Premium</button>
            </div>
          ) : likes.length === 0 ? (
            <div className="card text-center" style={{ padding: 48 }}>
              <div style={{ fontSize: '3rem', marginBottom: 16 }}>👀</div>
              <h3>No likes yet</h3>
              <p>Make sure your profile has a great photo and bio!</p>
            </div>
          ) : (
            <div className="grid-3" style={{ gap: 16 }}>
              {likes.map((like, i) => (
                <div key={i} className="card" style={{ padding: 0, overflow: 'hidden' }}>
                  {like.profile_photo
                    ? <img src={like.profile_photo} alt="" style={{ width: '100%', aspectRatio: '1', objectFit: 'cover' }} />
                    : <div style={{ width: '100%', aspectRatio: '1', background: 'linear-gradient(135deg, var(--rose-light), var(--gold-light))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem' }}>{like.is_super ? '⭐' : '❤️'}</div>
                  }
                  <div style={{ padding: '12px 14px' }}>
                    <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>{like.display_name || 'Someone'}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--gray)', marginTop: 2 }}>
                      {like.city && `${like.city}, `}{like.country} · {like.age && `${like.age}y`}
                    </div>
                    {like.is_super && <div style={{ fontSize: '0.78rem', color: 'var(--gold)', fontWeight: 600, marginTop: 2 }}>⭐ Super Like!</div>}
                    <button className="btn btn-primary btn-sm btn-block mt-2" style={{ fontSize: '0.8rem' }}
                      onClick={() => likeBack(like.from_user_id)}>
                      ♥ Like Back
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
