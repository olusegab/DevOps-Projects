import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';

const CURRENCIES = [
  { code: 'USD', symbol: '$', flag: '🇺🇸' },
  { code: 'NGN', symbol: '₦', flag: '🇳🇬' },
  { code: 'GBP', symbol: '£', flag: '🇬🇧' },
  { code: 'EUR', symbol: '€', flag: '🇪🇺' },
  { code: 'KES', symbol: 'KSh', flag: '🇰🇪' },
];

const FEATURES = [
  { icon: '💬', free: '5 msg/day after trial', premium: 'Unlimited messages' },
  { icon: '👀', free: 'Hidden', premium: 'See who liked you' },
  { icon: '🔍', free: 'Basic filters', premium: 'Advanced filters (distance, country, age)' },
  { icon: '⭐', free: '1 super like/day', premium: '5 super likes/day' },
  { icon: '✓✓', free: 'No read receipts', premium: 'Read receipts' },
  { icon: '🚀', free: 'Normal ranking', premium: 'Priority in discovery' },
  { icon: '🤖', free: '100 AI credits', premium: 'Unlimited AI coach' },
  { icon: '📞', free: '❌', premium: 'Voice & video calls' },
  { icon: '🌍', free: '❌', premium: 'Profile boost (1/week)' },
];

export default function SubscribePage() {
  const { trialStatus, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [currency, setCurrency] = useState('NGN');
  const [selected, setSelected] = useState('monthly');
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState(false);
  const [payRef, setPayRef] = useState('');
  const [showPayModal, setShowPayModal] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    api.getPlans(currency).then(({ plans: p }) => { setPlans(p); setLoading(false); }).catch(() => setLoading(false));
  }, [currency]);

  const handleSubscribe = async () => {
    if (!payRef.trim()) { alert('Please enter your payment reference'); return; }
    setSubscribing(true);
    try {
      await api.subscribe(selected, currency, payRef);
      await refreshUser();
      setSuccess(true);
      setShowPayModal(false);
    } catch (e) {
      alert(e.message);
    } finally {
      setSubscribing(false);
    }
  };

  const selectedPlan = plans.find(p => p.id === selected);
  const cur = CURRENCIES.find(c => c.code === currency);

  if (success) return (
    <div className="container-sm" style={{ paddingTop: 60, textAlign: 'center' }}>
      <div style={{ fontSize: '4rem', marginBottom: 16 }}>🎉</div>
      <h2>Welcome to Premium!</h2>
      <p style={{ marginTop: 8, marginBottom: 28 }}>Your subscription is now active. Enjoy unlimited access to all features.</p>
      <button className="btn btn-primary btn-lg" onClick={() => navigate('/discover')}>Start Discovering 💕</button>
    </div>
  );

  return (
    <div className="container-md" style={{ paddingTop: 16 }}>
      <div style={{ textAlign: 'center', marginBottom: 32 }}>
        <h2>⭐ Upgrade to Premium</h2>
        {trialStatus?.isInFreeTrial && (
          <div style={{ marginTop: 8 }}>
            <span className="badge badge-green">🎉 Free Trial Active — {trialStatus.freeTrialDaysLeft} days left</span>
          </div>
        )}
        <p style={{ marginTop: 12, color: 'var(--gray)' }}>Unlock unlimited matches, calls, and AI features</p>
      </div>

      {/* Currency Selector */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 28, flexWrap: 'wrap' }}>
        {CURRENCIES.map(c => (
          <button key={c.code} onClick={() => setCurrency(c.code)}
            className={currency === c.code ? 'btn btn-primary btn-sm' : 'btn btn-ghost btn-sm'}>
            {c.flag} {c.code}
          </button>
        ))}
      </div>

      {/* Plans */}
      {loading ? <div className="spinner" style={{ margin: '40px auto' }} /> : (
        <div className="grid-3" style={{ gap: 16, marginBottom: 32 }}>
          {plans.map(plan => (
            <div key={plan.id} onClick={() => setSelected(plan.id)}
              style={{
                border: `2px solid ${selected === plan.id ? 'var(--rose)' : plan.popular ? 'var(--gold)' : 'var(--border)'}`,
                borderRadius: 'var(--radius)', padding: 24, cursor: 'pointer', background: 'white',
                position: 'relative', transition: 'all 0.2s',
                transform: selected === plan.id ? 'translateY(-4px)' : 'none',
                boxShadow: selected === plan.id ? 'var(--shadow)' : 'none'
              }}>
              {plan.popular && (
                <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: 'var(--gold)', color: 'white', padding: '3px 14px', borderRadius: 50, fontSize: '0.75rem', fontWeight: 700, whiteSpace: 'nowrap' }}>
                  MOST POPULAR
                </div>
              )}
              {selected === plan.id && (
                <div style={{ position: 'absolute', top: 12, right: 12, width: 22, height: 22, borderRadius: '50%', background: 'var(--rose)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: 700 }}>✓</div>
              )}
              <div style={{ fontWeight: 700, fontSize: '1.05rem', marginBottom: 4, textTransform: 'capitalize' }}>{plan.id}</div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--rose)', lineHeight: 1 }}>
                {cur?.symbol}{plan.price.toLocaleString()}
              </div>
              <div style={{ fontSize: '0.78rem', color: 'var(--gray)', marginTop: 4 }}>
                per {plan.id === 'yearly' ? 'year' : plan.id === 'monthly' ? 'month' : 'week'}
              </div>
              {plan.id === 'yearly' && (
                <div style={{ marginTop: 8, background: 'var(--gold-light)', borderRadius: 'var(--radius-xs)', padding: '4px 10px', fontSize: '0.78rem', color: '#b45309', fontWeight: 600, display: 'inline-block' }}>
                  Save ~44% vs monthly
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Subscribe Button */}
      <div style={{ textAlign: 'center', marginBottom: 32 }}>
        <button className="btn btn-primary btn-lg" onClick={() => setShowPayModal(true)} disabled={!selectedPlan}>
          Get {selectedPlan?.name} — {cur?.symbol}{selectedPlan?.price?.toLocaleString()} {currency}
        </button>
        <p style={{ marginTop: 12, fontSize: '0.8rem', color: 'var(--gray)' }}>
          Cancel anytime · Secure payment
        </p>
      </div>

      {/* Feature Comparison Table */}
      <div className="card">
        <h3 style={{ marginBottom: 20 }}>Free vs Premium</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.88rem' }}>
          <thead>
            <tr>
              <th style={{ textAlign: 'left', padding: '10px 0', borderBottom: '2px solid var(--border)', color: 'var(--gray)', fontWeight: 600 }}>Feature</th>
              <th style={{ textAlign: 'center', padding: '10px 0', borderBottom: '2px solid var(--border)', color: 'var(--gray)', fontWeight: 600 }}>Free</th>
              <th style={{ textAlign: 'center', padding: '10px 0', borderBottom: '2px solid var(--border)', color: 'var(--rose)', fontWeight: 700 }}>⭐ Premium</th>
            </tr>
          </thead>
          <tbody>
            {FEATURES.map((f, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? 'var(--gray-light)' : 'white' }}>
                <td style={{ padding: '12px 8px' }}>{f.icon}</td>
                <td style={{ padding: '12px 8px', textAlign: 'center', color: 'var(--gray)' }}>{f.free}</td>
                <td style={{ padding: '12px 8px', textAlign: 'center', color: 'var(--rose)', fontWeight: 600 }}>{f.premium}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Payment Modal */}
      {showPayModal && (
        <div className="modal-backdrop" onClick={() => setShowPayModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Complete Payment</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowPayModal(false)}>✕</button>
            </div>
            <div style={{ marginBottom: 20 }}>
              <div style={{ background: 'var(--gray-light)', borderRadius: 'var(--radius-sm)', padding: 16, marginBottom: 16 }}>
                <div style={{ fontWeight: 700, fontSize: '1.1rem' }}>{selectedPlan?.name}</div>
                <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--rose)', marginTop: 4 }}>
                  {cur?.symbol}{selectedPlan?.price?.toLocaleString()} {currency}
                </div>
              </div>
              <p style={{ marginBottom: 16, fontSize: '0.9rem', color: 'var(--dark)' }}>
                Pay via your preferred method (bank transfer, card, or mobile money), then enter your payment reference below to activate your subscription.
              </p>
              <div style={{ background: 'var(--gold-light)', borderRadius: 'var(--radius-sm)', padding: 14, marginBottom: 16, fontSize: '0.85rem' }}>
                <strong>Payment Details:</strong><br />
                Bank: First Bank Nigeria<br />
                Account: 3012345678<br />
                Name: MyLover Ltd<br />
                Amount: {cur?.symbol}{selectedPlan?.price?.toLocaleString()} {currency}
              </div>
              <div className="form-group">
                <label className="form-label">Payment Reference / Transaction ID</label>
                <input className="form-input" placeholder="e.g. FBN2024123456" value={payRef} onChange={e => setPayRef(e.target.value)} />
                <div className="form-hint">Enter the reference from your bank app or receipt.</div>
              </div>
            </div>
            <div className="flex gap-3">
              <button className="btn btn-ghost flex-1" onClick={() => setShowPayModal(false)}>Cancel</button>
              <button className="btn btn-primary flex-1" onClick={handleSubscribe} disabled={subscribing || !payRef.trim()}>
                {subscribing ? <span className="spinner spinner-sm" /> : 'Activate Subscription'}
              </button>
            </div>
            <p style={{ marginTop: 12, fontSize: '0.78rem', color: 'var(--gray)', textAlign: 'center' }}>
              Subscription activates within minutes of payment verification. Need help? Contact support@mylover.app
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
