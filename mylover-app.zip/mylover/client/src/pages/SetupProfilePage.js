import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getCurrentPosition, saveLocation } from '../utils/geo';
import api from '../utils/api';

const INTERESTS = ['🎵 Music','🎬 Movies','✈️ Travel','🍳 Cooking','📚 Reading','🏋️ Fitness','🎮 Gaming','🎨 Art','📸 Photography','🌿 Nature','💃 Dancing','🏊 Swimming','⚽ Football','🎭 Theatre','🧘 Yoga','🍷 Wine','🐶 Pets','📺 Series','🏖️ Beach','🎤 Karaoke'];

export default function SetupProfilePage() {
  const { refreshUser } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ bio: '', occupation: '', education: '', height: '', religion: '', language: 'English', interested_in: '', interests: [], city: '' });
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [geoLoading, setGeoLoading] = useState(false);
  const [loading, setLoading] = useState(false);

  const toggleInterest = (i) => {
    setForm(f => ({ ...f, interests: f.interests.includes(i) ? f.interests.filter(x => x !== i) : [...f.interests, i].slice(0, 10) }));
  };

  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleLocation = async () => {
    setGeoLoading(true);
    try {
      const { lat, lng } = await getCurrentPosition();
      await saveLocation(lat, lng);
    } catch {}
    setGeoLoading(false);
  };

  const handleFinish = async () => {
    setLoading(true);
    try {
      if (photo) await api.uploadProfilePhoto(photo);
      await api.updateProfile({ ...form, interests: form.interests });
      await refreshUser();
      navigate('/discover');
    } catch (e) {
      alert('Error saving profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const steps = [
    { title: 'Add a Photo', desc: 'A great photo gets 10x more matches' },
    { title: 'About You', desc: 'Tell people a bit about yourself' },
    { title: 'Your Interests', desc: 'Pick up to 10 things you love' },
    { title: 'Almost There!', desc: 'Final details to complete your profile' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #1a0a0f, #2d1520)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 520 }}>
        {/* Progress */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            {steps.map((_, i) => (
              <div key={i} style={{ flex: 1, height: 4, borderRadius: 2, background: i < step ? 'var(--rose)' : 'rgba(255,255,255,0.2)' }} />
            ))}
          </div>
          <h2 style={{ color: 'white', marginBottom: 4 }}>{steps[step-1].title}</h2>
          <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.88rem' }}>{steps[step-1].desc}</p>
        </div>

        <div className="card" style={{ padding: 32 }}>
          {/* Step 1: Photo */}
          {step === 1 && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ width: 160, height: 160, borderRadius: '50%', background: photoPreview ? 'none' : 'linear-gradient(135deg, var(--rose-light), var(--purple-light))', margin: '0 auto 24px', overflow: 'hidden', border: '4px solid var(--rose)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {photoPreview ? <img src={photoPreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ fontSize: '3rem' }}>📷</span>}
              </div>
              <label className="btn btn-primary" style={{ cursor: 'pointer', display: 'inline-flex' }}>
                {photoPreview ? '📷 Change Photo' : '📷 Upload Photo'}
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhoto} />
              </label>
              <p style={{ marginTop: 12, fontSize: '0.82rem', color: 'var(--gray)' }}>JPG, PNG or WebP · Max 10MB</p>
            </div>
          )}

          {/* Step 2: Bio */}
          {step === 2 && (
            <div>
              <div className="form-group">
                <label className="form-label">Bio</label>
                <textarea className="form-input" placeholder="Tell people about yourself, your passions, what you're looking for..." value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} style={{ minHeight: 120 }} maxLength={500} />
                <div className="form-hint">{form.bio.length}/500</div>
              </div>
              <div className="grid-2">
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Occupation</label>
                  <input type="text" className="form-input" placeholder="e.g. Software Engineer" value={form.occupation} onChange={e => setForm(f => ({ ...f, occupation: e.target.value }))} />
                </div>
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">City</label>
                  <input type="text" className="form-input" placeholder="e.g. Lagos" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
                </div>
              </div>
              <div className="form-group mt-4">
                <label className="form-label">I'm interested in</label>
                <select className="form-input form-select" value={form.interested_in} onChange={e => setForm(f => ({ ...f, interested_in: e.target.value }))}>
                  <option value="">Everyone</option>
                  <option value="male">Men</option>
                  <option value="female">Women</option>
                  <option value="non-binary">Non-binary</option>
                  <option value="everyone">Everyone</option>
                </select>
              </div>
            </div>
          )}

          {/* Step 3: Interests */}
          {step === 3 && (
            <div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                {INTERESTS.map(i => (
                  <button key={i} type="button"
                    onClick={() => toggleInterest(i)}
                    className={form.interests.includes(i) ? 'interest-tag' : ''}
                    style={{ padding: '8px 16px', borderRadius: 50, border: '2px solid', cursor: 'pointer', fontSize: '0.88rem', fontFamily: 'var(--font)', transition: 'all 0.15s', borderColor: form.interests.includes(i) ? 'var(--rose)' : 'var(--border)', background: form.interests.includes(i) ? 'var(--rose-light)' : 'white', color: form.interests.includes(i) ? 'var(--rose)' : 'var(--dark)', fontWeight: form.interests.includes(i) ? 600 : 400 }}>
                    {i}
                  </button>
                ))}
              </div>
              <p style={{ marginTop: 16, fontSize: '0.82rem', color: 'var(--gray)' }}>{form.interests.length}/10 selected</p>
            </div>
          )}

          {/* Step 4: Final */}
          {step === 4 && (
            <div>
              <div className="grid-2">
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Height (cm)</label>
                  <input type="number" className="form-input" placeholder="e.g. 175" value={form.height} onChange={e => setForm(f => ({ ...f, height: e.target.value }))} min="120" max="250" />
                </div>
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Religion</label>
                  <select className="form-input form-select" value={form.religion} onChange={e => setForm(f => ({ ...f, religion: e.target.value }))}>
                    <option value="">Prefer not to say</option>
                    <option>Christianity</option><option>Islam</option><option>Judaism</option>
                    <option>Hinduism</option><option>Buddhism</option><option>Spiritual</option>
                    <option>Atheist</option><option>Agnostic</option><option>Other</option>
                  </select>
                </div>
              </div>
              <div className="form-group mt-4">
                <label className="form-label">Primary Language</label>
                <select className="form-input form-select" value={form.language} onChange={e => setForm(f => ({ ...f, language: e.target.value }))}>
                  {['English','Yoruba','Igbo','Hausa','French','Swahili','Arabic','Spanish','Portuguese','German','Mandarin','Hindi'].map(l => <option key={l}>{l}</option>)}
                </select>
              </div>

              {/* Location */}
              <div style={{ background: 'var(--rose-light)', borderRadius: 'var(--radius-sm)', padding: 16, marginTop: 16 }}>
                <div style={{ fontWeight: 600, marginBottom: 6, fontSize: '0.92rem' }}>📍 Enable Location</div>
                <p style={{ fontSize: '0.82rem', color: 'var(--gray)', marginBottom: 12 }}>Share your location to see how close you are to other users and get better matches.</p>
                <button type="button" className="btn btn-primary btn-sm" onClick={handleLocation} disabled={geoLoading}>
                  {geoLoading ? 'Getting location...' : '📍 Share My Location'}
                </button>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between mt-4" style={{ marginTop: 28 }}>
            {step > 1
              ? <button className="btn btn-ghost" onClick={() => setStep(s => s - 1)}>← Back</button>
              : <div />
            }
            {step < 4
              ? <button className="btn btn-primary" onClick={() => setStep(s => s + 1)}>
                  Continue →
                </button>
              : <button className="btn btn-primary" onClick={handleFinish} disabled={loading}>
                  {loading ? <span className="spinner spinner-sm" /> : '🎉 Start Discovering!'}
                </button>
            }
          </div>
          {step === 1 && (
            <button className="btn btn-ghost btn-block mt-2" style={{ fontSize: '0.85rem' }} onClick={() => setStep(2)}>
              Skip for now
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
