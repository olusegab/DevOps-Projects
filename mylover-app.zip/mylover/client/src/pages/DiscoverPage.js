import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { getCurrentPosition, saveLocation } from '../utils/geo';
import api from '../utils/api';

const INTERESTS_LIST = [
  '🎵 Music','🎬 Movies','✈️ Travel','🍳 Cooking','📚 Reading',
  '🏋️ Fitness','🎮 Gaming','🎨 Art','📸 Photography','🌿 Nature',
  '💃 Dancing','🏊 Swimming','⚽ Football','🎭 Theatre','🧘 Yoga'
];

export default function DiscoverPage() {
  const { user, isPremium, trialStatus } = useAuth();
  const { emit, on } = useSocket();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [loading, setLoading] = useState(true);
  const [match, setMatch] = useState(null);
  const [viewProfile, setViewProfile] = useState(null);
  const [filters, setFilters] = useState({ maxDistance: '', country: '' });
  const [showFilters, setShowFilters] = useState(false);
  const [geoStatus, setGeoStatus] = useState('idle');
  const [swipeDir, setSwipeDir] = useState(null);
  const touchStart = useRef(null);
  const cardRef = useRef(null);

  // Request location on mount
  useEffect(() => {
    (async () => {
      try {
        setGeoStatus('loading');
        const { lat, lng } = await getCurrentPosition();
        await saveLocation(lat, lng);
        setGeoStatus('granted');
      } catch {
        setGeoStatus('denied');
      }
    })();
  }, []);

  const loadProfiles = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (filters.maxDistance) params.maxDistance = filters.maxDistance;
      if (filters.country) params.country = filters.country;
      const { profiles: p } = await api.discover(params);
      setProfiles(p);
      setCurrentIdx(0);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => { loadProfiles(); }, [loadProfiles]);

  // Listen for match event
  useEffect(() => {
    if (!on) return;
    const unsub = on('its_a_match', ({ userId, conversationId }) => {
      const matchedUser = profiles.find(p => p.id === userId);
      setMatch({ user: matchedUser, conversationId });
    });
    return unsub;
  }, [on, profiles]);

  const current = profiles[currentIdx];

  const handleLike = useCallback((isSuper = false) => {
    if (!current) return;
    setSwipeDir('right');
    setTimeout(() => { setSwipeDir(null); setCurrentIdx(i => i + 1); }, 350);
    emit('send_like', { targetUserId: current.id, isSuper });
  }, [current, emit]);

  const handlePass = useCallback(() => {
    if (!current) return;
    setSwipeDir('left');
    setTimeout(() => { setSwipeDir(null); setCurrentIdx(i => i + 1); }, 350);
  }, [current]);

  // Touch swipe
  const onTouchStart = (e) => { touchStart.current = e.touches[0].clientX; };
  const onTouchEnd = (e) => {
    if (touchStart.current === null) return;
    const diff = e.changedTouches[0].clientX - touchStart.current;
    touchStart.current = null;
    if (diff > 80) handleLike();
    else if (diff < -80) handlePass();
  };

  if (loading) return (
    <div className="container" style={{ paddingTop: 40, textAlign: 'center' }}>
      <div className="spinner" style={{ margin: '60px auto' }} />
      <p>Finding your matches...</p>
    </div>
  );

  return (
    <div className="container" style={{ maxWidth: 520, paddingTop: 16 }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 style={{ color: 'var(--dark)' }}>Discover 🌍</h2>
        <div className="flex gap-2">
          {geoStatus === 'granted' && <span className="badge badge-green">📍 Location On</span>}
          {geoStatus === 'denied' && <span className="badge badge-gray">📍 No Location</span>}
          <button className="btn btn-ghost btn-sm" onClick={() => setShowFilters(!showFilters)}>
            🔧 Filters
          </button>
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="card mb-4">
          <h3 style={{ marginBottom: 16 }}>Filter Profiles</h3>
          <div className="grid-2">
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Max Distance (km)</label>
              <input type="number" className="form-input" placeholder="e.g. 50"
                value={filters.maxDistance} onChange={e => setFilters(f => ({ ...f, maxDistance: e.target.value }))} />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Country</label>
              <input type="text" className="form-input" placeholder="e.g. Nigeria"
                value={filters.country} onChange={e => setFilters(f => ({ ...f, country: e.target.value }))} />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button className="btn btn-primary btn-sm" onClick={() => { setShowFilters(false); loadProfiles(); }}>Apply</button>
            <button className="btn btn-ghost btn-sm" onClick={() => { setFilters({ maxDistance: '', country: '' }); }}>Clear</button>
          </div>
        </div>
      )}

      {/* Trial Banner */}
      {trialStatus && !trialStatus.isPremium && trialStatus.isInFreeTrial && (
        <div style={{ background: 'linear-gradient(135deg, #fce4ec, #f3e5f5)', borderRadius: 'var(--radius-sm)', padding: '12px 16px', marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: '0.85rem', color: 'var(--dark)' }}>
            🎉 Free trial: <strong>{trialStatus.freeTrialDaysLeft} days</strong> left
          </span>
          <button className="btn btn-sm btn-primary" onClick={() => navigate('/subscribe')}>Upgrade</button>
        </div>
      )}

      {/* Swipe Card Stack */}
      {currentIdx >= profiles.length ? (
        <div className="card text-center" style={{ padding: 48 }}>
          <div style={{ fontSize: '3rem', marginBottom: 16 }}>🌹</div>
          <h3>You've seen everyone nearby!</h3>
          <p style={{ marginTop: 8, marginBottom: 24 }}>Expand your filters or check back later for new members.</p>
          <button className="btn btn-primary" onClick={loadProfiles}>Refresh</button>
        </div>
      ) : (
        <>
          {/* Card stack visual (show next 2 cards behind current) */}
          <div style={{ position: 'relative', marginBottom: 20 }}>
            {profiles[currentIdx + 2] && (
              <div style={{ position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)', width: '90%', height: 80, background: '#f8f8f8', borderRadius: 24, zIndex: 1, boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }} />
            )}
            {profiles[currentIdx + 1] && (
              <div style={{ position: 'absolute', top: 4, left: '50%', transform: 'translateX(-50%)', width: '95%', height: 80, background: '#fdfdfd', borderRadius: 24, zIndex: 2, boxShadow: '0 3px 12px rgba(0,0,0,0.08)' }} />
            )}

            {/* Main swipe card */}
            <div
              ref={cardRef}
              className="swipe-card"
              style={{
                position: 'relative', zIndex: 3,
                transform: swipeDir === 'right' ? 'rotate(15deg) translateX(120%)' : swipeDir === 'left' ? 'rotate(-15deg) translateX(-120%)' : 'none',
                transition: swipeDir ? 'transform 0.35s ease' : 'none'
              }}
              onTouchStart={onTouchStart}
              onTouchEnd={onTouchEnd}
              onClick={() => setViewProfile(current)}
            >
              {current.profile_photo ? (
                <img src={current.profile_photo} alt={current.display_name} className="swipe-card-img" />
              ) : (
                <div className="swipe-card-img" style={{ background: 'linear-gradient(135deg, var(--rose-light), var(--purple-light))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '5rem' }}>👤</div>
              )}

              {/* Like/Nope overlay indicators */}
              {swipeDir === 'right' && (
                <div style={{ position: 'absolute', top: 30, left: 20, background: 'var(--rose)', color: 'white', padding: '8px 20px', borderRadius: 8, fontSize: '1.5rem', fontWeight: 900, transform: 'rotate(-20deg)', border: '4px solid white' }}>LIKE 💗</div>
              )}
              {swipeDir === 'left' && (
                <div style={{ position: 'absolute', top: 30, right: 20, background: '#64748b', color: 'white', padding: '8px 20px', borderRadius: 8, fontSize: '1.5rem', fontWeight: 900, transform: 'rotate(20deg)', border: '4px solid white' }}>NOPE</div>
              )}

              <div className="swipe-card-overlay" onClick={e => e.stopPropagation()}>
                <div className="flex items-center gap-2">
                  <h2 style={{ color: 'white', fontSize: '1.6rem' }}>
                    {current.display_name}
                    {current.age && <span style={{ fontWeight: 400 }}>, {current.age}</span>}
                  </h2>
                  {current.is_verified && <span title="Verified">✅</span>}
                  {current.is_premium && <span title="Premium">⭐</span>}
                </div>
                <div style={{ color: 'rgba(255,255,255,0.85)', fontSize: '0.9rem', marginTop: 4 }}>
                  📍 {current.city ? `${current.city}, ` : ''}{current.country || 'Unknown'}
                  {current.distanceLabel && <span style={{ marginLeft: 8, color: '#ffd54f' }}>· {current.distanceLabel}</span>}
                </div>
                {current.occupation && <div style={{ color: 'rgba(255,255,255,0.75)', fontSize: '0.85rem', marginTop: 2 }}>💼 {current.occupation}</div>}
                {current.bio && <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '0.88rem', marginTop: 8, lineHeight: 1.4, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>{current.bio}</p>}
                <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                  {(current.interests || []).slice(0, 3).map(i => (
                    <span key={i} style={{ background: 'rgba(255,255,255,0.2)', color: 'white', padding: '3px 10px', borderRadius: 50, fontSize: '0.78rem' }}>{i}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="swipe-actions">
            <button className="swipe-btn swipe-btn-back" title="Undo" onClick={loadProfiles}>↩</button>
            <button className="swipe-btn swipe-btn-pass" title="Pass" onClick={handlePass}>✕</button>
            <button className="swipe-btn swipe-btn-like" title="Like" onClick={() => handleLike(false)}>♥</button>
            <button className="swipe-btn swipe-btn-super" title="Super Like" onClick={() => handleLike(true)}>⭐</button>
            <button className="swipe-btn" style={{ background: 'white', color: 'var(--rose)' }} title="Boost" onClick={() => navigate('/subscribe')}>🚀</button>
          </div>

          <p style={{ textAlign: 'center', marginTop: 16, fontSize: '0.8rem', color: 'var(--gray)' }}>
            Swipe right to like · Swipe left to pass · Tap card for full profile
          </p>
          <p style={{ textAlign: 'center', fontSize: '0.78rem', color: 'var(--gray)' }}>
            {currentIdx + 1} of {profiles.length} profiles
          </p>
        </>
      )}

      {/* Full Profile Modal */}
      {viewProfile && (
        <div className="modal-backdrop" onClick={() => setViewProfile(null)}>
          <div className="modal" style={{ maxWidth: 440, padding: 0, overflow: 'hidden' }} onClick={e => e.stopPropagation()}>
            {viewProfile.profile_photo && (
              <img src={viewProfile.profile_photo} alt="" style={{ width: '100%', height: 300, objectFit: 'cover', display: 'block' }} />
            )}
            <div style={{ padding: 24 }}>
              <div className="flex items-center gap-2 justify-between">
                <div>
                  <h2>{viewProfile.display_name}{viewProfile.age ? `, ${viewProfile.age}` : ''} {viewProfile.is_verified ? '✅' : ''}</h2>
                  <p style={{ marginTop: 4 }}>📍 {viewProfile.city ? `${viewProfile.city}, ` : ''}{viewProfile.country}
                    {viewProfile.distanceLabel && <span style={{ color: 'var(--rose)', marginLeft: 8 }}>· {viewProfile.distanceLabel}</span>}
                  </p>
                </div>
              </div>
              {viewProfile.bio && <p style={{ marginTop: 12, color: 'var(--dark)', lineHeight: 1.6 }}>{viewProfile.bio}</p>}
              <div className="divider" />
              <div className="grid-2" style={{ fontSize: '0.88rem', color: 'var(--gray)' }}>
                {viewProfile.occupation && <div>💼 {viewProfile.occupation}</div>}
                {viewProfile.education && <div>🎓 {viewProfile.education}</div>}
                {viewProfile.height && <div>📏 {viewProfile.height} cm</div>}
                {viewProfile.religion && <div>🕊️ {viewProfile.religion}</div>}
                {viewProfile.language && <div>🗣️ {viewProfile.language}</div>}
                {viewProfile.ethnicity && <div>🌍 {viewProfile.ethnicity}</div>}
              </div>
              {viewProfile.interests?.length > 0 && (
                <>
                  <div className="divider" />
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {viewProfile.interests.map(i => <span key={i} className="interest-tag">{i}</span>)}
                  </div>
                </>
              )}
              {/* Photo gallery */}
              {viewProfile.photos?.length > 0 && (
                <>
                  <div className="divider" />
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                    {viewProfile.photos.map((ph, i) => (
                      <img key={i} src={ph} alt="" style={{ width: '100%', aspectRatio: '1', objectFit: 'cover', borderRadius: 8 }} />
                    ))}
                  </div>
                </>
              )}
              <div className="flex gap-3 mt-4">
                <button className="btn btn-ghost flex-1" onClick={() => setViewProfile(null)}>Close</button>
                <button className="btn btn-ghost flex-1" style={{ color: '#64748b' }} onClick={() => { handlePass(); setViewProfile(null); }}>✕ Pass</button>
                <button className="btn btn-primary flex-1" onClick={() => { handleLike(false); setViewProfile(null); }}>♥ Like</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Match Screen */}
      {match && (
        <div className="match-screen">
          <div className="heart-burst">💗</div>
          <h1>It's a Match!</h1>
          <p style={{ opacity: 0.9, marginTop: 8 }}>You and {match.user?.display_name || 'someone'} liked each other</p>
          <div className="match-photos" style={{ margin: '28px 0' }}>
            {user?.profile_photo
              ? <img src={user.profile_photo} alt="" />
              : <div style={{ width: 120, height: 120, borderRadius: '50%', background: 'rgba(255,255,255,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', border: '4px solid white' }}>😊</div>
            }
            <span style={{ fontSize: '2rem', alignSelf: 'center' }}>💕</span>
            {match.user?.profile_photo
              ? <img src={match.user.profile_photo} alt="" />
              : <div style={{ width: 120, height: 120, borderRadius: '50%', background: 'rgba(255,255,255,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', border: '4px solid white' }}>😊</div>
            }
          </div>
          <div className="flex gap-3">
            <button className="btn btn-secondary" style={{ color: 'white', borderColor: 'white' }} onClick={() => setMatch(null)}>Keep Swiping</button>
            <button className="btn btn-primary" style={{ background: 'white', color: 'var(--rose)' }}
              onClick={() => { setMatch(null); if (match.conversationId) navigate(`/chat/${match.conversationId}`); }}>
              💬 Start Chatting
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
