// ProfilePage.js
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';

export default function ProfilePage() {
  const { user, refreshUser, logout, trialStatus } = useAuth();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ display_name: user?.display_name || '', bio: user?.bio || '', occupation: user?.occupation || '', city: user?.city || '', height: user?.height || '', religion: user?.religion || '', language: user?.language || '' });
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const fileRef = useRef(null);

  const handleSave = async () => {
    setSaving(true);
    try { await api.updateProfile(form); await refreshUser(); setEditing(false); }
    catch (e) { alert(e.message); }
    finally { setSaving(false); }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingPhoto(true);
    try { await api.uploadProfilePhoto(file); await refreshUser(); }
    catch (e) { alert('Upload failed'); }
    finally { setUploadingPhoto(false); }
  };

  const photos = (() => { try { return JSON.parse(user?.photos || '[]'); } catch { return []; } })();
  const interests = (() => { try { return JSON.parse(user?.interests || '[]'); } catch { return []; } })();
  const age = user?.date_of_birth ? Math.floor((Date.now() - new Date(user.date_of_birth)) / (1000*60*60*24*365.25)) : null;

  return (
    <div className="container-md" style={{ paddingTop: 16 }}>
      <div className="card" style={{ marginBottom: 20 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 24 }}>
          <div style={{ position: 'relative', flexShrink: 0 }}>
            {user?.profile_photo
              ? <img src={user.profile_photo} alt="" style={{ width: 96, height: 96, borderRadius: '50%', objectFit: 'cover', border: '3px solid var(--rose)' }} />
              : <div className="avatar avatar-xl">{user?.display_name?.[0]?.toUpperCase()}</div>
            }
            <button onClick={() => fileRef.current.click()} disabled={uploadingPhoto}
              style={{ position: 'absolute', bottom: 0, right: 0, width: 28, height: 28, borderRadius: '50%', background: 'var(--rose)', border: '2px solid white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '0.75rem' }}>
              {uploadingPhoto ? '...' : '📷'}
            </button>
            <input type="file" ref={fileRef} accept="image/*" style={{ display: 'none' }} onChange={handlePhotoUpload} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <h2>{user?.display_name}</h2>
              {user?.is_verified && <span className="badge badge-green">✓ Verified</span>}
              {user?.is_premium && <span className="badge badge-gold">⭐ Premium</span>}
            </div>
            <p style={{ marginTop: 4 }}>{age && `${age} years old`}{user?.city && ` · ${user.city}`}{user?.country && `, ${user.country}`}</p>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={() => editing ? handleSave() : setEditing(true)} disabled={saving}>
            {editing ? (saving ? 'Saving...' : '✓ Save') : '✏️ Edit'}
          </button>
        </div>

        {/* Trial / Premium Status */}
        {trialStatus && (
          <div style={{ background: trialStatus.isPremium ? '#f0fdf4' : 'var(--rose-light)', borderRadius: 'var(--radius-sm)', padding: '12px 16px', marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            {trialStatus.isPremium
              ? <span style={{ color: '#16a34a', fontWeight: 600 }}>⭐ Premium Member</span>
              : trialStatus.isInFreeTrial
              ? <span style={{ color: 'var(--rose)', fontWeight: 600 }}>🎉 Free Trial: {trialStatus.freeTrialDaysLeft} days left</span>
              : <span style={{ color: 'var(--rose)', fontWeight: 600 }}>Free Trial Ended</span>
            }
            {!trialStatus.isPremium && <button className="btn btn-primary btn-sm" onClick={() => navigate('/subscribe')}>Upgrade</button>}
          </div>
        )}

        {editing ? (
          <div>
            <div className="grid-2">
              <div className="form-group"><label className="form-label">Display Name</label><input className="form-input" value={form.display_name} onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))} /></div>
              <div className="form-group"><label className="form-label">City</label><input className="form-input" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
            </div>
            <div className="form-group"><label className="form-label">Bio</label><textarea className="form-input" value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} style={{ minHeight: 100 }} /></div>
            <div className="grid-2">
              <div className="form-group"><label className="form-label">Occupation</label><input className="form-input" value={form.occupation} onChange={e => setForm(f => ({ ...f, occupation: e.target.value }))} /></div>
              <div className="form-group"><label className="form-label">Height (cm)</label><input type="number" className="form-input" value={form.height} onChange={e => setForm(f => ({ ...f, height: e.target.value }))} /></div>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => setEditing(false)}>Cancel</button>
          </div>
        ) : (
          <div>
            {user?.bio && <p style={{ color: 'var(--dark)', lineHeight: 1.7, marginBottom: 16 }}>{user.bio}</p>}
            <div className="grid-2" style={{ fontSize: '0.88rem', color: 'var(--gray)', marginBottom: 16, gap: 10 }}>
              {user?.occupation && <div>💼 {user.occupation}</div>}
              {user?.height && <div>📏 {user.height} cm</div>}
              {user?.religion && <div>🕊️ {user.religion}</div>}
              {user?.language && <div>🗣️ {user.language}</div>}
              {user?.gender && <div>👤 {user.gender}</div>}
              {user?.email && <div>✉️ {user.email}</div>}
            </div>
            {interests.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {interests.map(i => <span key={i} className="interest-tag">{i}</span>)}
              </div>
            )}
          </div>
        )}
      </div>

      {/* AI Credits */}
      <div className="card" style={{ marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontWeight: 600 }}>🤖 AI Credits</div>
          <p style={{ fontSize: '0.85rem', marginTop: 2 }}>{user?.ai_credits || 0} credits remaining for AI Coach & Icebreakers</p>
        </div>
        <button className="btn btn-gold btn-sm" onClick={() => navigate('/subscribe')}>Get More</button>
      </div>

      {/* Actions */}
      <div className="card">
        <h3 style={{ marginBottom: 16 }}>Account</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {[
            { label: '⭐ Premium Plans', action: () => navigate('/subscribe') },
            { label: '🔧 Complete Profile', action: () => navigate('/setup') },
            { label: '🔒 Privacy Settings', action: () => {} },
            { label: '📞 Help & Support', action: () => {} },
          ].map(item => (
            <button key={item.label} onClick={item.action} style={{ padding: '14px 0', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', borderBottom: '1px solid var(--border)', fontSize: '0.92rem', color: 'var(--dark)', fontFamily: 'var(--font)' }}>
              {item.label} <span style={{ float: 'right', color: 'var(--gray)' }}>›</span>
            </button>
          ))}
          <button onClick={logout} style={{ padding: '14px 0', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', fontSize: '0.92rem', color: '#dc2626', fontFamily: 'var(--font)', marginTop: 8 }}>
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
