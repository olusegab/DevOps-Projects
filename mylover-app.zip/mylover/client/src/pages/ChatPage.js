import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import api from '../utils/api';

// ── Icons ────────────────────────────────────────────────────────────────────
const PhoneIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>;
const VideoIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/></svg>;
const SendIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>;
const BackIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>;
const EmojiIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/></svg>;
const MuteIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>;
const EndCallIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28-.28 0-.53-.11-.71-.29L.29 13.08c-.18-.17-.29-.42-.29-.7 0-.28.11-.53.29-.71C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67c.18.18.29.43.29.71 0 .28-.11.53-.29.71l-2.48 2.48c-.18.18-.43.29-.71.29-.27 0-.52-.1-.7-.28-.79-.73-1.68-1.36-2.66-1.85-.33-.16-.56-.51-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z"/></svg>;
const CameraOffIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M18 10.48V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-4.48l4 3.98v-11l-4 3.98zm-2-.79V18H4V6h12v3.69z"/></svg>;

const EMOJIS = ['😊','❤️','😂','🥰','😘','💋','🌹','🎉','👋','🔥','💯','😍','🙏','✨','💕'];

export default function ChatPage() {
  const { conversationId: paramConvId } = useParams();
  const { user, isPremium, trialStatus } = useAuth();
  const { emit, on, onlineUsers } = useSocket();
  const navigate = useNavigate();

  const [conversations, setConversations] = useState([]);
  const [activeConv, setActiveConv] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [typing, setTyping] = useState(false);
  const [partnerTyping, setPartnerTyping] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sendingBlocked, setSendingBlocked] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showIcebreaker, setShowIcebreaker] = useState(false);
  const [icebreakers, setIcebreakers] = useState('');
  const [icebreakerLoading, setIcebreakerLoading] = useState(false);

  // Call state
  const [callState, setCallState] = useState(null); // null | 'outgoing' | 'incoming' | 'active'
  const [callType, setCallType] = useState(null); // 'audio' | 'video'
  const [incomingCall, setIncomingCall] = useState(null);
  const [callMuted, setCallMuted] = useState(false);
  const [callVideoOff, setCallVideoOff] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  // AI Coach
  const [showAI, setShowAI] = useState(false);
  const [aiMessages, setAiMessages] = useState([]);
  const [aiInput, setAiInput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  // WebRTC
  const pcRef = useRef(null);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const localStreamRef = useRef(null);
  const callTimerRef = useRef(null);

  const messagesEndRef = useRef(null);
  const typingTimerRef = useRef(null);

  // Load conversations
  useEffect(() => {
    (async () => {
      try {
        const { conversations: convs } = await api.getConversations();
        setConversations(convs);
        if (paramConvId) {
          const found = convs.find(c => c.id === paramConvId);
          if (found) openConversation(found);
        }
      } finally {
        setLoading(false);
      }
    })();
  }, [paramConvId]);

  const openConversation = useCallback(async (conv) => {
    setActiveConv(conv);
    setMessages([]);
    navigate(`/chat/${conv.id}`, { replace: true });
    emit('join_conversation', { conversationId: conv.id });
    try {
      const { messages: msgs } = await api.getMessages(conv.id);
      setMessages(msgs);
      emit('mark_read', { conversationId: conv.id });
    } catch {}
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
  }, [emit, navigate]);

  // Socket events
  useEffect(() => {
    if (!on) return;
    const unsubMsg = on('new_message', (msg) => {
      if (msg.conversationId === activeConv?.id) {
        setMessages(prev => [...prev, msg]);
        emit('mark_read', { conversationId: msg.conversationId });
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
      }
      setConversations(prev => prev.map(c => c.id === msg.conversationId ? { ...c, lastMessage: msg.content } : c));
    });
    const unsubTyping = on('user_typing', ({ userId, isTyping }) => {
      if (activeConv && userId !== user.id) setPartnerTyping(isTyping);
    });
    const unsubBlocked = on('message_blocked', () => setSendingBlocked(true));

    // Call events
    const unsubIncoming = on('incoming_call', ({ fromUserId, offer, conversationId }) => {
      if (conversationId === activeConv?.id || true) {
        setIncomingCall({ fromUserId, offer, conversationId });
        setCallState('incoming');
      }
    });
    const unsubAnswered = on('call_answered', ({ answer }) => {
      pcRef.current?.setRemoteDescription(new RTCSessionDescription(answer));
      setCallState('active');
      startCallTimer();
    });
    const unsubCandidate = on('ice_candidate', ({ candidate }) => {
      pcRef.current?.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
    });
    const unsubEnded = on('call_ended', () => endCall(false));

    return () => { unsubMsg(); unsubTyping(); unsubBlocked(); unsubIncoming(); unsubAnswered(); unsubCandidate(); unsubEnded(); };
  }, [on, activeConv, user, emit]);

  const sendMessage = useCallback(() => {
    if (!text.trim() || !activeConv) return;
    emit('send_message', { conversationId: activeConv.id, content: text.trim(), messageType: 'text' });
    setText('');
    setShowEmoji(false);
  }, [text, activeConv, emit]);

  const handleTyping = (val) => {
    setText(val);
    if (!typing) {
      setTyping(true);
      emit('typing', { conversationId: activeConv?.id, isTyping: true });
    }
    clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      setTyping(false);
      emit('typing', { conversationId: activeConv?.id, isTyping: false });
    }, 1500);
  };

  // ── WebRTC Call ─────────────────────────────────────────────────────────────
  async function startCall(type) {
    if (!activeConv) return;
    setCallType(type);
    setCallState('outgoing');

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: type === 'video' });
    localStreamRef.current = stream;
    if (localVideoRef.current) localVideoRef.current.srcObject = stream;

    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    pcRef.current = pc;
    stream.getTracks().forEach(t => pc.addTrack(t, stream));

    pc.onicecandidate = ({ candidate }) => {
      if (candidate) emit('ice_candidate', { targetUserId: activeConv.partner.id, candidate });
    };
    pc.ontrack = ({ streams }) => {
      if (remoteVideoRef.current) remoteVideoRef.current.srcObject = streams[0];
    };

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    emit('call_offer', { targetUserId: activeConv.partner.id, offer, conversationId: activeConv.id });
  }

  async function acceptCall() {
    if (!incomingCall) return;
    setCallState('active');
    setCallType(callType || 'audio');

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: callType === 'video' });
    localStreamRef.current = stream;
    if (localVideoRef.current) localVideoRef.current.srcObject = stream;

    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    pcRef.current = pc;
    stream.getTracks().forEach(t => pc.addTrack(t, stream));

    pc.onicecandidate = ({ candidate }) => {
      if (candidate) emit('ice_candidate', { targetUserId: incomingCall.fromUserId, candidate });
    };
    pc.ontrack = ({ streams }) => {
      if (remoteVideoRef.current) remoteVideoRef.current.srcObject = streams[0];
    };

    await pc.setRemoteDescription(new RTCSessionDescription(incomingCall.offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    emit('call_answer', { targetUserId: incomingCall.fromUserId, answer });
    setIncomingCall(null);
    startCallTimer();
  }

  function declineCall() {
    emit('end_call', { targetUserId: incomingCall?.fromUserId });
    setIncomingCall(null);
    setCallState(null);
  }

  function endCall(notify = true) {
    if (notify && activeConv) emit('end_call', { targetUserId: activeConv.partner.id });
    pcRef.current?.close(); pcRef.current = null;
    localStreamRef.current?.getTracks().forEach(t => t.stop()); localStreamRef.current = null;
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
    if (remoteVideoRef.current) remoteVideoRef.current.srcObject = null;
    clearInterval(callTimerRef.current);
    setCallState(null); setCallType(null); setCallDuration(0); setCallMuted(false); setCallVideoOff(false);
  }

  function toggleMute() {
    localStreamRef.current?.getAudioTracks().forEach(t => { t.enabled = callMuted; });
    setCallMuted(m => !m);
  }

  function toggleVideo() {
    localStreamRef.current?.getVideoTracks().forEach(t => { t.enabled = callVideoOff; });
    setCallVideoOff(v => !v);
  }

  function startCallTimer() {
    callTimerRef.current = setInterval(() => setCallDuration(d => d + 1), 1000);
  }

  const fmtDuration = (s) => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;

  // AI Icebreaker
  async function loadIcebreakers() {
    if (!activeConv) return;
    setIcebreakerLoading(true);
    try {
      const { suggestions } = await api.aiIcebreaker(activeConv.partner.id);
      setIcebreakers(suggestions);
    } catch (e) {
      setIcebreakers('Could not load suggestions. Try again.');
    } finally {
      setIcebreakerLoading(false);
    }
  }

  // AI Coach
  async function sendAiMessage() {
    if (!aiInput.trim()) return;
    const userMsg = { role: 'user', content: aiInput };
    setAiMessages(m => [...m, userMsg]);
    setAiInput('');
    setAiLoading(true);
    try {
      const { reply } = await api.aiCoach(aiInput, aiMessages);
      setAiMessages(m => [...m, { role: 'assistant', content: reply }]);
    } catch {
      setAiMessages(m => [...m, { role: 'assistant', content: 'AI coach temporarily unavailable.' }]);
    } finally {
      setAiLoading(false);
    }
  }

  const canAccess = isPremium || (trialStatus?.isInFreeTrial);
  const partner = activeConv?.partner;
  const partnerOnline = partner && onlineUsers?.has?.(partner.id);

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 64px)', overflow: 'hidden' }}>
      {/* Conversation List */}
      <div style={{
        width: activeConv ? '300px' : '100%', maxWidth: 360, borderRight: '1px solid var(--border)',
        background: 'white', display: 'flex', flexDirection: 'column', flexShrink: 0,
        ...(activeConv ? { display: window.innerWidth < 768 ? 'none' : 'flex' } : {})
      }}>
        <div style={{ padding: '20px 20px 16px', borderBottom: '1px solid var(--border)' }}>
          <h3>Messages</h3>
        </div>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {conversations.length === 0 ? (
            <div style={{ padding: 32, textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: 12 }}>💬</div>
              <p>No matches yet. Go discover people!</p>
              <button className="btn btn-primary btn-sm mt-4" onClick={() => navigate('/discover')}>Discover</button>
            </div>
          ) : conversations.map(conv => (
            <div key={conv.id}
              onClick={() => openConversation(conv)}
              style={{
                padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12,
                cursor: 'pointer', borderBottom: '1px solid var(--border)',
                background: activeConv?.id === conv.id ? 'var(--rose-light)' : 'white',
                transition: 'background 0.15s'
              }}>
              <div style={{ position: 'relative', flexShrink: 0 }}>
                {conv.partner.photo
                  ? <img src={conv.partner.photo} alt="" className="avatar avatar-md" />
                  : <div className="avatar avatar-md">{conv.partner.name?.[0]?.toUpperCase()}</div>
                }
                {onlineUsers?.has?.(conv.partner.id) && (
                  <div className="online-dot" style={{ position: 'absolute', bottom: 0, right: 0 }} />
                )}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontWeight: 600, fontSize: '0.92rem' }} className="truncate">{conv.partner.name}</span>
                  {conv.unreadCount > 0 && (
                    <span style={{ background: 'var(--rose)', color: 'white', borderRadius: 50, minWidth: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.72rem', fontWeight: 700, padding: '0 6px' }}>{conv.unreadCount}</span>
                  )}
                </div>
                <div className="truncate" style={{ fontSize: '0.82rem', color: 'var(--gray)', marginTop: 2 }}>{conv.lastMessage || 'Say hello!'}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Window */}
      {activeConv ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: '#f9f9f9', minWidth: 0 }}>
          {/* Chat Header */}
          <div style={{ padding: '14px 20px', background: 'white', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 12 }}>
            <button className="btn btn-ghost btn-sm btn-icon" onClick={() => { setActiveConv(null); navigate('/chat'); }} style={{ display: 'none' }} id="back-btn">
              <BackIcon />
            </button>
            {partner?.photo
              ? <img src={partner.photo} alt="" style={{ width: 42, height: 42, borderRadius: '50%', objectFit: 'cover' }} />
              : <div className="avatar avatar-md">{partner?.name?.[0]?.toUpperCase()}</div>
            }
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700 }}>{partner?.name}</div>
              <div style={{ fontSize: '0.78rem', color: partnerOnline ? '#22c55e' : 'var(--gray)' }}>
                {partnerOnline ? '● Online' : '● Offline'}
                {partnerTyping && ' · typing...'}
              </div>
            </div>
            <div className="flex gap-2">
              <button className="btn btn-ghost btn-sm btn-icon" title="Voice Call" onClick={() => startCall('audio')} style={{ color: 'var(--rose)' }}><PhoneIcon /></button>
              <button className="btn btn-ghost btn-sm btn-icon" title="Video Call" onClick={() => startCall('video')} style={{ color: 'var(--rose)' }}><VideoIcon /></button>
              <button className="btn btn-ghost btn-sm" style={{ fontSize: '0.8rem' }}
                onClick={() => { setShowIcebreaker(true); loadIcebreakers(); }}>
                ✨ Icebreaker
              </button>
              <button className="btn btn-ghost btn-sm" style={{ fontSize: '0.8rem', color: 'var(--purple)' }}
                onClick={() => setShowAI(true)}>
                🤖 AI Coach
              </button>
            </div>
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {messages.length === 0 && (
              <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: 12 }}>👋</div>
                <h3>You matched with {partner?.name}!</h3>
                <p style={{ marginTop: 8 }}>Say hello or use the AI Icebreaker for a great opener.</p>
              </div>
            )}
            {messages.map((msg, i) => {
              const isMine = msg.sender_id === user.id || msg.senderId === user.id;
              return (
                <div key={msg.id || i} style={{ display: 'flex', flexDirection: 'column', alignItems: isMine ? 'flex-end' : 'flex-start' }}>
                  <div className={`chat-bubble ${isMine ? 'chat-bubble-sent' : 'chat-bubble-recv'}`}>
                    {msg.content}
                  </div>
                  <div className="chat-time" style={{ textAlign: isMine ? 'right' : 'left' }}>
                    {new Date(msg.created_at || msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    {isMine && <span style={{ marginLeft: 4 }}>{msg.is_read ? '✓✓' : '✓'}</span>}
                  </div>
                </div>
              );
            })}
            {partnerTyping && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ background: 'white', border: '1px solid var(--border)', borderRadius: 18, padding: '10px 14px', display: 'flex', gap: 4 }}>
                  {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, background: 'var(--gray)', borderRadius: '50%', animation: `bounce 1s ${i*0.2}s infinite` }} />)}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Blocked message */}
          {sendingBlocked && (
            <div style={{ padding: '12px 20px', background: 'var(--rose-light)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.88rem', color: 'var(--rose)' }}>Free limit reached (5 msg/day). Upgrade for unlimited.</span>
              <button className="btn btn-primary btn-sm" onClick={() => navigate('/subscribe')}>Upgrade</button>
            </div>
          )}

          {/* Message Input */}
          {!sendingBlocked && (
            <div style={{ padding: '12px 20px', background: 'white', borderTop: '1px solid var(--border)', display: 'flex', gap: 10, alignItems: 'flex-end' }}>
              <div style={{ flex: 1, position: 'relative' }}>
                <textarea
                  className="form-input"
                  placeholder={`Message ${partner?.name}...`}
                  value={text}
                  onChange={e => handleTyping(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }}}
                  style={{ minHeight: 44, maxHeight: 120, resize: 'none', borderRadius: 22, paddingRight: 44 }}
                  rows={1}
                />
                <button style={{ position: 'absolute', right: 12, bottom: 10, border: 'none', background: 'none', cursor: 'pointer', color: 'var(--gray)', fontSize: '1.2rem' }}
                  onClick={() => setShowEmoji(!showEmoji)}>😊</button>
              </div>
              <button className="btn btn-primary btn-icon" onClick={sendMessage} disabled={!text.trim()}>
                <SendIcon />
              </button>
            </div>
          )}

          {/* Emoji Picker */}
          {showEmoji && (
            <div style={{ padding: '12px 20px', background: 'white', borderTop: '1px solid var(--border)', display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {EMOJIS.map(e => (
                <button key={e} onClick={() => setText(t => t + e)} style={{ border: 'none', background: 'none', cursor: 'pointer', fontSize: '1.5rem' }}>{e}</button>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16, color: 'var(--gray)' }}>
          <div style={{ fontSize: '4rem' }}>💬</div>
          <h3>Select a conversation</h3>
          <p>Pick a match to start chatting</p>
        </div>
      )}

      {/* ── Incoming Call Modal ─────────────────────────────────────────────── */}
      {callState === 'incoming' && incomingCall && (
        <div className="modal-backdrop">
          <div className="modal" style={{ textAlign: 'center', padding: 40 }}>
            <div style={{ fontSize: '3rem', marginBottom: 16 }}>📞</div>
            <h2>Incoming {callType === 'video' ? 'Video' : 'Voice'} Call</h2>
            <p style={{ marginTop: 8 }}>From your match</p>
            <div className="flex gap-4 justify-center mt-4">
              <button className="btn btn-ghost" style={{ color: '#dc2626', borderColor: '#dc2626' }} onClick={declineCall}>Decline</button>
              <button className="btn btn-primary" onClick={acceptCall}>Accept</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Outgoing Call Screen ─────────────────────────────────────────────── */}
      {callState === 'outgoing' && (
        <div className="modal-backdrop">
          <div className="modal" style={{ textAlign: 'center', padding: 40 }}>
            <div style={{ fontSize: '3rem', marginBottom: 16, animation: 'heartbeat 1s infinite alternate' }}>📞</div>
            <h2>Calling {partner?.name}...</h2>
            <p style={{ marginTop: 8 }}>Waiting for them to answer</p>
            <button className="btn mt-4" style={{ background: '#dc2626', color: 'white' }} onClick={() => endCall(true)}>Cancel</button>
          </div>
        </div>
      )}

      {/* ── Active Call Screen ─────────────────────────────────────────────── */}
      {callState === 'active' && (
        <div style={{ position: 'fixed', inset: 0, background: '#1a0a0f', zIndex: 500, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24 }}>
          {callType === 'video' ? (
            <>
              <video ref={remoteVideoRef} autoPlay playsInline style={{ width: '100%', maxWidth: 600, borderRadius: 16, background: '#000' }} />
              <video ref={localVideoRef} autoPlay playsInline muted style={{ position: 'absolute', bottom: 120, right: 24, width: 140, height: 100, objectFit: 'cover', borderRadius: 12, border: '3px solid white' }} />
            </>
          ) : (
            <>
              {partner?.photo
                ? <img src={partner.photo} alt="" style={{ width: 120, height: 120, borderRadius: '50%', objectFit: 'cover', border: '4px solid var(--rose)' }} />
                : <div style={{ width: 120, height: 120, borderRadius: '50%', background: 'var(--rose)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem', color: 'white' }}>👤</div>
              }
              <div style={{ textAlign: 'center', color: 'white' }}>
                <h2>{partner?.name}</h2>
                <p style={{ marginTop: 4, color: 'rgba(255,255,255,0.7)' }}>{fmtDuration(callDuration)}</p>
              </div>
              <audio ref={remoteVideoRef} autoPlay />
            </>
          )}
          {/* Call controls */}
          <div style={{ display: 'flex', gap: 20, alignItems: 'center', position: callType === 'video' ? 'absolute' : 'static', bottom: 40 }}>
            <button onClick={toggleMute} style={{ width: 56, height: 56, borderRadius: '50%', border: 'none', background: callMuted ? 'var(--rose)' : 'rgba(255,255,255,0.2)', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MuteIcon />
            </button>
            <button onClick={() => endCall(true)} style={{ width: 72, height: 72, borderRadius: '50%', border: 'none', background: '#dc2626', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <EndCallIcon />
            </button>
            {callType === 'video' && (
              <button onClick={toggleVideo} style={{ width: 56, height: 56, borderRadius: '50%', border: 'none', background: callVideoOff ? 'var(--rose)' : 'rgba(255,255,255,0.2)', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <CameraOffIcon />
              </button>
            )}
          </div>
          {callType === 'audio' && <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>{fmtDuration(callDuration)}</p>}
        </div>
      )}

      {/* ── Icebreaker Modal ──────────────────────────────────────────────── */}
      {showIcebreaker && (
        <div className="modal-backdrop" onClick={() => setShowIcebreaker(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>✨ AI Icebreakers</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowIcebreaker(false)}>✕</button>
            </div>
            {icebreakerLoading ? <div className="spinner" style={{ margin: '20px auto' }} /> : (
              <div>
                <p style={{ marginBottom: 16, fontSize: '0.88rem' }}>Suggested opening messages for {partner?.name}:</p>
                <div style={{ whiteSpace: 'pre-wrap', background: 'var(--gray-light)', borderRadius: 'var(--radius-sm)', padding: 16, fontSize: '0.9rem', color: 'var(--dark)', lineHeight: 1.7 }}>{icebreakers}</div>
                <div className="flex gap-2 mt-4">
                  <button className="btn btn-ghost btn-sm" onClick={loadIcebreakers}>Regenerate</button>
                  <button className="btn btn-primary btn-sm" onClick={() => setShowIcebreaker(false)}>Done</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── AI Dating Coach ──────────────────────────────────────────────── */}
      {showAI && (
        <div className="modal-backdrop" onClick={() => setShowAI(false)}>
          <div className="modal" style={{ maxWidth: 480 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🤖 AI Dating Coach</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowAI(false)}>✕</button>
            </div>
            <div style={{ height: 320, overflowY: 'auto', background: 'var(--gray-light)', borderRadius: 'var(--radius-sm)', padding: 16, display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 12 }}>
              {aiMessages.length === 0 && <p style={{ textAlign: 'center', color: 'var(--gray)', fontSize: '0.88rem' }}>Ask me anything about dating, relationships, or how to approach {partner?.name}!</p>}
              {aiMessages.map((m, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
                  <div style={{ maxWidth: '80%', padding: '10px 14px', borderRadius: 16, background: m.role === 'user' ? 'var(--rose)' : 'white', color: m.role === 'user' ? 'white' : 'var(--dark)', fontSize: '0.88rem', border: m.role === 'assistant' ? '1px solid var(--border)' : 'none' }}>
                    {m.content}
                  </div>
                </div>
              ))}
              {aiLoading && <div style={{ display: 'flex', gap: 4, padding: '10px 14px' }}>{[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, background: 'var(--gray)', borderRadius: '50%', animation: `bounce 1s ${i*0.2}s infinite` }} />)}</div>}
            </div>
            <div className="flex gap-2">
              <input className="form-input" style={{ borderRadius: 22 }} placeholder="Ask your dating coach..." value={aiInput} onChange={e => setAiInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendAiMessage()} />
              <button className="btn btn-primary btn-icon" onClick={sendAiMessage} disabled={!aiInput.trim() || aiLoading}><SendIcon /></button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
      `}</style>
    </div>
  );
}
