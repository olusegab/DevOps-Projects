import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(form.email, form.password);
      navigate('/discover');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #1a0a0f, #2d1520)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 440 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <Link to="/" style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', color: 'var(--rose)', textDecoration: 'none', fontWeight: 700 }}>
            MyLover <span style={{ color: 'var(--gold)' }}>🌹</span>
          </Link>
          <p style={{ color: 'rgba(255,255,255,0.5)', marginTop: 8 }}>Welcome back</p>
        </div>
        <div className="card" style={{ padding: 32 }}>
          <h2 style={{ marginBottom: 24, textAlign: 'center' }}>Sign In</h2>
          {error && <div style={{ background: '#fef2f2', color: '#dc2626', padding: '12px 16px', borderRadius: 'var(--radius-xs)', marginBottom: 20, fontSize: '0.88rem' }}>{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" className="form-input" placeholder="you@example.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className="form-input" placeholder="••••••••" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
            </div>
            <button type="submit" className="btn btn-primary btn-block btn-lg" disabled={loading}>
              {loading ? <span className="spinner spinner-sm" /> : 'Sign In'}
            </button>
          </form>
          <p style={{ textAlign: 'center', marginTop: 20, fontSize: '0.88rem', color: 'var(--gray)' }}>
            Don't have an account? <Link to="/register">Create one</Link>
          </p>
          <p style={{ textAlign: 'center', marginTop: 8, fontSize: '0.82rem' }}>
            <Link to="/" style={{ color: 'var(--gray)' }}>← Back to home</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
