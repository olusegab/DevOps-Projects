import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';

// ── Icons ─────────────────────────────────────────────────────────────────────
const Icon = ({ d, size = 18 }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d={d} /></svg>;
const icons = {
  dash: 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z',
  users: 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z',
  chat: 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z',
  report: 'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
  money: 'M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z',
  log: 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z',
  ban: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.42 3.58-8 8-8 1.85 0 3.55.63 4.9 1.68L5.68 16.9C4.63 15.55 4 13.85 4 12zm8 8c-1.85 0-3.55-.63-4.9-1.68L18.32 7.1C19.37 8.45 20 10.15 20 12c0 4.42-3.58 8-8 8z',
};

const NavItem = ({ icon, label, active, onClick }) => (
  <button className={`admin-nav-item ${active ? 'active' : ''}`} onClick={onClick}>
    <Icon d={icons[icon]} size={18} />
    {label}
  </button>
);

export default function AdminPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [section, setSection] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [reports, setReports] = useState([]);
  const [subs, setSubs] = useState([]);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [userFilter, setUserFilter] = useState('');
  const [msgSearch, setMsgSearch] = useState('');
  const [showFlagged, setShowFlagged] = useState(false);
  const [toast, setToast] = useState(null);
  const [selectedMsgs, setSelectedMsgs] = useState([]);

  const showToast = (msg, type = 'success') => { setToast({ msg, type }); setTimeout(() => setToast(null), 3000); };

  const load = useCallback(async (sec) => {
    setLoading(true);
    try {
      if (sec === 'dashboard') { const s = await api.admin.getStats(); setStats(s); }
      else if (sec === 'users') { const { users: u } = await api.admin.getUsers({ search, status: userFilter }); setUsers(u); }
      else if (sec === 'messages') { const { messages: m } = await api.admin.getMessages({ flagged: showFlagged, search: msgSearch }); setMessages(m); }
      else if (sec === 'reports') { const { reports: r } = await api.admin.getReports('pending'); setReports(r); }
      else if (sec === 'subscriptions') { const { subscriptions: s } = await api.admin.getSubscriptions(); setSubs(s); }
      else if (sec === 'logs') { const { logs: l } = await api.admin.getLogs(); setLogs(l); }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [search, userFilter, showFlagged, msgSearch]);

  useEffect(() => { load(section); }, [section]);

  const banUser = async (id, reason) => {
    const r = reason || prompt('Ban reason:');
    if (!r) return;
    await api.admin.banUser(id, r);
    showToast('User banned');
    load('users');
  };
  const unbanUser = async (id) => { await api.admin.unbanUser(id); showToast('User unbanned'); load('users'); };
  const verifyUser = async (id) => { await api.admin.verifyUser(id); showToast('User verified ✓'); load('users'); };
  const grantPremium = async (id) => { const d = prompt('Premium days (default 30):', '30'); if (!d) return; await api.admin.grantPremium(id, parseInt(d)); showToast('Premium granted ⭐'); load('users'); };
  const flagMsg = async (id) => { const r = prompt('Flag reason:'); if (!r) return; await api.admin.flagMessage(id, r); showToast('Message flagged'); load('messages'); };
  const unflagMsg = async (id) => { await api.admin.unflagMessage(id); load('messages'); };
  const resolveReport = async (id) => { const a = prompt('Action taken:'); if (!a) return; await api.admin.resolveReport(id, { actionTaken: a }); showToast('Report resolved'); load('reports'); };
  const aiScan = async () => { const ids = messages.map(m => m.id); const r = await api.admin.aiScanMessages(ids); showToast(`AI scanned ${r.scanned} msgs, flagged ${r.flagged}`); load('messages'); };

  const Stat = ({ value, label, sub, color = 'var(--rose)' }) => (
    <div className="stat-card">
      <div className="value" style={{ color }}>{value}</div>
      <div className="label">{label}</div>
      {sub && <div className="change" style={{ color }}>{sub}</div>}
    </div>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--gray-light)' }}>
      {/* Sidebar */}
      <div className="admin-sidebar">
        <div className="logo">
          <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.4rem', color: 'var(--rose)', fontWeight: 700 }}>MyLover 🌹</div>
          <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>Admin Panel</div>
        </div>
        {[
          { id: 'dashboard', icon: 'dash', label: 'Dashboard' },
          { id: 'users', icon: 'users', label: 'Users' },
          { id: 'messages', icon: 'chat', label: 'Messages' },
          { id: 'reports', icon: 'report', label: 'Reports' },
          { id: 'subscriptions', icon: 'money', label: 'Subscriptions' },
          { id: 'logs', icon: 'log', label: 'Audit Logs' },
        ].map(item => (
          <NavItem key={item.id} icon={item.icon} label={item.label} active={section === item.id} onClick={() => setSection(item.id)} />
        ))}
        <div style={{ marginTop: 'auto', borderTop: '1px solid rgba(255,255,255,0.1)', padding: '16px 24px' }}>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.78rem', marginBottom: 12 }}>Signed in as<br /><strong style={{ color: 'white' }}>{user?.display_name}</strong></div>
          <button className="admin-nav-item" onClick={() => navigate('/discover')}>← Back to App</button>
          <button className="admin-nav-item" onClick={logout} style={{ color: '#f87171' }}>Sign Out</button>
        </div>
      </div>

      {/* Content */}
      <div className="admin-content" style={{ flex: 1 }}>
        {toast && <div style={{ position: 'fixed', top: 20, right: 20, background: toast.type === 'error' ? '#dc2626' : '#16a34a', color: 'white', padding: '12px 24px', borderRadius: 50, zIndex: 999, fontWeight: 600 }}>{toast.msg}</div>}

        {loading && <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>}

        {/* Dashboard */}
        {section === 'dashboard' && stats && !loading && (
          <>
            <h2 style={{ marginBottom: 24 }}>Dashboard Overview</h2>
            <div className="grid-4" style={{ marginBottom: 24 }}>
              <Stat value={stats.users.total.toLocaleString()} label="Total Users" sub={`+${stats.users.new_this_week} this week`} />
              <Stat value={stats.users.active_today.toLocaleString()} label="Active Today" color="#2563eb" />
              <Stat value={stats.users.premium.toLocaleString()} label="Premium Members" color="#d97706" />
              <Stat value={stats.messages.total.toLocaleString()} label="Total Messages" color="#7c3aed" />
            </div>
            <div className="grid-4" style={{ marginBottom: 32 }}>
              <Stat value={stats.matches.total.toLocaleString()} label="Total Matches" />
              <Stat value={stats.messages.flagged.toLocaleString()} label="Flagged Messages" color="#dc2626" sub="⚠ Needs review" />
              <Stat value={stats.reports.pending.toLocaleString()} label="Pending Reports" color="#dc2626" />
              <Stat value={stats.subscriptions.active.toLocaleString()} label="Active Subscriptions" color="#16a34a" />
            </div>

            {/* Top Countries */}
            <div className="grid-2" style={{ gap: 24 }}>
              <div className="card">
                <h3 style={{ marginBottom: 16 }}>Top Countries</h3>
                {stats.countries.map(c => (
                  <div key={c.country} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: '0.88rem' }}>
                    <span>{c.country || 'Unknown'}</span>
                    <span style={{ fontWeight: 600, color: 'var(--rose)' }}>{c.count}</span>
                  </div>
                ))}
              </div>
              <div className="card">
                <h3 style={{ marginBottom: 16 }}>Subscription Breakdown</h3>
                {[
                  { label: 'Weekly', value: stats.subscriptions.weekly, color: 'var(--rose)' },
                  { label: 'Monthly', value: stats.subscriptions.monthly, color: 'var(--gold)' },
                  { label: 'Yearly', value: stats.subscriptions.yearly, color: 'var(--purple)' },
                ].map(s => (
                  <div key={s.label} style={{ marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: '0.85rem' }}>
                      <span>{s.label}</span><span style={{ fontWeight: 600 }}>{s.value}</span>
                    </div>
                    <div style={{ height: 8, background: 'var(--gray-light)', borderRadius: 4, overflow: 'hidden' }}>
                      <div style={{ height: '100%', background: s.color, width: `${stats.subscriptions.active ? (s.value / stats.subscriptions.active) * 100 : 0}%`, borderRadius: 4 }} />
                    </div>
                  </div>
                ))}
                <div style={{ marginTop: 20 }}>
                  <h3 style={{ marginBottom: 12 }}>Messages (7 days)</h3>
                  {stats.messages.this_week.toLocaleString()} messages this week
                </div>
              </div>
            </div>
          </>
        )}

        {/* Users */}
        {section === 'users' && !loading && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
              <h2>Users ({users.length})</h2>
              <div style={{ display: 'flex', gap: 10 }}>
                <input className="form-input" style={{ width: 220 }} placeholder="Search name or email..." value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && load('users')} />
                <select className="form-input form-select" style={{ width: 140 }} value={userFilter} onChange={e => { setUserFilter(e.target.value); }}>
                  <option value="">All Users</option>
                  <option value="banned">Banned</option>
                  <option value="premium">Premium</option>
                  <option value="verified">Verified</option>
                </select>
                <button className="btn btn-primary btn-sm" onClick={() => load('users')}>Search</button>
              </div>
            </div>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>User</th><th>Country</th><th>Status</th><th>Joined</th><th>Last Seen</th><th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--rose-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: 'var(--rose)', flexShrink: 0, fontSize: '0.9rem' }}>
                              {u.display_name?.[0]?.toUpperCase()}
                            </div>
                            <div>
                              <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{u.display_name}</div>
                              <div style={{ fontSize: '0.78rem', color: 'var(--gray)' }}>{u.email}</div>
                            </div>
                          </div>
                        </td>
                        <td>{u.country || '—'}</td>
                        <td>
                          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                            {u.is_verified ? <span className="badge badge-green">✓ Verified</span> : null}
                            {u.is_premium ? <span className="badge badge-gold">⭐ Premium</span> : null}
                            {u.is_banned ? <span className="badge badge-red">🚫 Banned</span> : null}
                            {!u.is_verified && !u.is_premium && !u.is_banned ? <span className="badge badge-gray">Free</span> : null}
                          </div>
                        </td>
                        <td style={{ fontSize: '0.82rem', color: 'var(--gray)' }}>{u.created_at ? new Date(u.created_at).toLocaleDateString() : '—'}</td>
                        <td style={{ fontSize: '0.82rem', color: 'var(--gray)' }}>{u.last_seen ? new Date(u.last_seen).toLocaleDateString() : '—'}</td>
                        <td>
                          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                            {!u.is_verified && <button className="btn btn-sm" style={{ background: '#f0fdf4', color: '#16a34a', fontSize: '0.78rem' }} onClick={() => verifyUser(u.id)}>✓ Verify</button>}
                            {!u.is_premium && <button className="btn btn-sm" style={{ background: 'var(--gold-light)', color: '#b45309', fontSize: '0.78rem' }} onClick={() => grantPremium(u.id)}>⭐ Premium</button>}
                            {u.is_banned
                              ? <button className="btn btn-sm" style={{ background: '#f0fdf4', color: '#16a34a', fontSize: '0.78rem' }} onClick={() => unbanUser(u.id)}>Unban</button>
                              : <button className="btn btn-sm" style={{ background: '#fef2f2', color: '#dc2626', fontSize: '0.78rem' }} onClick={() => banUser(u.id)}>🚫 Ban</button>
                            }
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {/* Messages Monitor */}
        {section === 'messages' && !loading && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
              <h2>Message Monitor</h2>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <input className="form-input" style={{ width: 200 }} placeholder="Search content..." value={msgSearch} onChange={e => setMsgSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && load('messages')} />
                <button className={`btn btn-sm ${showFlagged ? 'btn-primary' : 'btn-ghost'}`} onClick={() => { setShowFlagged(f => !f); }}>
                  🚩 {showFlagged ? 'Show All' : 'Flagged Only'}
                </button>
                <button className="btn btn-sm btn-secondary" onClick={aiScan}>🤖 AI Scan All</button>
                <button className="btn btn-sm btn-primary" onClick={() => load('messages')}>Search</button>
              </div>
            </div>
            <div style={{ marginBottom: 12, fontSize: '0.85rem', color: 'var(--gray)' }}>
              {messages.length} messages shown · AI scan automatically flags scams, harassment, and explicit content
            </div>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table className="data-table">
                <thead>
                  <tr><th>Sender</th><th>Message</th><th>Time</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                  {messages.map(m => (
                    <tr key={m.id} style={{ background: m.is_flagged ? '#fff7f7' : 'white' }}>
                      <td>
                        <div style={{ fontWeight: 600, fontSize: '0.88rem' }}>{m.sender_name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--gray)' }}>{m.sender_email}</div>
                      </td>
                      <td style={{ maxWidth: 300 }}>
                        <div style={{ fontSize: '0.88rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 280 }}>{m.content}</div>
                        {m.is_flagged && <div style={{ fontSize: '0.75rem', color: '#dc2626', marginTop: 2 }}>🚩 {m.flag_reason}</div>}
                      </td>
                      <td style={{ fontSize: '0.78rem', color: 'var(--gray)', whiteSpace: 'nowrap' }}>{new Date(m.created_at).toLocaleString()}</td>
                      <td>
                        {m.is_flagged
                          ? <span className="badge badge-red">🚩 Flagged</span>
                          : <span className="badge badge-green">✓ Clean</span>
                        }
                      </td>
                      <td>
                        {m.is_flagged
                          ? <button className="btn btn-sm" style={{ background: '#f0fdf4', color: '#16a34a', fontSize: '0.78rem' }} onClick={() => unflagMsg(m.id)}>Clear</button>
                          : <button className="btn btn-sm" style={{ background: '#fef2f2', color: '#dc2626', fontSize: '0.78rem' }} onClick={() => flagMsg(m.id)}>🚩 Flag</button>
                        }
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* Reports */}
        {section === 'reports' && !loading && (
          <>
            <h2 style={{ marginBottom: 20 }}>User Reports ({reports.length} pending)</h2>
            {reports.length === 0 ? (
              <div className="card text-center" style={{ padding: 40 }}>
                <div style={{ fontSize: '2rem', marginBottom: 12 }}>✅</div>
                <h3>No pending reports</h3>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {reports.map(r => (
                  <div key={r.id} className="card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
                      <div>
                        <div style={{ fontWeight: 700, marginBottom: 4 }}>
                          <span style={{ color: 'var(--rose)' }}>{r.reporter_name}</span>
                          {' reported '}
                          <span style={{ color: '#dc2626' }}>{r.reported_name}</span>
                          {r.reported_is_banned && <span className="badge badge-red" style={{ marginLeft: 8 }}>Already Banned</span>}
                        </div>
                        <div style={{ fontSize: '0.88rem', marginBottom: 4 }}>
                          <strong>Reason:</strong> {r.reason}
                        </div>
                        {r.details && <div style={{ fontSize: '0.85rem', color: 'var(--gray)' }}>{r.details}</div>}
                        <div style={{ fontSize: '0.78rem', color: 'var(--gray)', marginTop: 4 }}>{new Date(r.created_at).toLocaleString()}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        {!r.reported_is_banned && (
                          <button className="btn btn-sm" style={{ background: '#fef2f2', color: '#dc2626' }} onClick={() => banUser(r.reported_user_id, r.reason)}>🚫 Ban User</button>
                        )}
                        <button className="btn btn-sm btn-primary" onClick={() => resolveReport(r.id)}>✓ Resolve</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Subscriptions */}
        {section === 'subscriptions' && !loading && (
          <>
            <h2 style={{ marginBottom: 20 }}>Subscriptions ({subs.length})</h2>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table className="data-table">
                <thead>
                  <tr><th>User</th><th>Plan</th><th>Price</th><th>Status</th><th>Expires</th><th>Ref</th></tr>
                </thead>
                <tbody>
                  {subs.map(s => (
                    <tr key={s.id}>
                      <td>
                        <div style={{ fontWeight: 600, fontSize: '0.88rem' }}>{s.display_name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--gray)' }}>{s.email}</div>
                      </td>
                      <td><span className="badge badge-gold" style={{ textTransform: 'capitalize' }}>⭐ {s.plan}</span></td>
                      <td>{s.currency} {s.price?.toLocaleString()}</td>
                      <td><span className={`badge ${s.status === 'active' ? 'badge-green' : 'badge-gray'}`}>{s.status}</span></td>
                      <td style={{ fontSize: '0.82rem' }}>{new Date(s.expires_at).toLocaleDateString()}</td>
                      <td style={{ fontSize: '0.78rem', color: 'var(--gray)' }}>{s.payment_ref || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* Logs */}
        {section === 'logs' && !loading && (
          <>
            <h2 style={{ marginBottom: 20 }}>Audit Logs</h2>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table className="data-table">
                <thead>
                  <tr><th>Admin</th><th>Action</th><th>Target</th><th>Details</th><th>Time</th></tr>
                </thead>
                <tbody>
                  {logs.map(l => (
                    <tr key={l.id}>
                      <td style={{ fontWeight: 600, fontSize: '0.88rem' }}>{l.admin_name}</td>
                      <td><span className="badge badge-rose" style={{ textTransform: 'capitalize' }}>{l.action.replace(/_/g, ' ')}</span></td>
                      <td style={{ fontSize: '0.82rem' }}>{l.target_type} {l.target_id?.slice(0, 8)}...</td>
                      <td style={{ fontSize: '0.82rem', color: 'var(--gray)' }}>{l.details}</td>
                      <td style={{ fontSize: '0.78rem', color: 'var(--gray)', whiteSpace: 'nowrap' }}>{new Date(l.created_at).toLocaleString()}</td>
                    </tr>
                  ))}
                  {logs.length === 0 && <tr><td colSpan="5" style={{ textAlign: 'center', padding: 32, color: 'var(--gray)' }}>No logs yet</td></tr>}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
