#!/bin/bash
# MyLover — Development Startup Script

echo "🌹 Starting MyLover..."

# Check node
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org (v18+)"
  exit 1
fi

# Install root dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "📦 Installing dependencies..."
  npm install
fi

# Copy .env if not exists
if [ ! -f "server/.env" ]; then
  cp server/.env.example server/.env
  echo "⚠️  server/.env created from template. Edit it before production!"
fi

# Start server and client in parallel
echo "🚀 Starting server on :5000 and client on :3000..."
echo ""

# Start server
cd server && node index.js &
SERVER_PID=$!

# Wait a moment then start client
sleep 2
cd ../client && PORT=3000 BROWSER=none npm start &
CLIENT_PID=$!

echo ""
echo "✅ MyLover is running!"
echo "   App:    http://localhost:3000"
echo "   API:    http://localhost:5000/api/health"
echo "   Admin:  http://localhost:3000/admin"
echo "   Login:  admin@mylover.app / Admin@MyLover2024!"
echo ""
echo "Press Ctrl+C to stop."

# Wait and clean up
trap "kill $SERVER_PID $CLIENT_PID 2>/dev/null; exit" INT TERM
wait
