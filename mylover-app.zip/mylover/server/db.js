// db.js — database bootstrap
const fs      = require('fs');
const path    = require('path');
const Database = require('./db_sqlite_shim');

const DB_PATH = path.join(__dirname, 'data', 'mylover.db');
let _db = null;

async function initDB() {
  // 1. Initialise sql.js WASM (async, once)
  await Database.init();

  // 2. Ensure data directory exists
  const dir = path.join(__dirname, 'data');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  // 3. Open / create database file
  _db = new Database(DB_PATH);

  // 4. Create schema
  _db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL,
      date_of_birth TEXT,
      gender TEXT,
      interested_in TEXT,
      country TEXT,
      city TEXT,
      lat REAL,
      lng REAL,
      bio TEXT,
      profile_photo TEXT,
      photos TEXT DEFAULT '[]',
      interests TEXT DEFAULT '[]',
      occupation TEXT,
      education TEXT,
      height INTEGER,
      religion TEXT,
      ethnicity TEXT,
      language TEXT DEFAULT 'English',
      is_verified INTEGER DEFAULT 0,
      is_premium INTEGER DEFAULT 0,
      is_admin INTEGER DEFAULT 0,
      is_banned INTEGER DEFAULT 0,
      ban_reason TEXT,
      free_trial_used INTEGER DEFAULT 0,
      ai_credits INTEGER DEFAULT 100,
      last_seen TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      plan TEXT NOT NULL,
      status TEXT DEFAULT 'active',
      price REAL,
      currency TEXT DEFAULT 'USD',
      started_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      payment_ref TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS likes (
      id TEXT PRIMARY KEY,
      from_user_id TEXT NOT NULL,
      to_user_id TEXT NOT NULL,
      is_super INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      UNIQUE(from_user_id, to_user_id)
    );

    CREATE TABLE IF NOT EXISTS matches (
      id TEXT PRIMARY KEY,
      user1_id TEXT NOT NULL,
      user2_id TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(user1_id, user2_id)
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      user1_id TEXT NOT NULL,
      user2_id TEXT NOT NULL,
      last_message TEXT,
      last_message_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(user1_id, user2_id)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      sender_id TEXT NOT NULL,
      content TEXT NOT NULL,
      message_type TEXT DEFAULT 'text',
      is_read INTEGER DEFAULT 0,
      is_flagged INTEGER DEFAULT 0,
      flag_reason TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      reporter_id TEXT NOT NULL,
      reported_user_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      details TEXT,
      status TEXT DEFAULT 'pending',
      reviewed_by TEXT,
      reviewed_at TEXT,
      action_taken TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS blocks (
      id TEXT PRIMARY KEY,
      blocker_id TEXT NOT NULL,
      blocked_id TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(blocker_id, blocked_id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT,
      data TEXT DEFAULT '{}',
      is_read INTEGER DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_logs (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details TEXT,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_messages_conv   ON messages(conversation_id);
    CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
    CREATE INDEX IF NOT EXISTS idx_likes_from      ON likes(from_user_id);
    CREATE INDEX IF NOT EXISTS idx_likes_to        ON likes(to_user_id);
    CREATE INDEX IF NOT EXISTS idx_notifs_user     ON notifications(user_id);
  `);

  // 5. Seed default admin
  const { v4: uuidv4 } = require('uuid');
  const bcrypt = require('bcryptjs');
  const existing = _db.prepare('SELECT id FROM users WHERE is_admin = 1').get();
  if (!existing) {
    const now = new Date().toISOString();
    _db.prepare(`
      INSERT INTO users (id, email, password_hash, display_name, is_admin, is_verified, created_at, updated_at)
      VALUES (?, ?, ?, ?, 1, 1, ?, ?)
    `).run(uuidv4(), 'admin@mylover.app', bcrypt.hashSync('Admin@MyLover2024!', 10), 'Admin', now, now);
    console.log('✅ Default admin created → admin@mylover.app / Admin@MyLover2024!');
  }

  console.log('✅ Database initialised at', DB_PATH);
  return _db;
}

function getDB() {
  if (!_db) throw new Error('DB not initialised. Await initDB() first.');
  return _db;
}

module.exports = { initDB, getDB };
