// db_sqlite_shim.js  — synchronous-API SQLite backed by sql.js
// Strategy: initialise sql.js once at module load via a pre-loaded singleton.
// Call Database.init() before first use (awaited once at server startup in db.js).

const fs = require('fs');
let _SQL = null; // set by init()

class Statement {
  constructor(sqlDb, sql) { this._db = sqlDb; this._sql = sql; }
  _p(a) { return a.length === 0 ? [] : a.length === 1 && Array.isArray(a[0]) ? a[0] : a; }

  run(...a) {
    this._db._raw.run(this._sql, this._p(a));
    this._db._dirty = true;
    return { changes: this._db._raw.getRowsModified() };
  }
  get(...a) {
    const s = this._db._raw.prepare(this._sql);
    s.bind(this._p(a));
    let obj;
    if (s.step()) { const c = s.getColumnNames(), v = s.get(); obj = {}; c.forEach((k,i)=>obj[k]=v[i]); }
    s.free();
    return obj;
  }
  all(...a) {
    const res = this._db._raw.exec(this._sql, this._p(a));
    if (!res.length) return [];
    const { columns: c, values: rows } = res[0];
    return rows.map(r => { const o = {}; c.forEach((k,i)=>o[k]=r[i]); return o; });
  }
}

class Database {
  // Call once before creating any Database instance
  static async init() {
    if (_SQL) return;
    const initSqlJs = require('sql.js');
    _SQL = await initSqlJs();
  }

  constructor(filePath) {
    if (!_SQL) throw new Error('Call Database.init() before creating a Database instance');
    this._path  = filePath;
    this._dirty = false;
    this._raw   = fs.existsSync(filePath)
      ? new _SQL.Database(fs.readFileSync(filePath))
      : new _SQL.Database();

    // Persist every 2 s when dirty
    this._timer = setInterval(() => { if (this._dirty) this._persist(); }, 2000);
    this._timer.unref();
  }

  _persist() {
    const buf = Buffer.from(this._raw.export());
    const tmp = this._path + '.tmp';
    fs.writeFileSync(tmp, buf);
    fs.renameSync(tmp, this._path);
    this._dirty = false;
  }

  prepare(sql) { return new Statement(this, sql); }

  exec(sql) {
    this._raw.run(sql);
    this._dirty = true;
    this._persist();   // persist immediately for DDL statements
  }

  close() {
    clearInterval(this._timer);
    if (this._dirty) this._persist();
    this._raw.close();
  }
}

module.exports = Database;
