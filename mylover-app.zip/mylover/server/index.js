require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const fs         = require('fs');

const { initDB, getDB }            = require('./db');
const { authenticateSocket }       = require('./middleware/auth');

const app    = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: process.env.CLIENT_URL || 'http://localhost:3000', methods: ['GET','POST'], credentials: true }
});

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/api/', rateLimit({ windowMs: 15*60*1000, max: 300 }));
app.use('/api/auth/', rateLimit({ windowMs: 15*60*1000, max: 30 }));

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

const clientBuild = path.join(__dirname, '../client/build');
if (fs.existsSync(clientBuild)) app.use(express.static(clientBuild));

// ── Bootstrap: init DB then mount routes ─────────────────────────────────────
async function start() {
  await initDB();

  const authRoutes         = require('./routes/auth');
  const userRoutes         = require('./routes/users');
  const matchRoutes        = require('./routes/matches');
  const chatRoutes         = require('./routes/chat');
  const subscriptionRoutes = require('./routes/subscriptions');
  const adminRoutes        = require('./routes/admin');
  const uploadRoutes       = require('./routes/upload');

  app.use('/api/auth',          authRoutes);
  app.use('/api/users',         userRoutes);
  app.use('/api/matches',       matchRoutes);
  app.use('/api/chat',          chatRoutes);
  app.use('/api/subscriptions', subscriptionRoutes);
  app.use('/api/admin',         adminRoutes);
  app.use('/api/upload',        uploadRoutes);
  app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'MyLover', version: '1.0.0' }));

  if (fs.existsSync(clientBuild)) {
    app.get('*', (_req, res) => res.sendFile(path.join(clientBuild, 'index.html')));
  }

  // ── Socket.io ───────────────────────────────────────────────────────────────
  const onlineUsers = new Map();
  io.use(authenticateSocket);

  io.on('connection', (socket) => {
    const userId = socket.user.id;
    onlineUsers.set(userId, socket.id);
    socket.broadcast.emit('user_online', { userId });

    socket.on('join_conversation', ({ conversationId }) => socket.join(`conv_${conversationId}`));

    socket.on('send_message', (data) => {
      const db = getDB();
      const { conversationId, content, messageType = 'text' } = data;

      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
      const sub  = db.prepare("SELECT * FROM subscriptions WHERE user_id = ? AND status = 'active' AND expires_at > ?").get(userId, new Date().toISOString());
      const ageDays = (Date.now() - new Date(user.created_at).getTime()) / 86400000;
      const inTrial = ageDays <= 60;

      if (!inTrial && !sub && !user.is_premium) {
        const today = new Date().toISOString().split('T')[0];
        const cnt   = db.prepare("SELECT COUNT(*) as c FROM messages WHERE sender_id = ? AND created_at >= ?").get(userId, today + 'T00:00:00Z');
        if (cnt.c >= 5) { socket.emit('message_blocked', { reason: 'free_limit', upgradeRequired: true }); return; }
      }

      const { v4: uuidv4 } = require('uuid');
      const msgId = uuidv4();
      const now   = new Date().toISOString();

      db.prepare('INSERT INTO messages (id, conversation_id, sender_id, content, message_type, created_at) VALUES (?,?,?,?,?,?)').run(msgId, conversationId, userId, content, messageType, now);
      db.prepare('UPDATE conversations SET last_message = ?, last_message_at = ?, updated_at = ? WHERE id = ?').run(content, now, now, conversationId);

      const msg = { id: msgId, conversationId, senderId: userId, senderName: user.display_name, senderPhoto: user.profile_photo, content, messageType, created_at: now };
      io.to(`conv_${conversationId}`).emit('new_message', msg);

      const conv = db.prepare('SELECT * FROM conversations WHERE id = ?').get(conversationId);
      if (conv) {
        const recipientId = conv.user1_id === userId ? conv.user2_id : conv.user1_id;
        const rSock = onlineUsers.get(recipientId);
        if (rSock) io.to(rSock).emit('conversation_updated', { conversationId, lastMessage: content });
      }
    });

    socket.on('typing',    ({ conversationId, isTyping }) => socket.to(`conv_${conversationId}`).emit('user_typing', { userId, isTyping }));
    socket.on('mark_read', ({ conversationId }) => {
      const db = getDB();
      db.prepare('UPDATE messages SET is_read = 1 WHERE conversation_id = ? AND sender_id != ? AND is_read = 0').run(conversationId, userId);
      socket.to(`conv_${conversationId}`).emit('messages_read', { conversationId, readBy: userId });
    });

    socket.on('send_like', ({ targetUserId, isSuper = false }) => {
      const db  = getDB();
      const { v4: uuidv4 } = require('uuid');
      const now = new Date().toISOString();

      try {
        db.prepare('INSERT OR REPLACE INTO likes (id, from_user_id, to_user_id, is_super, created_at) VALUES (?,?,?,?,?)').run(uuidv4(), userId, targetUserId, isSuper ? 1 : 0, now);
      } catch {}

      const mutual = db.prepare('SELECT * FROM likes WHERE from_user_id = ? AND to_user_id = ?').get(targetUserId, userId);
      if (mutual) {
        const matchId  = uuidv4();
        const convId   = uuidv4();
        const u1 = userId < targetUserId ? userId : targetUserId;
        const u2 = userId < targetUserId ? targetUserId : userId;
        try {
          db.prepare('INSERT OR IGNORE INTO matches (id, user1_id, user2_id, created_at) VALUES (?,?,?,?)').run(matchId, u1, u2, now);
          db.prepare('INSERT OR IGNORE INTO conversations (id, user1_id, user2_id, created_at, updated_at) VALUES (?,?,?,?,?)').run(convId, u1, u2, now, now);
        } catch {}
        const matchData = { matchId, conversationId: convId };
        socket.emit('its_a_match', { ...matchData, userId: targetUserId });
        const tSock = onlineUsers.get(targetUserId);
        if (tSock) io.to(tSock).emit('its_a_match', { ...matchData, userId });
      } else {
        const tSock = onlineUsers.get(targetUserId);
        if (tSock) io.to(tSock).emit('new_like', { fromUserId: userId, isSuper });
      }
    });

    // WebRTC signaling
    socket.on('call_offer',    ({ targetUserId, offer, conversationId }) => { const s = onlineUsers.get(targetUserId); if (s) io.to(s).emit('incoming_call',  { fromUserId: userId, offer, conversationId }); });
    socket.on('call_answer',   ({ targetUserId, answer })               => { const s = onlineUsers.get(targetUserId); if (s) io.to(s).emit('call_answered',  { answer }); });
    socket.on('ice_candidate', ({ targetUserId, candidate })             => { const s = onlineUsers.get(targetUserId); if (s) io.to(s).emit('ice_candidate',  { candidate }); });
    socket.on('end_call',      ({ targetUserId })                        => { const s = onlineUsers.get(targetUserId); if (s) io.to(s).emit('call_ended'); });

    socket.on('disconnect', () => {
      onlineUsers.delete(userId);
      try { getDB().prepare('UPDATE users SET last_seen = ? WHERE id = ?').run(new Date().toISOString(), userId); } catch {}
      socket.broadcast.emit('user_offline', { userId });
    });
  });

  app.set('io', io);
  app.set('onlineUsers', onlineUsers);

  const PORT = process.env.PORT || 5000;
  server.listen(PORT, () => {
    console.log(`\n🌹 MyLover server running on port ${PORT}`);
    console.log(`   Health: http://localhost:${PORT}/api/health`);
    console.log(`   Admin:  login with admin@mylover.app`);
  });
}

start().catch(err => { console.error('Failed to start:', err); process.exit(1); });

module.exports = { app, io };
