const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { getDB } = require('../db');
const { generateToken, authenticate } = require('../middleware/auth');

const router = express.Router();

// ── Register ─────────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { email, password, displayName, dateOfBirth, gender, country } = req.body;

    if (!email || !password || !displayName) {
      return res.status(400).json({ error: 'Email, password and display name are required' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }

    const db = getDB();
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const id = uuidv4();
    const now = new Date().toISOString();
    const hash = await bcrypt.hash(password, 12);

    db.prepare(`
      INSERT INTO users (id, email, password_hash, display_name, date_of_birth, gender, country, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, email.toLowerCase(), hash, displayName, dateOfBirth || null, gender || null, country || null, now, now);

    const token = generateToken(id);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);

    res.status(201).json({ token, user: sanitizeUser(user) });
  } catch (e) {
    console.error('Register error:', e);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// ── Login ─────────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const db = getDB();
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    if (user.is_banned) return res.status(403).json({ error: 'Account banned', reason: user.ban_reason });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    // Update last seen
    db.prepare('UPDATE users SET last_seen = ? WHERE id = ?').run(new Date().toISOString(), user.id);

    const token = generateToken(user.id);
    res.json({ token, user: sanitizeUser(user) });
  } catch (e) {
    console.error('Login error:', e);
    res.status(500).json({ error: 'Login failed' });
  }
});

// ── Get current user ───────────────────────────────────────────────────────────
router.get('/me', authenticate, (req, res) => {
  const db = getDB();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: sanitizeUser(user) });
});

// ── Check free trial status ───────────────────────────────────────────────────
router.get('/trial-status', authenticate, (req, res) => {
  const user = req.user;
  const accountAgeDays = (Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24);
  const freeTrialDaysLeft = Math.max(0, 60 - Math.floor(accountAgeDays));
  const isInFreeTrial = freeTrialDaysLeft > 0;

  const db = getDB();
  const sub = db.prepare(`
    SELECT * FROM subscriptions WHERE user_id = ? AND status = 'active' AND expires_at > ?
  `).get(user.id, new Date().toISOString());

  res.json({
    isInFreeTrial,
    freeTrialDaysLeft,
    isPremium: !!sub || !!user.is_premium,
    subscription: sub || null
  });
});

function sanitizeUser(user) {
  const { password_hash, ...safe } = user;
  return safe;
}

module.exports = router;
