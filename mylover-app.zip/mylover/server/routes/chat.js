const express = require('express');
const { getDB } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// ── Get conversations list ────────────────────────────────────────────────────
router.get('/conversations', authenticate, (req, res) => {
  const db = getDB();
  const convs = db.prepare(`
    SELECT c.*,
      u1.id as u1_id, u1.display_name as u1_name, u1.profile_photo as u1_photo, u1.last_seen as u1_last_seen, u1.is_premium as u1_premium,
      u2.id as u2_id, u2.display_name as u2_name, u2.profile_photo as u2_photo, u2.last_seen as u2_last_seen, u2.is_premium as u2_premium,
      (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND sender_id != ? AND is_read = 0) as unread_count
    FROM conversations c
    JOIN users u1 ON c.user1_id = u1.id
    JOIN users u2 ON c.user2_id = u2.id
    WHERE (c.user1_id = ? OR c.user2_id = ?) AND u1.is_banned = 0 AND u2.is_banned = 0
    ORDER BY c.updated_at DESC
  `).all(req.user.id, req.user.id, req.user.id);

  const result = convs.map(c => {
    const isUser1 = c.user1_id === req.user.id;
    return {
      id: c.id,
      lastMessage: c.last_message,
      lastMessageAt: c.last_message_at,
      unreadCount: c.unread_count,
      updatedAt: c.updated_at,
      partner: {
        id: isUser1 ? c.u2_id : c.u1_id,
        name: isUser1 ? c.u2_name : c.u1_name,
        photo: isUser1 ? c.u2_photo : c.u1_photo,
        lastSeen: isUser1 ? c.u2_last_seen : c.u1_last_seen,
        isPremium: isUser1 ? c.u2_premium : c.u1_premium
      }
    };
  });

  res.json({ conversations: result });
});

// ── Get messages in a conversation ────────────────────────────────────────────
router.get('/conversations/:id/messages', authenticate, (req, res) => {
  const db = getDB();
  const { page = 1, limit = 50 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  const conv = db.prepare('SELECT * FROM conversations WHERE id = ?').get(req.params.id);
  if (!conv) return res.status(404).json({ error: 'Conversation not found' });
  if (conv.user1_id !== req.user.id && conv.user2_id !== req.user.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const messages = db.prepare(`
    SELECT m.*, u.display_name as sender_name, u.profile_photo as sender_photo
    FROM messages m JOIN users u ON m.sender_id = u.id
    WHERE m.conversation_id = ?
    ORDER BY m.created_at DESC LIMIT ? OFFSET ?
  `).all(req.params.id, parseInt(limit), offset);

  // Mark as read
  db.prepare(`
    UPDATE messages SET is_read = 1 WHERE conversation_id = ? AND sender_id != ? AND is_read = 0
  `).run(req.params.id, req.user.id);

  res.json({ messages: messages.reverse(), page: parseInt(page), hasMore: messages.length === parseInt(limit) });
});

// ── AI Dating Coach ───────────────────────────────────────────────────────────
router.post('/ai-coach', authenticate, async (req, res) => {
  const db = getDB();
  const user = req.user;

  // Check AI credits
  if (user.ai_credits <= 0) {
    return res.status(403).json({ error: 'No AI credits remaining', upgradeRequired: true });
  }

  const { message, conversationHistory = [] } = req.body;

  // Deduct 1 credit
  db.prepare('UPDATE users SET ai_credits = ai_credits - 1 WHERE id = ?').run(user.id);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 600,
        system: `You are MyLover's AI Dating Coach — warm, empathetic, and expert in international relationships. 
You help users with:
- Writing great opening messages and conversation starters
- Dating advice tailored to different cultures and countries
- Profile improvement tips
- Relationship guidance
- How to handle matches and keep conversations going

User profile: ${user.display_name}, from ${user.country || 'unknown'}, ${user.gender || ''}, ${user.bio ? 'Bio: ' + user.bio : ''}

Be concise, practical, and encouraging. Keep responses to 3-5 sentences unless asked for more detail.`,
        messages: [
          ...conversationHistory.slice(-6),
          { role: 'user', content: message }
        ]
      })
    });

    const data = await response.json();
    const reply = data.content?.[0]?.text || 'I apologize, I could not generate a response right now.';

    const updatedUser = db.prepare('SELECT ai_credits FROM users WHERE id = ?').get(user.id);
    res.json({ reply, creditsRemaining: updatedUser.ai_credits });
  } catch (e) {
    console.error('AI coach error:', e);
    // Refund the credit on error
    db.prepare('UPDATE users SET ai_credits = ai_credits + 1 WHERE id = ?').run(user.id);
    res.status(500).json({ error: 'AI service temporarily unavailable' });
  }
});

// ── AI Icebreaker generator ───────────────────────────────────────────────────
router.post('/ai-icebreaker', authenticate, async (req, res) => {
  const db = getDB();
  const { targetUserId } = req.body;

  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(targetUserId);
  if (!target) return res.status(404).json({ error: 'User not found' });

  const me = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 300,
        messages: [{
          role: 'user',
          content: `Generate 3 creative, genuine, and culturally sensitive opening messages for ${me.display_name} (from ${me.country}, ${me.gender}) to send to ${target.display_name} (from ${target.country}, interests: ${target.interests || 'unknown'}, bio: ${target.bio || 'none'}). 

Make them warm, not cheesy. Format as a numbered list. Each should be 1-2 sentences.`
        }]
      })
    });

    const data = await response.json();
    const suggestions = data.content?.[0]?.text || '';
    db.prepare('UPDATE users SET ai_credits = ai_credits - 1 WHERE id = ? AND ai_credits > 0').run(req.user.id);
    res.json({ suggestions });
  } catch (e) {
    res.status(500).json({ error: 'Could not generate icebreakers' });
  }
});

module.exports = router;
