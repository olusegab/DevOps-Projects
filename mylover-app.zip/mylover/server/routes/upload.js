const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { getDB } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, '../uploads');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const userDir = path.join(UPLOAD_DIR, req.user.id);
    if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
    cb(null, userDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) cb(null, true);
    else cb(new Error('Only image files are allowed'));
  }
});

// Upload a single photo
router.post('/photo', authenticate, upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const url = `/uploads/${req.user.id}/${req.file.filename}`;
  res.json({ url, filename: req.file.filename });
});

// Set profile photo
router.post('/profile-photo', authenticate, upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const db = getDB();
  const url = `/uploads/${req.user.id}/${req.file.filename}`;
  db.prepare('UPDATE users SET profile_photo = ?, updated_at = ? WHERE id = ?')
    .run(url, new Date().toISOString(), req.user.id);

  res.json({ url });
});

// Upload multiple photos (max 6)
router.post('/photos', authenticate, upload.array('photos', 6), (req, res) => {
  if (!req.files?.length) return res.status(400).json({ error: 'No files uploaded' });

  const db = getDB();
  const user = db.prepare('SELECT photos FROM users WHERE id = ?').get(req.user.id);
  const existing = JSON.parse(user.photos || '[]');

  const newUrls = req.files.map(f => `/uploads/${req.user.id}/${f.filename}`);
  const allPhotos = [...existing, ...newUrls].slice(0, 9); // max 9 photos

  db.prepare('UPDATE users SET photos = ?, updated_at = ? WHERE id = ?')
    .run(JSON.stringify(allPhotos), new Date().toISOString(), req.user.id);

  res.json({ urls: newUrls, allPhotos });
});

// Delete a photo
router.delete('/photos', authenticate, (req, res) => {
  const db = getDB();
  const { url } = req.body;
  const user = db.prepare('SELECT photos, profile_photo FROM users WHERE id = ?').get(req.user.id);
  const photos = JSON.parse(user.photos || '[]').filter(p => p !== url);

  const updates = { photos: JSON.stringify(photos) };
  if (user.profile_photo === url) updates.profile_photo = photos[0] || null;

  db.prepare(`UPDATE users SET photos = ?, profile_photo = ?, updated_at = ? WHERE id = ?`)
    .run(updates.photos, updates.profile_photo || null, new Date().toISOString(), req.user.id);

  // Delete file
  try {
    const filePath = path.join(__dirname, '..', url);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch (e) {}

  res.json({ success: true, allPhotos: photos });
});

module.exports = router;
