const express = require('express');
const { getDB } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// Get all matches
router.get('/', authenticate, (req, res) => {
  const db = getDB();
  const matches = db.prepare(`
    SELECT m.*,
      u1.id as u1_id, u1.display_name as u1_name, u1.profile_photo as u1_photo, u1.last_seen as u1_last_seen,
      u2.id as u2_id, u2.display_name as u2_name, u2.profile_photo as u2_photo, u2.last_seen as u2_last_seen,
      c.id as conv_id, c.last_message, c.last_message_at
    FROM matches m
    JOIN users u1 ON m.user1_id = u1.id
    JOIN users u2 ON m.user2_id = u2.id
    LEFT JOIN conversations c ON (c.user1_id = m.user1_id AND c.user2_id = m.user2_id)
    WHERE m.user1_id = ? OR m.user2_id = ?
    ORDER BY c.last_message_at DESC, m.created_at DESC
  `).all(req.user.id, req.user.id);

  const result = matches.map(m => {
    const isUser1 = m.user1_id === req.user.id;
    return {
      matchId: m.id,
      conversationId: m.conv_id,
      matchedAt: m.created_at,
      lastMessage: m.last_message,
      lastMessageAt: m.last_message_at,
      user: {
        id: isUser1 ? m.u2_id : m.u1_id,
        name: isUser1 ? m.u2_name : m.u1_name,
        photo: isUser1 ? m.u2_photo : m.u1_photo,
        lastSeen: isUser1 ? m.u2_last_seen : m.u1_last_seen,
      }
    };
  });

  res.json({ matches: result });
});

// Get who liked me
router.get('/likes-received', authenticate, (req, res) => {
  const db = getDB();
  // Premium feature: see who liked you
  const user = req.user;
  const sub = db.prepare(`SELECT * FROM subscriptions WHERE user_id = ? AND status = 'active' AND expires_at > ?`)
    .get(user.id, new Date().toISOString());
  const accountAgeDays = (Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24);

  if (!sub && !user.is_premium && accountAgeDays > 60) {
    return res.status(403).json({ error: 'Premium required', upgradeRequired: true });
  }

  const likes = db.prepare(`
    SELECT l.*, u.display_name, u.profile_photo, u.city, u.country, u.date_of_birth, u.is_verified
    FROM likes l JOIN users u ON l.from_user_id = u.id
    WHERE l.to_user_id = ? AND u.is_banned = 0
    ORDER BY l.created_at DESC LIMIT 50
  `).all(req.user.id);

  res.json({ likes: likes.map(l => ({
    ...l,
    age: l.date_of_birth ? Math.floor((Date.now() - new Date(l.date_of_birth)) / (1000*60*60*24*365.25)) : null
  }))});
});

module.exports = router;
