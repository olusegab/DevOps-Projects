const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDB } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// ── Haversine distance in metres ─────────────────────────────────────────────
function haversine(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lng1 == null || lat2 == null || lng2 == null) return null;
  const R = 6371000;
  const toRad = d => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLng/2)**2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));
}

// ── Update profile ────────────────────────────────────────────────────────────
router.put('/profile', authenticate, (req, res) => {
  const db = getDB();
  const now = new Date().toISOString();
  const allowed = [
    'display_name','bio','occupation','education','height','religion',
    'ethnicity','language','city','country','gender','interested_in',
    'date_of_birth','interests','photos','profile_photo','lat','lng'
  ];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

  if (Array.isArray(updates.interests)) updates.interests = JSON.stringify(updates.interests);
  if (Array.isArray(updates.photos)) updates.photos = JSON.stringify(updates.photos);

  if (Object.keys(updates).length === 0) return res.json({ success: true });

  const setClauses = Object.keys(updates).map(k => `${k} = ?`).join(', ');
  const values = [...Object.values(updates), now, req.user.id];
  db.prepare(`UPDATE users SET ${setClauses}, updated_at = ? WHERE id = ?`).run(...values);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const { password_hash, ...safe } = user;
  res.json({ user: safe });
});

// ── Discovery / Swipe feed (gender-opposite by default) ──────────────────────
router.get('/discover', authenticate, (req, res) => {
  const db = getDB();
  const me = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const { page = 1, limit = 20, minAge, maxAge, country, maxDistance } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  // Exclude already-liked and blocked
  const likedIds = db.prepare('SELECT to_user_id FROM likes WHERE from_user_id = ?')
    .all(me.id).map(r => r.to_user_id);
  const blockedIds = db.prepare('SELECT blocked_id FROM blocks WHERE blocker_id = ?')
    .all(me.id).map(r => r.blocked_id);
  const excludeIds = [...likedIds, ...blockedIds, me.id];

  let query = `
    SELECT id, display_name, date_of_birth, gender, country, city, bio,
           profile_photo, photos, interests, occupation, height, religion,
           ethnicity, language, is_verified, is_premium, last_seen, lat, lng
    FROM users
    WHERE is_banned = 0 AND profile_photo IS NOT NULL
  `;
  const params = [];

  if (excludeIds.length > 0) {
    query += ` AND id NOT IN (${excludeIds.map(() => '?').join(',')})`;
    params.push(...excludeIds);
  }

  // Show opposite gender by default (or match interested_in preference)
  const interestedIn = me.interested_in;
  if (interestedIn && interestedIn !== 'everyone') {
    query += ` AND gender = ?`;
    params.push(interestedIn);
  } else if (!interestedIn && me.gender) {
    // Default: show opposite
    const opposite = me.gender === 'male' ? 'female' : me.gender === 'female' ? 'male' : null;
    if (opposite) { query += ` AND gender = ?`; params.push(opposite); }
  }

  if (country) { query += ` AND country = ?`; params.push(country); }

  if (minAge) {
    const d = new Date(); d.setFullYear(d.getFullYear() - parseInt(minAge));
    query += ` AND date_of_birth <= ?`; params.push(d.toISOString().split('T')[0]);
  }
  if (maxAge) {
    const d = new Date(); d.setFullYear(d.getFullYear() - parseInt(maxAge) - 1);
    query += ` AND date_of_birth >= ?`; params.push(d.toISOString().split('T')[0]);
  }

  // Fetch more than needed so we can filter by distance client-side if needed
  query += ` ORDER BY is_premium DESC, last_seen DESC LIMIT ? OFFSET ?`;
  params.push(Math.min(parseInt(limit) * 3, 200), offset);

  let profiles = db.prepare(query).all(...params).map(p => {
    const distM = haversine(me.lat, me.lng, p.lat, p.lng);
    return {
      ...p,
      photos: JSON.parse(p.photos || '[]'),
      interests: JSON.parse(p.interests || '[]'),
      age: p.date_of_birth ? Math.floor((Date.now() - new Date(p.date_of_birth)) / (1000*60*60*24*365.25)) : null,
      distanceMetres: distM,
      distanceLabel: formatDist(distM)
    };
  });

  // Filter by max distance if provided
  if (maxDistance) {
    const maxM = parseInt(maxDistance) * 1000; // km → metres
    profiles = profiles.filter(p => p.distanceMetres == null || p.distanceMetres <= maxM);
  }

  // Sort by distance if user has location
  if (me.lat && me.lng) {
    profiles.sort((a, b) => {
      if (a.distanceMetres == null) return 1;
      if (b.distanceMetres == null) return -1;
      return a.distanceMetres - b.distanceMetres;
    });
  }

  profiles = profiles.slice(0, parseInt(limit));
  res.json({ profiles, page: parseInt(page), hasMore: profiles.length === parseInt(limit) });
});

function formatDist(m) {
  if (m == null) return null;
  if (m < 1000) return `${m} m away`;
  return m < 100000 ? `${(m/1000).toFixed(1)} km away` : `${Math.round(m/1000)} km away`;
}

// ── Get a single profile ──────────────────────────────────────────────────────
router.get('/:id', authenticate, (req, res) => {
  const db = getDB();
  const me = db.prepare('SELECT lat, lng FROM users WHERE id = ?').get(req.user.id);
  const user = db.prepare(`
    SELECT id, display_name, date_of_birth, gender, country, city, bio,
           profile_photo, photos, interests, occupation, height, religion,
           ethnicity, language, is_verified, is_premium, last_seen, created_at, lat, lng
    FROM users WHERE id = ? AND is_banned = 0
  `).get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const distM = haversine(me.lat, me.lng, user.lat, user.lng);
  res.json({
    ...user,
    photos: JSON.parse(user.photos || '[]'),
    interests: JSON.parse(user.interests || '[]'),
    age: user.date_of_birth ? Math.floor((Date.now() - new Date(user.date_of_birth)) / (1000*60*60*24*365.25)) : null,
    distanceMetres: distM,
    distanceLabel: formatDist(distM)
  });
});

// ── Search users ──────────────────────────────────────────────────────────────
router.get('/search', authenticate, (req, res) => {
  const db = getDB();
  const { q } = req.query;
  if (!q) return res.json({ results: [] });
  const me = db.prepare('SELECT lat, lng FROM users WHERE id = ?').get(req.user.id);
  const results = db.prepare(`
    SELECT id, display_name, date_of_birth, gender, country, city, profile_photo, is_verified, is_premium, lat, lng
    FROM users WHERE is_banned = 0 AND id != ?
      AND (display_name LIKE ? OR city LIKE ? OR country LIKE ?)
    LIMIT 30
  `).all(req.user.id, `%${q}%`, `%${q}%`, `%${q}%`);

  res.json({ results: results.map(r => {
    const distM = haversine(me.lat, me.lng, r.lat, r.lng);
    return { ...r,
      age: r.date_of_birth ? Math.floor((Date.now() - new Date(r.date_of_birth)) / (1000*60*60*24*365.25)) : null,
      distanceMetres: distM, distanceLabel: formatDist(distM)
    };
  })});
});

// ── Block ─────────────────────────────────────────────────────────────────────
router.post('/:id/block', authenticate, (req, res) => {
  const db = getDB();
  db.prepare('INSERT OR IGNORE INTO blocks (id, blocker_id, blocked_id, created_at) VALUES (?, ?, ?, ?)')
    .run(uuidv4(), req.user.id, req.params.id, new Date().toISOString());
  res.json({ success: true });
});

// ── Report ────────────────────────────────────────────────────────────────────
router.post('/:id/report', authenticate, (req, res) => {
  const db = getDB();
  const { reason, details } = req.body;
  db.prepare('INSERT INTO reports (id, reporter_id, reported_user_id, reason, details, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(uuidv4(), req.user.id, req.params.id, reason, details || null, new Date().toISOString());
  res.json({ success: true });
});

module.exports = router;
