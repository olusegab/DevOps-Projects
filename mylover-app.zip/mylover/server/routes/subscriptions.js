const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDB } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

const PLANS = {
  weekly: {
    name: 'Weekly Premium',
    duration: 7,
    prices: { USD: 4.99, NGN: 7999, GBP: 3.99, EUR: 4.49, KES: 699 }
  },
  monthly: {
    name: 'Monthly Premium',
    duration: 30,
    prices: { USD: 14.99, NGN: 22999, GBP: 11.99, EUR: 13.99, KES: 1999 }
  },
  yearly: {
    name: 'Yearly Premium',
    duration: 365,
    prices: { USD: 99.99, NGN: 149999, GBP: 79.99, EUR: 89.99, KES: 12999 }
  }
};

const PREMIUM_FEATURES = [
  'Unlimited messages',
  'See who liked you',
  'Advanced filters (age, country, interests)',
  'Super likes (5/day)',
  'Read receipts',
  'Priority in discovery',
  'AI dating coach (unlimited)',
  'Video calls',
  'Profile boost (1/week)',
  'No ads'
];

// ── Get plans ─────────────────────────────────────────────────────────────────
router.get('/plans', (req, res) => {
  const currency = req.query.currency || 'USD';
  const plans = Object.entries(PLANS).map(([key, plan]) => ({
    id: key,
    name: plan.name,
    duration: plan.duration,
    price: plan.prices[currency] || plan.prices.USD,
    currency: plan.prices[currency] ? currency : 'USD',
    features: PREMIUM_FEATURES,
    popular: key === 'monthly'
  }));
  res.json({ plans, features: PREMIUM_FEATURES });
});

// ── Get current subscription ──────────────────────────────────────────────────
router.get('/current', authenticate, (req, res) => {
  const db = getDB();
  const sub = db.prepare(`
    SELECT * FROM subscriptions WHERE user_id = ? AND status = 'active' AND expires_at > ?
    ORDER BY expires_at DESC LIMIT 1
  `).get(req.user.id, new Date().toISOString());

  const accountAgeDays = (Date.now() - new Date(req.user.created_at).getTime()) / (1000 * 60 * 60 * 24);
  const freeTrialDaysLeft = Math.max(0, 60 - Math.floor(accountAgeDays));

  res.json({
    subscription: sub || null,
    isPremium: !!(sub || req.user.is_premium),
    isInFreeTrial: freeTrialDaysLeft > 0,
    freeTrialDaysLeft,
    plans: PLANS
  });
});

// ── Subscribe (manual payment reference for now) ──────────────────────────────
// In production: integrate Paystack (Nigeria), Stripe (international), Flutterwave
router.post('/subscribe', authenticate, (req, res) => {
  const db = getDB();
  const { plan, currency = 'USD', paymentRef } = req.body;

  if (!PLANS[plan]) return res.status(400).json({ error: 'Invalid plan' });
  if (!paymentRef) return res.status(400).json({ error: 'Payment reference required' });

  const planData = PLANS[plan];
  const now = new Date();
  const expires = new Date(now.getTime() + planData.duration * 24 * 60 * 60 * 1000);
  const subId = uuidv4();

  db.prepare(`
    INSERT INTO subscriptions (id, user_id, plan, status, price, currency, started_at, expires_at, payment_ref, created_at)
    VALUES (?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)
  `).run(
    subId, req.user.id, plan,
    planData.prices[currency] || planData.prices.USD, currency,
    now.toISOString(), expires.toISOString(), paymentRef, now.toISOString()
  );

  db.prepare('UPDATE users SET is_premium = 1, ai_credits = ai_credits + 500 WHERE id = ?').run(req.user.id);

  const sub = db.prepare('SELECT * FROM subscriptions WHERE id = ?').get(subId);
  res.json({ subscription: sub, message: `${planData.name} activated successfully!` });
});

// ── Cancel subscription ───────────────────────────────────────────────────────
router.post('/cancel', authenticate, (req, res) => {
  const db = getDB();
  db.prepare(`UPDATE subscriptions SET status = 'cancelled' WHERE user_id = ? AND status = 'active'`).run(req.user.id);
  db.prepare('UPDATE users SET is_premium = 0 WHERE id = ?').run(req.user.id);
  res.json({ success: true, message: 'Subscription cancelled. Access continues until expiry.' });
});

module.exports = router;
