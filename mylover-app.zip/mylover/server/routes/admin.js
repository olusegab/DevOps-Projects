const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDB } = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, requireAdmin);

// ── Dashboard stats ───────────────────────────────────────────────────────────
router.get('/stats', (req, res) => {
  const db = getDB();
  const now = new Date().toISOString();
  const today = new Date().toISOString().split('T')[0];
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

  const stats = {
    users: {
      total: db.prepare('SELECT COUNT(*) as c FROM users WHERE is_admin = 0').get().c,
      active_today: db.prepare("SELECT COUNT(*) as c FROM users WHERE last_seen >= ?").get(today + 'T00:00:00Z').c,
      new_this_week: db.prepare("SELECT COUNT(*) as c FROM users WHERE created_at >= ?").get(weekAgo).c,
      new_this_month: db.prepare("SELECT COUNT(*) as c FROM users WHERE created_at >= ?").get(monthAgo).c,
      premium: db.prepare("SELECT COUNT(*) as c FROM users WHERE is_premium = 1").get().c,
      banned: db.prepare("SELECT COUNT(*) as c FROM users WHERE is_banned = 1").get().c,
      verified: db.prepare("SELECT COUNT(*) as c FROM users WHERE is_verified = 1").get().c,
    },
    messages: {
      total: db.prepare('SELECT COUNT(*) as c FROM messages').get().c,
      today: db.prepare("SELECT COUNT(*) as c FROM messages WHERE created_at >= ?").get(today + 'T00:00:00Z').c,
      this_week: db.prepare("SELECT COUNT(*) as c FROM messages WHERE created_at >= ?").get(weekAgo).c,
      flagged: db.prepare('SELECT COUNT(*) as c FROM messages WHERE is_flagged = 1').get().c,
    },
    matches: {
      total: db.prepare('SELECT COUNT(*) as c FROM matches').get().c,
      this_week: db.prepare("SELECT COUNT(*) as c FROM matches WHERE created_at >= ?").get(weekAgo).c,
    },
    subscriptions: {
      active: db.prepare("SELECT COUNT(*) as c FROM subscriptions WHERE status = 'active' AND expires_at > ?").get(now).c,
      weekly: db.prepare("SELECT COUNT(*) as c FROM subscriptions WHERE plan = 'weekly' AND status = 'active'").get().c,
      monthly: db.prepare("SELECT COUNT(*) as c FROM subscriptions WHERE plan = 'monthly' AND status = 'active'").get().c,
      yearly: db.prepare("SELECT COUNT(*) as c FROM subscriptions WHERE plan = 'yearly' AND status = 'active'").get().c,
    },
    reports: {
      pending: db.prepare("SELECT COUNT(*) as c FROM reports WHERE status = 'pending'").get().c,
      total: db.prepare('SELECT COUNT(*) as c FROM reports').get().c,
    },
    countries: db.prepare(`
      SELECT country, COUNT(*) as count FROM users WHERE country IS NOT NULL AND is_admin = 0
      GROUP BY country ORDER BY count DESC LIMIT 10
    `).all(),
    signups_by_day: db.prepare(`
      SELECT substr(created_at, 1, 10) as day, COUNT(*) as count
      FROM users WHERE created_at >= ? AND is_admin = 0
      GROUP BY day ORDER BY day
    `).all(weekAgo)
  };

  res.json(stats);
});

// ── All users ────────────────────────────────────────────────────────────────
router.get('/users', (req, res) => {
  const db = getDB();
  const { page = 1, limit = 50, search, status, country } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let query = `SELECT id, email, display_name, country, city, gender, is_verified, is_premium, is_banned, is_admin, ban_reason, created_at, last_seen FROM users WHERE is_admin = 0`;
  const params = [];

  if (search) { query += ` AND (display_name LIKE ? OR email LIKE ?)`; params.push(`%${search}%`, `%${search}%`); }
  if (status === 'banned') { query += ` AND is_banned = 1`; }
  else if (status === 'premium') { query += ` AND is_premium = 1`; }
  else if (status === 'verified') { query += ` AND is_verified = 1`; }
  if (country) { query += ` AND country = ?`; params.push(country); }

  const total = db.prepare(`SELECT COUNT(*) as c FROM (${query})`).get(...params).c;
  query += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
  params.push(parseInt(limit), offset);

  const users = db.prepare(query).all(...params);
  res.json({ users, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
});

// ── Get user details ───────────────────────────────────────────────────────────
router.get('/users/:id', (req, res) => {
  const db = getDB();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const { password_hash, ...safe } = user;
  const subs = db.prepare('SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC').all(req.params.id);
  const reports_about = db.prepare('SELECT * FROM reports WHERE reported_user_id = ? ORDER BY created_at DESC').all(req.params.id);
  const messages_count = db.prepare('SELECT COUNT(*) as c FROM messages WHERE sender_id = ?').get(req.params.id);
  res.json({ user: safe, subscriptions: subs, reports: reports_about, messageCount: messages_count.c });
});

// ── Ban user ──────────────────────────────────────────────────────────────────
router.post('/users/:id/ban', (req, res) => {
  const db = getDB();
  const { reason } = req.body;
  db.prepare('UPDATE users SET is_banned = 1, ban_reason = ? WHERE id = ?').run(reason || 'Violation of terms', req.params.id);
  db.prepare(`INSERT INTO admin_logs (id, admin_id, action, target_type, target_id, details, created_at) VALUES (?, ?, 'ban_user', 'user', ?, ?, ?)`)
    .run(uuidv4(), req.user.id, req.params.id, reason, new Date().toISOString());
  res.json({ success: true });
});

// ── Unban user ────────────────────────────────────────────────────────────────
router.post('/users/:id/unban', (req, res) => {
  const db = getDB();
  db.prepare('UPDATE users SET is_banned = 0, ban_reason = NULL WHERE id = ?').run(req.params.id);
  db.prepare(`INSERT INTO admin_logs (id, admin_id, action, target_type, target_id, details, created_at) VALUES (?, ?, 'unban_user', 'user', ?, ?, ?)`)
    .run(uuidv4(), req.user.id, req.params.id, 'Unbanned', new Date().toISOString());
  res.json({ success: true });
});

// ── Verify user ───────────────────────────────────────────────────────────────
router.post('/users/:id/verify', (req, res) => {
  const db = getDB();
  db.prepare('UPDATE users SET is_verified = 1 WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ── Grant premium ─────────────────────────────────────────────────────────────
router.post('/users/:id/grant-premium', (req, res) => {
  const db = getDB();
  const { days = 30 } = req.body;
  const expires = new Date(Date.now() + parseInt(days) * 24 * 60 * 60 * 1000).toISOString();
  db.prepare('UPDATE users SET is_premium = 1 WHERE id = ?').run(req.params.id);
  db.prepare(`INSERT INTO subscriptions (id, user_id, plan, status, price, currency, started_at, expires_at, payment_ref, created_at) VALUES (?, ?, 'admin_grant', 'active', 0, 'USD', ?, ?, 'admin_grant', ?)`)
    .run(uuidv4(), req.params.id, new Date().toISOString(), expires, new Date().toISOString());
  res.json({ success: true });
});

// ── All messages (monitoring) ─────────────────────────────────────────────────
router.get('/messages', (req, res) => {
  const db = getDB();
  const { page = 1, limit = 100, flagged, search, conversationId } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let query = `
    SELECT m.*, 
      u.display_name as sender_name, u.email as sender_email,
      c.user1_id, c.user2_id
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    JOIN conversations c ON m.conversation_id = c.id
    WHERE 1=1
  `;
  const params = [];

  if (flagged === 'true') { query += ` AND m.is_flagged = 1`; }
  if (conversationId) { query += ` AND m.conversation_id = ?`; params.push(conversationId); }
  if (search) { query += ` AND m.content LIKE ?`; params.push(`%${search}%`); }

  query += ` ORDER BY m.created_at DESC LIMIT ? OFFSET ?`;
  params.push(parseInt(limit), offset);

  const messages = db.prepare(query).all(...params);
  res.json({ messages });
});

// ── Flag / unflag a message ───────────────────────────────────────────────────
router.post('/messages/:id/flag', (req, res) => {
  const db = getDB();
  const { reason } = req.body;
  db.prepare('UPDATE messages SET is_flagged = 1, flag_reason = ? WHERE id = ?').run(reason || 'Admin flagged', req.params.id);
  res.json({ success: true });
});

router.post('/messages/:id/unflag', (req, res) => {
  const db = getDB();
  db.prepare('UPDATE messages SET is_flagged = 0, flag_reason = NULL WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ── AI content scan (auto-flag suspicious messages) ───────────────────────────
router.post('/messages/ai-scan', async (req, res) => {
  const db = getDB();
  const { messageIds } = req.body;
  if (!messageIds?.length) return res.status(400).json({ error: 'No message IDs provided' });

  const messages = messageIds.map(id => db.prepare('SELECT * FROM messages WHERE id = ?').get(id)).filter(Boolean);
  if (!messages.length) return res.json({ scanned: 0 });

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: `You are a content moderation AI for a dating app. Analyze these messages and identify any that contain:
- Scam/fraud attempts (asking for money, gift cards, cryptocurrency)
- Explicit sexual content sent without consent
- Harassment, threats, or hate speech
- Personal information harvesting
- Spam or fake profiles

Messages to analyze:
${messages.map(m => `[ID: ${m.id}] "${m.content}"`).join('\n')}

Respond ONLY with JSON: {"flagged": [{"id": "...", "reason": "..."}]}`
        }]
      })
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '{"flagged":[]}';
    const clean = text.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);

    let flaggedCount = 0;
    for (const item of result.flagged || []) {
      db.prepare('UPDATE messages SET is_flagged = 1, flag_reason = ? WHERE id = ?').run(item.reason, item.id);
      flaggedCount++;
    }

    res.json({ scanned: messages.length, flagged: flaggedCount, details: result.flagged });
  } catch (e) {
    res.status(500).json({ error: 'AI scan failed' });
  }
});

// ── Reports management ────────────────────────────────────────────────────────
router.get('/reports', (req, res) => {
  const db = getDB();
  const { status = 'pending' } = req.query;
  const reports = db.prepare(`
    SELECT r.*,
      u1.display_name as reporter_name, u1.email as reporter_email,
      u2.display_name as reported_name, u2.email as reported_email, u2.is_banned as reported_is_banned
    FROM reports r
    JOIN users u1 ON r.reporter_id = u1.id
    JOIN users u2 ON r.reported_user_id = u2.id
    WHERE r.status = ?
    ORDER BY r.created_at DESC
  `).all(status);
  res.json({ reports });
});

router.post('/reports/:id/resolve', (req, res) => {
  const db = getDB();
  const { action, actionTaken } = req.body;
  db.prepare(`UPDATE reports SET status = 'resolved', reviewed_by = ?, reviewed_at = ?, action_taken = ? WHERE id = ?`)
    .run(req.user.id, new Date().toISOString(), actionTaken || action, req.params.id);
  res.json({ success: true });
});

// ── Admin logs ────────────────────────────────────────────────────────────────
router.get('/logs', (req, res) => {
  const db = getDB();
  const logs = db.prepare(`
    SELECT l.*, u.display_name as admin_name
    FROM admin_logs l JOIN users u ON l.admin_id = u.id
    ORDER BY l.created_at DESC LIMIT 200
  `).all();
  res.json({ logs });
});

// ── Subscriptions overview ────────────────────────────────────────────────────
router.get('/subscriptions', (req, res) => {
  const db = getDB();
  const subs = db.prepare(`
    SELECT s.*, u.display_name, u.email
    FROM subscriptions s JOIN users u ON s.user_id = u.id
    ORDER BY s.created_at DESC LIMIT 200
  `).all();
  res.json({ subscriptions: subs });
});

module.exports = router;
